import java.util.Base64;

public class Base64Helper {
    //Encode:
    public static String encode(String input) {

        return Base64.getEncoder().encodeToString(input.getBytes());

    }

    //Decode:
    public static String decode(String input) {

        byte[] decodedBytes = Base64.getDecoder().decode(input);
        return new String(decodedBytes);

    }

    //For Urls
    //Encode:
    public static String encodeURL(String input) {

        return Base64.getUrlEncoder().encodeToString(input.getBytes());

    }

    //Decode:
    public static String decodeURL(String input) {

        byte[] decodedBytes = Base64.getUrlDecoder().decode(input);
        return new String(decodedBytes);

    }
}
