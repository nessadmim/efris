import com.jacob.com.Dispatch;
import com.jacob.com.Variant;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.XML;
import org.json.JSONException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import java.util.Date;
import java.util.UUID;

public class Connection {
    public static int PRETTY_PRINT_INDENT_FACTOR = 4;

    public static String efris_url = "http://192.168.0.31:9880/efristcs/ws/tcsapp/getInformation";
    public static void main(String[] args) {
        //Permission Mode
        Variant QBPermissionMode = new Variant(1);
        //Mode for Multi user/Single User or both, this setting is both
        Variant QBaccessMode = new Variant(2);
        //Leave Empty to use the currently opened QB File
        String fileLocation = "C:\\Users\\Public\\Documents\\Intuit\\QuickBooks\\Company Files\\SAHARA TECH AND ANALYTICS.QBW";  //not needed unless opening QB file which is currently not opened

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String current_date = formatter.format(new Date());

        String XMLRequest = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<?qbxml version=\"13.0\"?>\n" +
                "<QBXML>\n" +
                "  <QBXMLMsgsRq onError=\"stopOnError\">\n" +
                "    <InvoiceQueryRq requestID=\"" + UUID.randomUUID() + "\">\n" +
                " \n" +
                "     <ModifiedDateRangeFilter>\n" +
                " \n" +
                "     <FromModifiedDate>2022-01-01</FromModifiedDate><ToModifiedDate>2022-06-30</ToModifiedDate>\n" +
                " \n" +
                "     </ModifiedDateRangeFilter><IncludeLineItems>true</IncludeLineItems></InvoiceQueryRq>\n" +
                " \n" +
                "  </QBXMLMsgsRq>\n" +
                "</QBXML>";


        String appID = "";//not needed unless you want to set AppID
        String applicationName = "QB Sync Test";
        Dispatch MySessionManager = new Dispatch("QBXMLRP2.RequestProcessor");
        Dispatch.call(MySessionManager, "OpenConnection2", appID, applicationName, QBPermissionMode);
        Variant ticket = Dispatch.call(MySessionManager, "BeginSession",fileLocation, QBaccessMode);
        Variant apiResponse = Dispatch.call(MySessionManager, "ProcessRequest", ticket, XMLRequest);
        try {

            /** XML */
            //System.out.println(apiResponse.toString());
            JSONObject xmlJSONObj = XML.toJSONObject(apiResponse.toString());

            /** JSON*/
            String jsonPrettyPrintString = xmlJSONObj.toString(PRETTY_PRINT_INDENT_FACTOR);
            //System.out.println(js     onPrettyPrintString);

            /** JSON string to JSON obj*/
            JSONObject json = new JSONObject(jsonPrettyPrintString);



            // get locations array from the JSON Object and store it into JSONArray

            JSONObject QBXML_obj = json.getJSONObject("QBXML");
            //String QBXMLMsgsRs_str = QBXML_obj.getString("QBXMLMsgsRs");
            JSONObject QBXMLMsgsRs_obj = QBXML_obj.getJSONObject("QBXMLMsgsRs");
            //String InvoiceQueryRs_str = QBXMLMsgsRs_obj.getString("InvoiceQueryRs");
            JSONObject InvoiceQueryRs_obj = QBXMLMsgsRs_obj.getJSONObject("InvoiceQueryRs");
            JSONArray jsonArray = InvoiceQueryRs_obj.getJSONArray("InvoiceRet");


            //System.out.println(jsonArray);
            for (int i = 0; i < jsonArray.length(); i++) {

                String tin = "124563ghrjjr";
                String ninBrn = "";
                String legalName = "TRUE NORTH CONSULT LTD";
                String businessName = "TRUE NORTH CONSULT LTD";
                String address = "Mengo 123";
                String mobilePhone = "0789354363";
                String linePhone = "";
                String emailAddress = "stephankasasa@gmail.com";
                String placeOfBusiness = "Kampala Road";
                String referenceNo = "123456789";
                String branchId = "4DHLNLNL";


                JSONObject invoiceObject = jsonArray.getJSONObject(i);

                System.out.println(invoiceObject);

                Integer invoiceNo = invoiceObject.getInt("RefNumber");
                String antifakeCode = "";
                String deviceNo = "123455667";
                String issuedDate = invoiceObject.getString("TimeCreated");
                String operator = "";

                JSONObject invoice_object = invoiceObject.getJSONObject("CurrencyRef");

                String currency = invoice_object.getString("FullName");
                String oriInvoiceId = "";
                String invoiceType = "";
                String invoiceKind = "";
                String dataSource = "";
                String invoiceIndustryCode = "";
                String isBatch = "";

                JSONObject customer_object = invoiceObject.getJSONObject("CustomerRef");

                String buyerTin = "1018167239";
                String buyerNinBrn = "";
                String buyerPassportNum = "";
                String buyerLegalName = "Nesscom Digital Solutions";
                //String buyerLegalName = customer_object.getString("FullName");
                String buyerBusinessName = "Nesscom Digital Solutions";
                String buyerAddress = "Kampala";
                String buyerEmail = "";
                String buyerMobilePhone = "";
                String buyerLinePhone = "010-";
                String buyerPlaceOfBusi = "";
                String buyerType = "";
                String buyerCitizenship = "";
                String buyerSector = "";
                String buyerReferenceNo = "";

                String buyerExtend = "";
                String propertyType = "";
                String district = "Kampala";
                String municipalityCounty = "";
                String divisionSubcounty = "";
                String town = "";
                String cellVillage = "";
                String effectiveRegistrationDate = "";
                String meterStatus = "";


                JSONObject line_ret = invoiceObject.getJSONObject("InvoiceLineRet");

                JSONObject ItemRef = line_ret.getJSONObject("InvoiceLineRet");

                String item = ItemRef.getString("FullName");
                String itemCode = "";
                String qty = line_ret.getString("Quantity");
                String unitOfMeasure = line_ret.getString("Unit");
                String unitPrice = line_ret.getString("Rate");
                String total = line_ret.getString("Amount");
                String taxRate = "";
                String tax = "";
                String discountTotal = "";
                String discountTaxRate = "";
                String orderNumber = "";
                String discountFlag = "";
                String deemedFlag = "";
                String exciseFlag = "";
                String categoryId = "";
                String categoryName = "";
                String goodsCategoryId = "";
                String goodsCategoryName = "";
                String exciseRate = "";
                String exciseRule = "";
                String exciseTax = "";
                String pack = "";
                String stick = "";
                String exciseUnit = "";
                String exciseCurrency = "";
                String exciseRateName = "";


                String taxCategoryCode = "";
                String netAmount = line_ret.getString("Amount");;
                //String taxRate = "";   Already defined in scope
                String taxAmount = line_ret.getString("SalesTaxTotal");

                String grossAmount = "";
                //String exciseUnit = "";   Already defined in scope
                //String exciseCurrency = ""; Already defined in scope


                JSONObject CustomerSalesTaxCodeRef = line_ret.getJSONObject("CustomerSalesTaxCodeRef");

                String taxRateName = CustomerSalesTaxCodeRef.getString("FullName");


//                String netAmount = "";
//                String taxAmount = "";
//                String grossAmount = "";
                String itemCount = "";
                String modeCode = "";
                String remarks = "";
                String qrCode = "";


                String paymentMode = "";
                String paymentAmount = "";
                // String orderNumber = "";


                String reason = "none";
                String reasonCode = "none";


                String importBusinessName = "";
                String importEmailAddress = "";
                String importContactNumber = "";
                String importAddress = "";
                String importInvoiceDate = "";
                String importAttachmentName = "";
                String importAttachmentContent = "";


                String content = "{\n" +
                        "\"sellerDetails\": {\n" +
                        "\"tin\":" + tin + "\n" +
                        "\"ninBrn\":" + ninBrn +  "\n" +
                        "\"legalName\":" + legalName + "\n" +
                        "\"businessName\":" + businessName + "n" +
                        "\"address\":" + address + "\n" +
                        "\"mobilePhone\":" + mobilePhone + "\n" +
                        "\"linePhone\":" + linePhone + "\n" +
                        "\"emailAddress\":" + emailAddress + "\n" +
                        "\"placeOfBusiness\":" + placeOfBusiness + "\n" +
                        "\"referenceNo\":" + referenceNo + "\n" +
                        "\"branchId\":" + branchId + "\n" +
                        "},\n" +
                        "\"basicInformation\": {\n" +
                        "\"invoiceNo\":" + invoiceNo + "\n" +
                        "\"antifakeCode\":" + antifakeCode + "\n" +
                        "\"deviceNo\":" + deviceNo + "\n" +
                        "\"issuedDate\":" + issuedDate + "\n" +
                        "\"operator\":" + operator + "\n" +
                        "\"currency\":" + currency + "\n" +
                        "\"oriInvoiceId\":" + oriInvoiceId + "\n" +
                        "\"invoiceType\":" + invoiceType + "\n" +
                        "\"invoiceKind\":" + invoiceKind + "\n" +
                        "\"dataSource\":" + dataSource + "\n" +
                        "\"invoiceIndustryCode\":" + invoiceIndustryCode + "\n" +
                        "\"isBatch\":" + isBatch + "\n" +
                        "},\n" +
                        "\"buyerDetails\": { //information from invoice \n" +
                        "\"buyerTin\":" + buyerTin + "\n" +
                        "\"buyerNinBrn\":" + buyerNinBrn + "\n" +
                        "\"buyerPassportNum\":" + buyerPassportNum + "\n" +
                        "\"buyerLegalName\":" + buyerLegalName + "\n" +
                        "\"buyerBusinessName\":" + buyerBusinessName + "\n" +
                        "\"buyerAddress\":" + buyerAddress + "\n" +
                        "\"buyerEmail\":" + buyerEmail + "\n" +
                        "\"buyerMobilePhone\":" + buyerMobilePhone + "\n" +
                        "\"buyerLinePhone\":" + buyerLinePhone + "\n" +
                        "\"buyerPlaceOfBusi\":" + buyerPlaceOfBusi + "\n" +
                        "\"buyerType\":" + buyerType + "\n" +
                        "\"buyerCitizenship\":" + buyerCitizenship + "\n" +
                        "\"buyerSector\":" + buyerSector + "\n" +
                        "\"buyerReferenceNo\":" + buyerReferenceNo + "\n" +
                        "},\n" +
                        "\"buyerExtend\": {\n" +
                        "\"propertyType\":" + propertyType + "\n" +
                        "\"district\":" + district + "\n" +
                        "\"municipalityCounty\":" + municipalityCounty + "\n" +
                        "\"divisionSubcounty\":" + divisionSubcounty + "\n" +
                        "\"town\":" + town + "\n" +
                        "\"cellVillage\":" + cellVillage + "\n" +
                        "\"effectiveRegistrationDate\":" + effectiveRegistrationDate + "\n" +
                        "\"meterStatus\":" + meterStatus + "\n" +
                        "},\n" +
                        "\"goodsDetails\": [{  // from invoice \n" +
                        "\"item\":" + item + "\n" +
                        "\"itemCode\":" + itemCode + "\n" +
                        "\"qty\":" + qty + "\n" +
                        "\"unitOfMeasure\":" + unitOfMeasure + "\n" +
                        "\"unitPrice\":" + unitPrice + "\n" +
                        "\"total\":" + total + "\n" +
                        "\"taxRate\":" + taxRate + "\n" +
                        "\"tax\":" + tax + "\n" +
                        "\"discountTotal\":" + discountTotal + "\n" +
                        "\"discountTaxRate\": " + discountTaxRate + "\n" +
                        "\"orderNumber\":" + orderNumber + "\n" +
                        "\"discountFlag\":" + discountFlag + "\n" +
                        "\"deemedFlag\":" + deemedFlag + "\n" +
                        "\"exciseFlag\":" + exciseFlag + "\n" +
                        "\"categoryId\":" + categoryId + "\n" +
                        "\"categoryName\":" + categoryName + "\n" +
                        "\"goodsCategoryId\":" + goodsCategoryId + "\n" +
                        "\"goodsCategoryName\":" + goodsCategoryName + "\n" +
                        "\"exciseRate\":" + exciseRate + "\n" +
                        "\"exciseRule\":" + exciseRule + "\n" +
                        "\"exciseTax\":" + exciseTax + "\n" +
                        "\"pack\":" + pack + "\n" +
                        "\"stick\":" + stick + "\n" +
                        "\"exciseUnit\":" + exciseUnit + "\n" +
                        "\"exciseCurrency\":" + exciseCurrency + "\n" +
                        "\"exciseRateName\":" + exciseRateName + "\n" +
                        "}],\n" +
                        "\"taxDetails\": [{\n" +
                        "\"taxCategoryCode\":" + taxCategoryCode + "\n" +
                        "\"netAmount\": " + netAmount + " \n" +
                        "\"taxRate\":" + taxRate + "\n" +
                        "\"taxAmount\":" + taxAmount + "\n" +
                        "\"grossAmount\":" + grossAmount + "\n" +
                        "\"exciseUnit\":" + exciseUnit + "\n" +
                        "\"exciseCurrency\":" + exciseCurrency + "\n" +
                        "\"taxRateName\":" + taxRateName + "\n" +
                        "}],\n" +
                        "\"summary\": {\n" +
                        "\"netAmount\":" + netAmount + "\n" +
                        "\"taxAmount\":" + taxAmount + "\n" +
                        "\"grossAmount\":" + grossAmount + "\n" +
                        "\"itemCount\":" + itemCount + "\n" +
                        "\"modeCode\":" + modeCode + "\n" +
                        "\"remarks\":" + remarks + "\n" +
                        "\"qrCode\":" + qrCode + "\n" +
                        "},\n" +
                        "\"payWay\": [{\n" +
                        "\"paymentMode\":" + paymentMode + "\n" +
                        "\"paymentAmount\":" + paymentAmount + "\n" +
                        "\"orderNumber\":" + orderNumber + "\n" +
                        "}],\n" +
                        "\"extend\": {\n" +
                        "\"reason\":" + reason + "\n" +
                        "\"reasonCode\":" + reasonCode + "\n" +
                        "},\n" +
                        "\"importServicesSeller\": {\n" +
                        "\"importBusinessName\":" + importBusinessName + "\n" +
                        "\"importEmailAddress\":" + importEmailAddress + "\n" +
                        "\"importContactNumber\":" + importContactNumber + "\n" +
                        "\"importAddress\":" + importAddress + "\n" +
                        "\"importInvoiceDate\":" + importInvoiceDate + "\n" +
                        "\"importAttachmentName\":" + importAttachmentName + "\n" +
                        "\"importAttachmentContent\":" + importAttachmentContent + "\n" +
                        "}\n" +
                        "}";


                System.out.println(content);

                String final_string = getBodyOuterData(content);

                String response = NetworkHelper.performPost(efris_url,final_string,"UTF-8");

                JSONObject efris_response_obj = new JSONObject(response);

                String response_qr_code = getQrCode(efris_response_obj);
                String response_invoice_no = getInvoiceNo(efris_response_obj);
                String response_antifake_code = getAntiFakeCode(efris_response_obj);


                String XMLRequest2 = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                        "<?qbxml version=\"13.0\"?>\n" +
                        "<QBXML>\n" +
                        "  <QBXMLMsgsRq onError=\"stopOnError\">\n" +
                        "    <InvoiceModRq requestID=\"" + UUID.randomUUID() + "\">\n" +
                        " \n" +
                        "     <InvoiceMod>\n" +
                        " \n" +
                        "       <TxnID>4-1656100688</TxnID>\n" +
                        " \n" +
                        "       <EditSequence>1656331197</EditSequence>\n" +
                        " \n" +
                        "       <CustomerRef>\n" +
                        " \n" +
                        "       <ListID>80000004-1656100078</ListID>\n" +
                        " \n" +
                        "       <FullName>isaac</FullName>\n" +
                        " \n" +
                        "       </CustomerRef>\n" +
                        " \n" +
                        "       <TxnDate>2022-06-24</TxnDate>\n" +
                        " \n" +
                        "       <RefNumber>1</RefNumber>\n" +
                        " \n" +
                        "       <InvoiceLineMod>\n" +
                        " \n" +
                        "       <TxnLineID>6-1656100688</TxnLineID>\n" +
                        " \n" +
                        "       <ItemRef>\n" +
                        " \n" +
                        "       <ListID>80000005-1656099817</ListID>\n" +
                        " \n" +
                        "       <FullName>Computer Networking</FullName>\n" +
                        " \n" +
                        "       </ItemRef>\n" +
                        " \n" +
                        "       <Quantity>3</Quantity>\n" +
                        " \n" +
                        "       </InvoiceLineMod>\n" +
                        " \n" +
                        "     </InvoiceMod></InvoiceModRq>\n" +
                        " \n" +
                        "  </QBXMLMsgsRq>\n" +
                        "</QBXML>";


//                String applicationName2 = "QB Sync Test";
//                Dispatch MySessionManager2 = new Dispatch("QBXMLRP2.RequestProcessor");
                Dispatch.call(MySessionManager, "OpenConnection2", appID, applicationName, QBPermissionMode);
                Variant ticket2 = Dispatch.call(MySessionManager, "BeginSession",fileLocation, QBaccessMode);
                Variant apiResponse2 = Dispatch.call(MySessionManager, "ProcessRequest", ticket2, XMLRequest2);
                System.out.println(final_string);

                try {

                    /** XML */
                    //System.out.println(apiResponse.toString());
                    JSONObject xmlJSONObj2 = XML.toJSONObject(apiResponse.toString());

                    /** JSON*/
                    String jsonPrettyPrintString2 = xmlJSONObj2.toString(PRETTY_PRINT_INDENT_FACTOR);
                    //System.out.println(jsonPrettyPrintString);

                    //System.out.println(jsonPrettyPrintString2);



                } catch (JSONException je) {
                    System.out.println(je.toString());
                }
            }

        } catch (JSONException je) {
            System.out.println(je.toString());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Dispatch.call(MySessionManager, "EndSession", ticket);
        Dispatch.call(MySessionManager, "CloseConnection");

    }

    private static String getBodyOuterData(String inner) {
        var innerInBase64 = Base64Helper.encode(inner);

        var current_date_time = getCurrentDateTime();

        String outer = "{\n" +
                "\"data\": {\n" +
                " \"content\": \""+innerInBase64+"\",\n" +
                " \"dataDescription\": {\n" +
                "   \"codeType\": \"0\",\n" +
                " \"encryptCode\": \"1\",\n" +
                " \"zipCode\": \"0\"\n" +
                " }\n" +
                " },\n" +
                " \"globalInfo\": {\n" +
                " \"appId\": \"AP01\",\n" +
                "\"version\": \"1.1.20191201\",\n" +
                " \"dataExchangeId\": \"9230489223014123\",\n" +
                " \"interfaceCode\": \"T109\",\n" +
                " \"requestCode\": \"TP\",\n" +
                " \"requestTime\": \""+current_date_time+"\",\n" +
                " \"responseCode\": \"TA\",\n" +
                " \"userName\": \"admin\",\n" +
                "\"deviceMAC\": \"FFFFFFFFFFFF\",\n" +
                " \"deviceNo\": \"TCS23f9cf2615872238\",\n" +
                " \"tin\": \"1001524099\",\n" +
                "\"brn\": \"\",\n" +
                "\"taxpayerID\": \"1\",\n" +
                "\"longitude\": \"116.397128\",\n" +
                "\"latitude\": \"39.916527\",\n" +
                "\"extendField\": {\n" +
                " \"responseDateFormat\": \"dd/MM/yyyy\",\n" +
                " \"responseTimeFormat\": \"dd/MM/yyyy HH:mm:ss\",\n" +
                " \"referenceNo\": \"21PL010020807\"\n" +
                "}\n" +
                " },\n" +
                " \"returnStateInfo\": {\n" +
                " \"returnCode\": \"\",\n" +
                " \"returnMessage\": \"\"\n" +
                " }\n" +
                "}";
        return outer;
    }

    private static String getCurrentDateTime() {
        return LocalDateTime.now().format( DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss") );
    }

    private static String getEfrisResponseFilePath() {
        return "C:\\Users\\MENGO SCHOOL\\IdeaProjects\\qbsync2\\src\\main\\java\\data_invoice_response_OUTTER_500.json";
    }

    private static String getQrCode(JSONObject content) {
        try {
            return content.getJSONObject("summary").getString("qrCode");
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    private static String getInvoiceNo(JSONObject content) {
        try {
            return content.getJSONObject("basicInformation").getString("invoiceNo");
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    private static String getAntiFakeCode(JSONObject content) {
        try {
            return content.getJSONObject("basicInformation").getString("antifakeCode");
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

}

