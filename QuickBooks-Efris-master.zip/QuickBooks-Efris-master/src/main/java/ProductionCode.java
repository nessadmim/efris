import com.jacob.com.Dispatch;
import com.jacob.com.Variant;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.UUID;

public class ProductionCode {

    public static boolean IS_PRODUCTION = false;

    public static String efris_url = "http://127.0.0.1:9880/efristcs/ws/tcsapp/getInformation/";

    /*COMPANY CONSTANT*/
    public static String tin = "1004107475";
    public static String ninBrn = "";
    public static String legalName = "THE ELMA PHILANTHROPIES SERVICES EAST AFRICA LTD";
    public static String businessName = "THE ELMA PHILANTHROPIES SERVICES EAST AFRICA LTD";
    public static String address = "10th Floor, DTB Building,Kampala Road,Kampala";
    public static String mobilePhone = "";
    public static String linePhone = "";
    public static String emailAddress = "stumwesigye@elmaphilanthropies.org";
    public static String placeOfBusiness = "";
    public static String referenceNo = "SOQ07";
    public static String branchId = "";
    public static String deviceNo = "TCS03b30b152974040";
    public static String operator = "Sarah Tumwesigye";

    public static void main(String[] args) {
        Variant QBPermissionMode = new Variant(1);
        Variant QBaccessMode = new Variant(2);

        String XMLRequest = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<?qbxml version=\"13.0\"?>\n" +
                "<QBXML>\n" +
                "  <QBXMLMsgsRq onError=\"stopOnError\">\n" +
                "    <InvoiceQueryRq requestID=\"" + UUID.randomUUID() + "\">\n" +
                "     <ModifiedDateRangeFilter>\n" +
                "       <FromModifiedDate>"+getCurrentDate(0)+"</FromModifiedDate>" +
                "       <ToModifiedDate>"+getCurrentDate(1)+"</ToModifiedDate>\n" +
                "     </ModifiedDateRangeFilter>" +
                "     <IncludeLineItems>true</IncludeLineItems>" +
                "   </InvoiceQueryRq>\n" +
                "  </QBXMLMsgsRq>\n" +
                "</QBXML>";

        String fileLocation = "";
        String appID = "";//not needed unless you want to set AppID
        String applicationName = "QB Sync Test";
        Dispatch MySessionManager = new Dispatch("QBXMLRP2.RequestProcessor");
        Dispatch.call(MySessionManager, "OpenConnection2", appID, applicationName, QBPermissionMode);
        Variant ticket = Dispatch.call(MySessionManager, "BeginSession",fileLocation, QBaccessMode);
        Variant apiResponse = Dispatch.call(MySessionManager, "ProcessRequest", ticket, XMLRequest);

        Dispatch.call(MySessionManager, "EndSession", ticket);
        Dispatch.call(MySessionManager, "CloseConnection");
        try {

            /** XML */
            //System.out.println(apiResponse.toString());
            JSONObject xmlJSONObj = XML.toJSONObject(apiResponse.toString());

            /** JSON*/
            String jsonPrettyPrintString = xmlJSONObj.toString(Connection.PRETTY_PRINT_INDENT_FACTOR);
            //System.out.println(jsonPrettyPrintString);

            /** JSON string to JSON obj*/
            JSONObject json = new JSONObject(jsonPrettyPrintString);
            System.out.println(json);

            JSONObject QBXML_obj = json.getJSONObject("QBXML");
            JSONObject QBXMLMsgsRs_obj = QBXML_obj.getJSONObject("QBXMLMsgsRs");
            JSONObject InvoiceQueryRs_obj = QBXMLMsgsRs_obj.getJSONObject("InvoiceQueryRs");

            if (!InvoiceQueryRs_obj.has("InvoiceRet")){
                //RUNS WHEN THERE ARE NO INVOICES
                System.err.println(InvoiceQueryRs_obj.getString("statusSeverity") + " | "+ InvoiceQueryRs_obj.getString("statusMessage"));
                return;
            }

            //JSON array of all invoices
            JSONArray jsonArray = new JSONArray();
            try {
                jsonArray = InvoiceQueryRs_obj.getJSONArray("InvoiceRet");
            }catch (JSONException e){
                jsonArray.put(InvoiceQueryRs_obj.getJSONObject("InvoiceRet"));
            }
            //System.out.println("Invoices Found: "+jsonArray.length());


            for (int i = 0; i < jsonArray.length(); i++) {


                JSONObject invoice = jsonArray.getJSONObject(i);

                JSONObject invoiceLine;
                try {
                    invoiceLine = invoice.getJSONObject("InvoiceLineRet");
                }catch(JSONException e){
                    invoiceLine = invoice.getJSONArray("InvoiceLineRet").getJSONObject(1);
                }

                JSONObject customerRef = invoice.getJSONObject("CustomerRef");
                JSONObject itemRef = invoiceLine.getJSONObject("ItemRef");

                //SALES TAX INFO
                JSONObject sales_tax_object = invoiceLine.getJSONObject("SalesTaxCodeRef");
                String sales_tax_id  = sales_tax_object.getString("ListID");
                String sales_tax_name  = sales_tax_object.getString("FullName");

                //System.out.println(">>>");

                //String time_created  = invoiceLine.getString("TimeCreated");
                String txn_line_id  = invoiceLine.getString("TxnLineID");
                String description  = invoiceLine.getString("Desc");


                //KEY INFO
                String currency = "USD";

                //TRANSACTION NUMBER (replaced the random string to avoid duplicates)
                String txnNumber = "";
                if (IS_PRODUCTION){
                    txnNumber = invoice.getInt("TxnNumber")+"";
                }else{
                    txnNumber = getAlphaNumericString(13);
                }


                //TAX INFORMATION
                String taxRate = "0";
                String tax = "00.00";
                String taxAmount = "0.00";
                String taxCategoryCode = "02";
                String taxRateName = "1";

                //AMOUNTS
                double qty = invoiceLine.getDouble("Quantity");
                double unitPrice = invoiceLine.getDouble("Rate");
                double total = invoiceLine.getDouble("Amount");
                double netAmount = total;
                double grossAmount = total;
                double paymentAmount = total;

                String unitOfMeasure = invoiceLine.getString("UnitOfMeasure");

                //ITEM
                String item = itemRef.getString("FullName");
                String itemCode = "002";

                //GOODS CATEGORY
                String categoryId = "80101601";
                String categoryName = "";
                String goodsCategoryId = "80101601";
                String goodsCategoryName = "";

                //OTHER
                String remarks = invoiceLine.getString("Desc");
                String paymentMode = "102";

                //BUYER
                String buyerLegalName = customerRef.getString("FullName");
                String buyerBusinessName = customerRef.getString("FullName");
                String buyerAddress = "Unknown";

                String invoiceNo = "";
                String antifakeCode = "";
                String issuedDate = formatTimeZoneDate(invoice.getString("TimeCreated"));

                String oriInvoiceId = "";
                String invoiceType = "1";
                String invoiceKind = "1";
                String dataSource = "101";
                String invoiceIndustryCode = "102";
                String isBatch = "0";

                String buyerTin = "";
                String buyerNinBrn = "";
                String buyerPassportNum = "";
                String buyerEmail = "";
                String buyerMobilePhone = "";
                String buyerLinePhone = "";
                String buyerPlaceOfBusi = "";
                String buyerType = "2";
                String buyerCitizenship = "";
                String buyerSector = "";
                String buyerReferenceNo = "";

                String propertyType = "";
                String district = "";
                String municipalityCounty = "";
                String divisionSubcounty = "";
                String town = "";
                String cellVillage = "";
                String effectiveRegistrationDate = "";
                String meterStatus = "";


                String discountTotal = "";
                String discountTaxRate = "";
                String orderNumber = "0";
                String discountFlag = "2";
                String deemedFlag = "2";
                String exciseFlag = "2";
                String exciseRate = "";
                String exciseRule = "";
                String exciseTax = "";
                String pack = "";
                String stick = "";
                String exciseUnit = "";
                String exciseCurrency = "";
                String exciseRateName = "";



                String itemCount = "1";
                String modeCode = "0";
                String qrCode = "";


                String reason = "";
                String reasonCode = "";

                String importBusinessName = "";
                String importEmailAddress = "";
                String importContactNumber = "";
                String importAddress = "";
                String importInvoiceDate = "";
                String importAttachmentName = "";
                String importAttachmentContent = "";
                String isCheckReferenceNo = "0";



                String content = "{\n" +
                        "\"sellerDetails\": {\n" +
                        "\"tin\":\"" + tin + "\",\n" +
                        "\"ninBrn\":\"" + ninBrn +  "\",\n" +
                        "\"legalName\":\"" + legalName + "\",\n" +
                        "\"businessName\":\"" + businessName + "\",\n" +
                        "\"address\":\"" + address + "\",\n" +
                        "\"mobilephone\":\"" + mobilePhone + "\",\n" +
                        "\"linephone\":\"" + linePhone + "\",\n" +
                        "\"emailaddress\":\"" + emailAddress + "\",\n" +
                        "\"placeOfBusiness\":\"" + placeOfBusiness + "\",\n" +
                        "\"referenceNo\":\"" + txnNumber + "\",\n" +
                        "\"branchId\":\"" + branchId + "\",\n" +
                        "\"isCheckReferenceNo\":\"" + isCheckReferenceNo + "\",\n" +
                        "},\n" +
                        "\"basicInformation\": {\n" +
                        "\"invoiceNo\":\"" + invoiceNo + "\",\n" +
                        "\"antifakeCode\":\"" + antifakeCode + "\",\n" +
                        "\"deviceNo\":\"" + deviceNo + "\",\n" +
                        "\"issuedDate\":\"" + issuedDate + "\",\n" +
                        "\"operator\":\"" + operator + "\",\n" +
                        "\"currency\":\"" + currency + "\",\n" +
                        "\"oriInvoiceId\":\"" + oriInvoiceId + "\",\n" +
                        "\"invoiceType\":\"" + invoiceType + "\",\n" +
                        "\"invoiceKind\":\"" + invoiceKind + "\",\n" +
                        "\"dataSource\":\"" + dataSource + "\",\n" +
                        "\"invoiceIndustryCode\":\"" + invoiceIndustryCode + "\",\n" +
                        "\"isBatch\":\"" + isBatch + "\",\n" +
                        "},\n" +
                        "\"buyerDetails\": {  \n" +
                        "\"buyerTin\":\"" + buyerTin + "\",\n" +
                        "\"buyerNinBrn\":\"" + buyerNinBrn + "\",\n" +
                        "\"buyerPassportNum\":\"" + buyerPassportNum + "\",\n" +
                        "\"buyerLegalName\":\"" + buyerLegalName + "\",\n" +
                        "\"buyerBusinessName\":\"" + buyerBusinessName + "\",\n" +
                        "\"buyerAddress\":\"" + buyerAddress + "\",\n" +
                        "\"buyerEmail\":\"" + buyerEmail + "\",\n" +
                        "\"buyerMobilePhone\":\"" + buyerMobilePhone + "\",\n" +
                        "\"buyerLinePhone\":\"" + buyerLinePhone + "\",\n" +
                        "\"buyerPlaceOfBusi\":\"" + buyerPlaceOfBusi + "\",\n" +
                        "\"buyerType\":\"" + buyerType + "\",\n" +
                        "\"buyerCitizenship\":\"" + buyerCitizenship + "\",\n" +
                        "\"buyerSector\":\"" + buyerSector + "\",\n" +
                        "\"buyerReferenceNo\":\"" + buyerReferenceNo + "\",\n" +
                        "},\n" +
                        "\"buyerExtend\": {\n" +
                        "\"propertyType\":\"" + propertyType + "\",\n" +
                        "\"district\":\"" + district + "\",\n" +
                        "\"municipalityCounty\":\"" + municipalityCounty + "\",\n" +
                        "\"divisionSubcounty\":\"" + divisionSubcounty + "\",\n" +
                        "\"town\":\"" + town + "\",\n" +
                        "\"cellVillage\":\"" + cellVillage + "\",\n" +
                        "\"effectiveRegistrationDate\":\"" + effectiveRegistrationDate + "\",\n" +
                        "\"meterStatus\":\"" + meterStatus + "\",\n" +
                        "},\n" +
                        "\"goodsDetails\": [{   \n" +
                        "\"item\":\"" + item + "\",\n" +
                        "\"itemCode\":\"" + itemCode + "\",\n" +
                        "\"qty\":\"" + qty + "\",\n" +
                        "\"unitOfMeasure\":\"" + unitOfMeasure + "\",\n" +
                        "\"unitPrice\":\"" + unitPrice + "\",\n" +
                        "\"total\":\"" + total + "\",\n" +
                        "\"taxRate\":\"" + taxRate + "\",\n" +
                        "\"tax\":\"" + tax + "\",\n" +
                        "\"discountTotal\":\"" + discountTotal + "\",\n" +
                        "\"discountTaxRate\":\"" + discountTaxRate + "\",\n" +
                        "\"orderNumber\":\"" + orderNumber + "\",\n" +
                        "\"discountFlag\":\"" + discountFlag + "\",\n" +
                        "\"deemedFlag\":\"" + deemedFlag + "\",\n" +
                        "\"exciseFlag\":\"" + exciseFlag + "\",\n" +
                        "\"categoryId\":\"" + categoryId + "\",\n" +
                        "\"categoryName\":\"" + categoryName + "\",\n" +
                        "\"goodsCategoryId\":\"" + goodsCategoryId + "\",\n" +
                        "\"goodsCategoryName\":\"" + goodsCategoryName + "\",\n" +
                        "\"exciseRate\":\"" + exciseRate + "\",\n" +
                        "\"exciseRule\":\"" + exciseRule + "\",\n" +
                        "\"exciseTax\":\"" + exciseTax + "\",\n" +
                        "\"pack\":\"" + pack + "\",\n" +
                        "\"stick\":\"" + stick + "\",\n" +
                        "\"exciseUnit\":\"" + exciseUnit + "\",\n" +
                        "\"exciseCurrency\":\"" + exciseCurrency + "\",\n" +
                        "\"exciseRateName\":\"" + exciseRateName + "\",\n" +
                        "}],\n" +
                        "\"taxDetails\": [{\n" +
                        "\"taxCategoryCode\":\"" + taxCategoryCode + "\",\n" +
                        "\"netAmount\":\"" + netAmount + "\",\n" +
                        "\"taxRate\":\"" + taxRate + "\",\n" +
                        "\"taxAmount\":\"" + taxAmount + "\",\n" +
                        "\"grossAmount\":\"" + grossAmount + "\",\n" +
                        "\"exciseUnit\":\"" + exciseUnit + "\",\n" +
                        "\"exciseCurrency\":\"" + exciseCurrency + "\",\n" +
                        "\"taxRateName\":\"" + taxRateName + "\",\n" +
                        "}],\n" +
                        "\"summary\": {\n" +
                        "\"netAmount\":\"" + netAmount + "\",\n" +
                        "\"taxAmount\":\"" + taxAmount + "\",\n" +
                        "\"grossAmount\":\"" + grossAmount + "\",\n" +
                        "\"itemCount\":\"" + itemCount + "\",\n" +
                        "\"modeCode\":\"" + modeCode + "\",\n" +
                        "\"remarks\":\"" + remarks + "\",\n" +
                        "\"qrCode\":\"" + qrCode + "\",\n" +
                        "},\n" +
                        "\"payWay\": [{\n" +
                        "\"paymentMode\":\"" + paymentMode + "\",\n" +
                        "\"paymentAmount\":\"" + paymentAmount + "\",\n" +
                        "\"orderNumber\":\"" + orderNumber + "\",\n" +
                        "}],\n" +
                        "\"extend\": {\n" +
                        "\"reason\":\"" + reason + "\",\n" +
                        "\"reasonCode\":\"" + reasonCode + "\",\n" +
                        "},\n" +
                        "\"importServicesSeller\": {\n" +
                        "\"importBusinessName\":\"" + importBusinessName + "\",\n" +
                        "\"importEmailAddress\":\"" + importEmailAddress + "\",\n" +
                        "\"importContactNumber\":\"" + importContactNumber + "\",\n" +
                        "\"importAddress\":\"" + importAddress + "\",\n" +
                        "\"importInvoiceDate\":\"" + importInvoiceDate + "\",\n" +
                        "\"importAttachmentName\":\"" + importAttachmentName + "\",\n" +
                        "\"importAttachmentContent\":\"" + importAttachmentContent + "\",\n" +
                        "}\n" +
                        "}";

                //System.out.println(content);

                String final_string = getBodyOuterData(content);

                String response = NetworkHelper.performPost(efris_url,final_string,"UTF-8");
                //System.out.println(response);

                //get json obj
                JSONObject obj = getJsonObject(response);

                //check the return code
                Boolean isSuccess = checkIfRequestWasSuccessful(txnNumber,obj);

                if (isSuccess){

                    String encrypted_content = getEncryptedResponseContent(obj);

                    JSONObject content2 = getContentObject(encrypted_content);

                    String efrisAntifakeCode = getAntiFakeCode(content2);
                    long efrisInvoiceNo = getInvoiceNo(content2);
                    String efrisQrCode = getQrCode(content2);

                    System.out.println("Invoice No: "+efrisInvoiceNo);
                    System.out.println("AntiFakeCode: "+efrisAntifakeCode);
                    System.out.println("QRCode: "+efrisQrCode);
                    saveLocalActionCopy(txnNumber, efrisInvoiceNo, efrisQrCode, efrisAntifakeCode, "",invoice);


                    try {

                            String txn_id = invoice.getString("TxnID");
                            Integer edit_sequence = invoice.getInt("EditSequence");
                            String customer_list_id = customerRef.getString("ListID");
                            String customer_full_name = customerRef.getString("FullName");
                            String ref_number = String.valueOf(invoice.getInt("RefNumber"));

                            JSONObject xmlJSONObj2 = updateInvoiceNo(edit_sequence,customer_list_id, customer_full_name,ref_number, efrisInvoiceNo, efrisAntifakeCode,
                                    efrisQrCode, sales_tax_id, sales_tax_name, txn_line_id, txn_id);
                            //Integer edit_sequence2 = getNewInvoiceEditSequence(txn_id);
                            //JSONObject xmlJSONObj3 = updateQrCode(edit_sequence2,customer_list_id, customer_full_name,ref_number, efrisInvoiceNo, efrisAntifakeCode,efrisQrCode, sales_tax_id, sales_tax_name, txn_line_id, txn_id, description);
                            Integer edit_sequence3 = getNewInvoiceEditSequence(txn_id);
                            JSONObject xmlJSONObj4 = updateAntiFake(edit_sequence3,customer_list_id, customer_full_name,ref_number, efrisInvoiceNo, efrisAntifakeCode,efrisQrCode, sales_tax_id, sales_tax_name, txn_line_id, txn_id);

                                /** JSON*/
                                String jsonPrettyPrintString2 = xmlJSONObj2.toString(Connection.PRETTY_PRINT_INDENT_FACTOR);

                                //System.out.println(jsonPrettyPrintString2);

                        }catch (Exception je) {
                            //System.out.println(je.toString());
                        }
                    }




                /*ENDED HERE*/
            }









        } catch (JSONException je) {
            System.out.println(je.toString());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

//        Dispatch.call(MySessionManager, "EndSession", ticket);
//        Dispatch.call(MySessionManager, "CloseConnection");


        }

    private static JSONObject getJsonObject(String json) {
        try {
            JSONObject jsObject = new JSONObject(json);
            return jsObject;
        } catch (JSONException e) {
            System.err.println("getJson");
            throw new RuntimeException(e);
        }
    }


    private static Integer getNewInvoiceEditSequence(String TxnId) throws JSONException {


        /*UPDATE THE INVO*/
        String XMLRequest = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<?qbxml version=\"13.0\"?>\n" +
                "<QBXML>\n" +
                "  <QBXMLMsgsRq onError=\"stopOnError\">\n" +
                "    <InvoiceQueryRq requestID=\"" + UUID.randomUUID() + "\">\n" +
                "       <TxnID>" + TxnId + "</TxnID>\n" +
                "     </InvoiceQueryRq>\n" +
                "  </QBXMLMsgsRq>\n" +
                "</QBXML>";

        Variant QBPermissionMode = new Variant(1);
        Variant QBaccessMode = new Variant(2);

        String fileLocation = "";
        String appID = "";//not needed unless you want to set AppID
        String applicationName = "QB Sync Test";
        Dispatch MySessionManager = new Dispatch("QBXMLRP2.RequestProcessor");

        Dispatch.call(MySessionManager, "OpenConnection2", appID, applicationName, QBPermissionMode);
        Variant ticket = Dispatch.call(MySessionManager, "BeginSession",fileLocation, QBaccessMode);
        Variant apiResponse = Dispatch.call(MySessionManager, "ProcessRequest", ticket, XMLRequest);

        Dispatch.call(MySessionManager, "EndSession", ticket);
        Dispatch.call(MySessionManager, "CloseConnection");



        /** XML */
        JSONObject xmlJSONObj2 = XML.toJSONObject(apiResponse.toString());

        //System.out.println(xmlJSONObj2);

        JSONObject QBXML_obj = xmlJSONObj2.getJSONObject("QBXML");
        JSONObject QBXMLMsgsRs_obj = QBXML_obj.getJSONObject("QBXMLMsgsRs");
        JSONObject InvoiceQueryRs_obj = QBXMLMsgsRs_obj.getJSONObject("InvoiceQueryRs");
        JSONObject invoice_obj = InvoiceQueryRs_obj.getJSONObject("InvoiceRet");

        Integer editSequence = invoice_obj.getInt("EditSequence");
        return editSequence;
    }

    private static JSONObject updateInvoiceNo(Integer edit_sequence, String customer_list_id, String customer_full_name,
                                       String ref_number, long efrisInvoiceNo, String efrisAntifakeCode, String efrisQrCode,
                                            String sales_tax_id, String sales_tax_name, String txn_line_id, String txn_id) throws JSONException {
        /*UPDATE THE INVO*/
        String XMLRequest = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<?qbxml version=\"13.0\"?>\n" +
                "<QBXML>\n" +
                "  <QBXMLMsgsRq onError=\"stopOnError\">\n" +
                "    <InvoiceModRq requestID=\"" + UUID.randomUUID() + "\">\n" +
                "     <InvoiceMod>\n" +
                "       <TxnID>" + txn_id + "</TxnID>\n" +
                "       <EditSequence>" + edit_sequence + "</EditSequence>\n" +
                "       <CustomerRef>\n" +
                "          <ListID>" + customer_list_id + "</ListID>\n" +
                "          <FullName>" + customer_full_name + "</FullName>\n" +
                "       </CustomerRef>\n" +
                "       <Other >"+efrisAntifakeCode+"</Other>"+
                //"       <FOB >"+efrisInvoiceNo+"</FOB>"+
                //"       <PONumber >"+efrisInvoiceNo+"</PONumber>"+
                //"       <InvoiceLineMod>\n" +
                //"             <TxnLineID>" + txn_line_id + "</TxnLineID>\n" +
                //"             <Other1>" + efrisInvoiceNo + "</Other1>\n" +
                //"       </InvoiceLineMod>\n" +
                "     </InvoiceMod></InvoiceModRq>\n" +
                "  </QBXMLMsgsRq>\n" +
                "</QBXML>";

        Variant QBPermissionMode = new Variant(1);
        Variant QBaccessMode = new Variant(2);

        String fileLocation = "";
        String appID = "";//not needed unless you want to set AppID
        String applicationName = "QB Sync Test";
        Dispatch MySessionManager = new Dispatch("QBXMLRP2.RequestProcessor");

        Dispatch.call(MySessionManager, "OpenConnection2", appID, applicationName, QBPermissionMode);
        Variant ticket = Dispatch.call(MySessionManager, "BeginSession",fileLocation, QBaccessMode);
        Variant apiResponse = Dispatch.call(MySessionManager, "ProcessRequest", ticket, XMLRequest);

        Dispatch.call(MySessionManager, "EndSession", ticket);
        Dispatch.call(MySessionManager, "CloseConnection");



        /** XML */
        JSONObject xmlJSONObj2 = XML.toJSONObject(apiResponse.toString());
        return xmlJSONObj2;
    }


    private static JSONObject updateQrCode(Integer edit_sequence, String customer_list_id, String customer_full_name,
                                              String ref_number, long efrisInvoiceNo, String efrisAntifakeCode, String efrisQrCode,
                                              String sales_tax_id, String sales_tax_name, String txn_line_id, String txn_id, String description) throws JSONException, IOException {
        /*UPDATE THE INVO*/

//        URL url = new URL("https://i.ibb.co/f9G4hMx/IMG-20220624-WA0004.jpg");
//        Image image = ImageIO.read(url);

        String XMLRequest = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<?qbxml version=\"13.0\"?>\n" +
                "<QBXML>\n" +
                "  <QBXMLMsgsRq onError=\"stopOnError\">\n" +
                "    <InvoiceModRq requestID=\"" + UUID.randomUUID() + "\">\n" +
                "     <InvoiceMod>\n" +
                "       <TxnID>" + txn_id + "</TxnID>\n" +
                "       <EditSequence>" + edit_sequence + "</EditSequence>\n" +
                "       <CustomerRef>\n" +
                "          <ListID>" + customer_list_id + "</ListID>\n" +
                "          <FullName>" + customer_full_name + "</FullName>\n" +
                "       </CustomerRef>\n" +
                "       <InvoiceLineMod>\n" +
                "             <TxnLineID>" + txn_line_id + "</TxnLineID>\n" +
                "               <Desc>" + description + "\n QrCode: " + efrisQrCode + "</Desc>\n" +
                "       </InvoiceLineMod>\n" +
                "     </InvoiceMod></InvoiceModRq>\n" +
                "  </QBXMLMsgsRq>\n" +
                "</QBXML>";

        Variant QBPermissionMode = new Variant(1);
        Variant QBaccessMode = new Variant(2);

        String fileLocation = "";
        String appID = "";//not needed unless you want to set AppID
        String applicationName = "QB Sync Test";
        Dispatch MySessionManager = new Dispatch("QBXMLRP2.RequestProcessor");

        Dispatch.call(MySessionManager, "OpenConnection2", appID, applicationName, QBPermissionMode);
        Variant ticket = Dispatch.call(MySessionManager, "BeginSession",fileLocation, QBaccessMode);
        Variant apiResponse = Dispatch.call(MySessionManager, "ProcessRequest", ticket, XMLRequest);

        Dispatch.call(MySessionManager, "EndSession", ticket);
        Dispatch.call(MySessionManager, "CloseConnection");



        /** XML */
        JSONObject xmlJSONObj2 = XML.toJSONObject(apiResponse.toString());
        return xmlJSONObj2;
    }


    private static JSONObject updateAntiFake(Integer edit_sequence, String customer_list_id, String customer_full_name,
                                              String ref_number, long efrisInvoiceNo, String efrisAntifakeCode, String efrisQrCode,
                                              String sales_tax_id, String sales_tax_name, String txn_line_id, String txn_id) throws JSONException {
        /*UPDATE THE INVO*/
        String XMLRequest = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "<?qbxml version=\"13.0\"?>\n" +
                "<QBXML>\n" +
                "  <QBXMLMsgsRq onError=\"stopOnError\">\n" +
                "    <InvoiceModRq requestID=\"" + UUID.randomUUID() + "\">\n" +
                "     <InvoiceMod>\n" +
                "       <TxnID>" + txn_id + "</TxnID>\n" +
                "       <EditSequence>" + edit_sequence + "</EditSequence>\n" +
                "       <CustomerRef>\n" +
                "          <ListID>" + customer_list_id + "</ListID>\n" +
                "          <FullName>" + customer_full_name + "</FullName>\n" +
                "       </CustomerRef>\n" +
                "       <FOB >"+efrisInvoiceNo+"</FOB>"+
                //"       <InvoiceLineMod>\n" +
                //"             <TxnLineID>" + txn_line_id + "</TxnLineID>\n" +
                //"             <Other2>" + efrisAntifakeCode + "</Other2>\n" +
                //"       </InvoiceLineMod>\n" +
                "     </InvoiceMod></InvoiceModRq>\n" +
                "  </QBXMLMsgsRq>\n" +
                "</QBXML>";

        Variant QBPermissionMode = new Variant(1);
        Variant QBaccessMode = new Variant(2);

        String fileLocation = "";
        String appID = "";//not needed unless you want to set AppID
        String applicationName = "QB Sync Test";
        Dispatch MySessionManager = new Dispatch("QBXMLRP2.RequestProcessor");

        Dispatch.call(MySessionManager, "OpenConnection2", appID, applicationName, QBPermissionMode);
        Variant ticket = Dispatch.call(MySessionManager, "BeginSession",fileLocation, QBaccessMode);
        Variant apiResponse = Dispatch.call(MySessionManager, "ProcessRequest", ticket, XMLRequest);

        Dispatch.call(MySessionManager, "EndSession", ticket);
        Dispatch.call(MySessionManager, "CloseConnection");



        /** XML */
        JSONObject xmlJSONObj2 = XML.toJSONObject(apiResponse.toString());
        return xmlJSONObj2;
    }

    public static String formatTimeZoneDate(String dt){
        ZonedDateTime dtt = ZonedDateTime.parse(dt);
        return (dtt.format( DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss") ));
    }

    private static String getBodyOuterData(String inner) {
        var innerInBase64 = Base64Helper.encode(inner);

        Integer num_set = 13;

        String randomString = getAlphaNumericString(num_set);

        String outer = "{\n" +
                "\"data\": {\n" +
                " \"content\": \""+innerInBase64+"\",\n" +
                " \"dataDescription\": {\n" +
                "   \"codeType\": \"0\",\n" +
                " \"encryptCode\": \"1\",\n" +
                " \"zipCode\": \"0\"\n" +
                " }\n" +
                " },\n" +
                " \"globalInfo\": {\n" +
                " \"appId\": \"AP01\",\n" +
                "\"version\": \"1.1.20191201\",\n" +
                " \"dataExchangeId\": \"9230489223014123\",\n" +
                " \"interfaceCode\": \"T109\",\n" +
                " \"requestCode\": \"TP\",\n" +
                " \"requestTime\": \""+getCurrentDateTime()+"\",\n" +
                " \"responseCode\": \"TA\",\n" +
                " \"userName\": \"admin\",\n" +
                "\"deviceMAC\": \"FFFFFFFFFFFF\",\n" +
                " \"deviceNo\": \""+deviceNo+"\",\n" +
                " \"tin\": \""+tin+"\",\n" +
                "\"brn\": \"\",\n" +
                "\"taxpayerID\": \"1\",\n" +
                "\"longitude\": \"116.397128\",\n" +
                "\"latitude\": \"39.916527\",\n" +
                "\"extendField\": {\n" +
                " \"responseDateFormat\": \"dd/MM/yyyy\",\n" +
                " \"responseTimeFormat\": \"dd/MM/yyyy HH:mm:ss\",\n" +
                " \"referenceNo\": \"" + randomString + "\"\n" +
                "}\n" +
                " },\n" +
                " \"returnStateInfo\": {\n" +
                " \"returnCode\": \"\", \n" +
                " \"returnMessage\": \"\"\n" +
                " }\n" +
                "}";

        return outer;
    }


    private static String getAlphaNumericString(int n)
    {

        // chose a Character random from this String
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                + "0123456789"
                + "abcdefghijklmnopqrstuvxyz";

        // create StringBuffer size of AlphaNumericString
        StringBuilder sb = new StringBuilder(n);

        for (int i = 0; i < n; i++) {

            // generate a random number between
            // 0 to AlphaNumericString variable length
            int index
                    = (int)(AlphaNumericString.length()
                    * Math.random());

            // add Character one by one in end of sb
            sb.append(AlphaNumericString
                    .charAt(index));
        }

        return sb.toString();
    }

    private static String getCurrentDateTime() {
        return LocalDateTime.now().format( DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss") );
    }
    private static String getCurrentDate(int plusDays) {
        return LocalDateTime.now().plusDays(plusDays).format( DateTimeFormatter.ofPattern("yyyy-MM-dd") );
    }


    private static String getQrCode(JSONObject content) {
        try {
            return content.getJSONObject("summary").getString("qrCode");
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }


    private static JSONObject getContentObject(String encrypted_content) {
        try {
            return new JSONObject( Base64Helper.decode(encrypted_content) );
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    private static String getEncryptedResponseContent(JSONObject obj) {
        try {
            return obj.getJSONObject("data").getString("content");
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    private static Boolean checkIfRequestWasSuccessful(String txnNumber, JSONObject obj) {
        try {
            JSONObject jj = obj.getJSONObject("returnStateInfo");
            String returnCode = jj.getString("returnCode");
            String returnMessage = jj.getString("returnMessage");

            System.err.println(returnMessage);

            boolean isSure = Objects.equals(returnCode, "00");

            if (!isSure)
                saveLocalActionError(txnNumber, 0, "", "", returnMessage);

            return isSure;

        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    private static Long getInvoiceNo(JSONObject content) {
        try {
            return content.getJSONObject("basicInformation").getLong("invoiceNo");
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    private static void saveLocalActionCopy(String txnNumber, long invoiceNo, String qrCode, String antiFakeCode, String comment, JSONObject invoice) {
        try(FileWriter fw = new FileWriter("submitted_invoices.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw))
        {
            out.println("{\"txnNumber\":\""+txnNumber+"\",\"invoiceNo\":\""+invoiceNo+"\",\"qrCode\":\""+qrCode+"\",\"antiFakeCode\":\""+antiFakeCode+"\",\"comment\":\""+comment+"\",\"invoice\":"+invoice.toString()+"},");

        } catch (IOException e) {
            //exception handling left as an exercise for the reader
        }
    }
    private static void saveLocalActionError(String txnNumber, long invoiceNo, String qrCode, String antiFakeCode, String comment) {
        try(FileWriter fw = new FileWriter("submitted_invoices_error.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw))
        {
            out.println("{\"txnNumber\":\""+txnNumber+"\",\"invoiceNo\":\""+invoiceNo+"\",\"qrCode\":\""+qrCode+"\",\"antiFakeCode\":\""+antiFakeCode+"\",\"comment\":\""+comment+"\"},");

        } catch (IOException e) {
            //exception handling left as an exercise for the reader
        }
    }
    private static String getAntiFakeCode(JSONObject content) {
        try {
            return content.getJSONObject("basicInformation").getString("antifakeCode");
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }
}
