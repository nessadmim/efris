package com.cdtcl.ogmous.models

data class AccountResponse(
    val status_code: Int,
    val status_message: String,
    val user: Person?
)