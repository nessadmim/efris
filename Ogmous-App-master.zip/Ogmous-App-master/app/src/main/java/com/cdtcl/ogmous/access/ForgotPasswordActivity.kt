package com.cdtcl.ogmous.access

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Log
import android.util.Patterns
import android.view.MenuItem
import android.widget.Toast
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.StringRequestListener
import com.cdtcl.ogmous.HomeActivity
import com.cdtcl.ogmous.databinding.ActivityForgotPasswordBinding
import com.cdtcl.ogmous.models.LoginResponse
import com.cdtcl.ogmous.network.NetworkClient
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import dmax.dialog.SpotsDialog

class ForgotPasswordActivity : AppCompatActivity() {

    private var spotDialog: AlertDialog? = null
    private lateinit var binding: ActivityForgotPasswordBinding

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home){
            finish()
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityForgotPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        spotDialog = SpotsDialog.Builder().setContext(this).build()

        supportActionBar?.title = "Forgot Password"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding.buttonCheckEmail.setOnClickListener {
            checkEmail()
        }

        binding.emailAddress.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun afterTextChanged(p0: Editable?) {
                binding.emailAddress.setTextColor(if (isValidEmail(p0.toString())) Color.BLACK else Color.RED)
            }
        })

    }


    fun isValidEmail(target: CharSequence?): Boolean {
        return if (TextUtils.isEmpty(target)) {
            false
        } else {
            Patterns.EMAIL_ADDRESS.matcher(target).matches()
        }
    }

    private val TAG = "ForgotPasswordActivity"
    private fun checkEmail() {

        if (!isValidEmail(binding.emailAddress.text)){
            Toast.makeText(this, "Please Enter a valid Email Address", Toast.LENGTH_LONG).show()
            return
        }


        spotDialog?.show()
        AndroidNetworking.post("${NetworkClient.baseUrl}forgot_password_check")
            .addBodyParameter("email_address",binding.emailAddress.text.toString())
            .build()
            .getAsString(object : StringRequestListener {
                override fun onResponse(response: String?) {

                    spotDialog?.dismiss()
                    Log.d(TAG, "onResponse: $response")

                    val nrf = Gson().fromJson(response, LoginResponse::class.java)
                    if (nrf.status_code==200){
                        //Sent
                        MaterialAlertDialogBuilder(this@ForgotPasswordActivity)
                            .setMessage(nrf.status_message)
                            .setPositiveButton("OK"){c,v->
                                finish()
                            }
                            .create()
                            .show()
                    }else{
                        //failed
                        MaterialAlertDialogBuilder(this@ForgotPasswordActivity)
                            .setMessage(nrf.status_message)
                            .setPositiveButton("OK",null)
                            .create()
                            .show()

                    }

                    Toast.makeText(this@ForgotPasswordActivity, nrf.status_message, Toast.LENGTH_SHORT).show()
                }

                override fun onError(anError: ANError?) {
                    Log.d(TAG, "onError: ${anError?.errorBody}")
                    Log.d(TAG, "onError: ${anError?.errorCode}")
                    Log.d(TAG, "onError: ${anError?.errorDetail}")

                    spotDialog?.dismiss()
                    Toast.makeText(this@ForgotPasswordActivity, "No Internet", Toast.LENGTH_SHORT).show()
                }
            })

    }
}