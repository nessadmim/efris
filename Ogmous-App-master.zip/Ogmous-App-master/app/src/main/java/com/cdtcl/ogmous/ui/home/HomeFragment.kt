package com.cdtcl.ogmous.ui.home

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.cdtcl.ogmous.R
import com.cdtcl.ogmous.databinding.FragmentHomeBinding
import com.cdtcl.ogmous.databinding.RowHomeBinding
import com.cdtcl.ogmous.models.Person
import com.cdtcl.ogmous.network.NetworkClient
import com.cdtcl.ogmous.storage.AppPreferences
import com.squareup.picasso.Picasso

class HomeFragment : Fragment() {

    private var person: Person? = null
    private lateinit var appPreferences: AppPreferences
    private lateinit var homeViewModel: HomeViewModel
    private var _binding: FragmentHomeBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        homeViewModel = ViewModelProvider(this).get(HomeViewModel::class.java)

        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        appPreferences = AppPreferences(requireContext())
        person = appPreferences.getPerson()

        binding.name.text = person?.name
        binding.company.text = person?.office_people?.first()?.office?.name
        binding.supervisorName.text = person?.office_people?.first()?.office?.supervisor?.name
        binding.supervisorEmail.text = person?.office_people?.first()?.office?.supervisor?.email
        val url = "${NetworkClient.domain}/profile/${person?.picture}"
        Picasso.get().load(url).placeholder(R.drawable.avatar).centerCrop().fit().into(binding.picture)

        binding.sendEmailToSupervisor.setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO)
            intent.data = Uri.parse("mailto:")
            intent.putExtra(Intent.EXTRA_EMAIL, arrayOf(person?.office_people?.first()?.office?.supervisor?.email))
            intent.putExtra(Intent.EXTRA_SUBJECT, "RE: From ${person?.name}")
            intent.putExtra(Intent.EXTRA_TEXT, "Hello," )
            requireContext().startActivity(intent)
        }

        val adapter = HomeAdapter(requireContext(), mutableListOf(
            Home(1,"Check In",R.drawable.icons8_enter_96px),
            Home(2,"Check Out",R.drawable.icons8_logout_96px),
            Home(3,"Leave",R.drawable.icons8_to_go_96px),
            Home(4,"Overtime",R.drawable.icons8_time_96px),
            Home(5,"Notes",R.drawable.icons8_note_96px),
        ))
        binding.rvHome.adapter = adapter


        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

class HomeAdapter(val context: Context, var list: MutableList<Home>)
    : RecyclerView.Adapter<HomeAdapter.HomeHolder>() {

    inner class HomeHolder(val binding : RowHomeBinding)
        : RecyclerView.ViewHolder(binding.root) {
        fun displayViews(obj: Home) {
            binding.name.text = obj.name
            binding.drawable.setImageResource(obj.drawable)
            binding.root.setOnClickListener {
                when(obj.id){
                    1->{//check in
                            context.startActivity(Intent(context,CheckInActivity::class.java))
                        }
                    2->{//check out
                            context.startActivity(Intent(context,CheckOutActivity::class.java))
                    }
                    3->{
                        //Leave
                        context.startActivity(Intent(context,LeaveRequestActivity::class.java))
                    }
                    4->{
                        //overtime
                        context.startActivity(Intent(context,OvertimesActivity::class.java))
                    }
                    5->{
                        //overtime
                        context.startActivity(Intent(context,NotesActivity::class.java))
                    }
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeHolder {
        return HomeHolder(RowHomeBinding.inflate(LayoutInflater.from(context),parent,false))
    }

    override fun onBindViewHolder(holder: HomeHolder, position: Int) {
        holder.displayViews(list[position])
    }

    override fun getItemCount(): Int = list.size
}