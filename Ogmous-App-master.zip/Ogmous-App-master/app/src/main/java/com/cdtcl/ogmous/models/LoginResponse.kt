package com.cdtcl.ogmous.models

data class LoginResponse(
    val person: Person?,
    val status_code: Int,
    val status_message: String
)