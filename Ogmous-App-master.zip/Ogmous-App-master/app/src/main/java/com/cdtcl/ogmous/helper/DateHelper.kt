package com.cdtcl.ogmous.helper

import org.joda.time.DateTime

import org.joda.time.format.DateTimeFormat
import org.joda.time.format.DateTimeFormatter
import java.text.SimpleDateFormat
import java.util.*


class DateHelper {
    fun formatNow(): String? {
        val today: DateTime = DateTime.now()
        val DATE_FORMAT: DateTimeFormatter =
            DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss") //Default format
        var SIMPLE_DATE_FORMAT: SimpleDateFormat? = null
        val SIMPLE_DATE_FORMAT_TODAY =
            SimpleDateFormat("h:mm a", Locale.getDefault()) //Needed format
        val SIMPLE_DATE_FORMAT_YESTERDAY =
            SimpleDateFormat("MMM,d h:mma", Locale.getDefault()) //Needed format
        val SIMPLE_DATE_FORMAT_BEFORE =
            SimpleDateFormat("M/d/yy", Locale.getDefault()) //Needed format
        val chatDateTime: DateTime = DateTime.now()
        if (chatDateTime.toLocalDate() == today.toLocalDate()) {
            //is today
            SIMPLE_DATE_FORMAT = SIMPLE_DATE_FORMAT_TODAY
        } else if (chatDateTime.toLocalDate() == today.minusDays(1).toLocalDate()) {
            //is yesterday
            SIMPLE_DATE_FORMAT = SIMPLE_DATE_FORMAT_YESTERDAY
            return "Yesterday"
        } else {
            //before yesterday
            SIMPLE_DATE_FORMAT = SIMPLE_DATE_FORMAT_BEFORE
        }
        val cal: Calendar = chatDateTime.toCalendar(Locale.getDefault())
        return SIMPLE_DATE_FORMAT.format(cal.getTime())
    }
}