package com.cdtcl.ogmous.ui.home

import android.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.StringRequestListener
import com.cdtcl.ogmous.databinding.ActivityCreateNotesBinding
import com.cdtcl.ogmous.models.LoginResponse
import com.cdtcl.ogmous.network.NetworkClient
import com.cdtcl.ogmous.storage.AppPreferences
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import dmax.dialog.SpotsDialog

class CreateNotesActivity : AppCompatActivity() {
    private var spotDialog: AlertDialog? = null
    private lateinit var appPreferences: AppPreferences
    private lateinit var binding: ActivityCreateNotesBinding

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home){
            finish()
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateNotesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Create Notes"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val objNotes = Gson().fromJson(intent.getStringExtra("note"),Notes::class.java)

        appPreferences = AppPreferences(this)
        spotDialog = SpotsDialog.Builder().setContext(this).build()

        binding.editor.setPadding(10, 10, 10, 10);
        binding.editor.setPlaceholder("Insert text here...");

        if (objNotes!=null){
            binding.editor.html = objNotes.content
            binding.buttonSubmit.visibility = View.GONE
        }

        binding.bold.setOnClickListener { binding.editor.setBold() }
        binding.italic.setOnClickListener { binding.editor.setItalic() }
        binding.bullets.setOnClickListener { binding.editor.setBullets() }
        binding.quotes.setOnClickListener { binding.editor.setBlockquote() }

        binding.buttonSubmit.setOnClickListener {
            submitNotes()
        }

    }

    private val TAG = "CreateNotesActivity"
    private fun submitNotes() {

        spotDialog?.show()
        AndroidNetworking.post("${NetworkClient.baseUrl}create_notes")
            .addBodyParameter("content",binding.editor.html.toString())
            .addBodyParameter("person_id",appPreferences.getPerson()?.id.toString())
            .build()
            .getAsString(object : StringRequestListener {
                override fun onResponse(response: String?) {
                    spotDialog?.dismiss()
                    Log.d(TAG, "onResponse: $response")

                    val nrf = Gson().fromJson(response, LoginResponse::class.java)
                    if (nrf.status_code==200){
                        setResult(RESULT_OK)
                        finish()
                    }

                    Toast.makeText(this@CreateNotesActivity, nrf.status_message, Toast.LENGTH_SHORT).show()
                }

                override fun onError(anError: ANError?) {
                    Log.d(TAG, "onError: ${anError?.errorBody}")
                    Log.d(TAG, "onError: ${anError?.errorCode}")
                    Log.d(TAG, "onError: ${anError?.errorDetail}")

                    spotDialog?.dismiss()
                    Toast.makeText(this@CreateNotesActivity, "No Internet", Toast.LENGTH_SHORT).show()
                }
            })

    }

}