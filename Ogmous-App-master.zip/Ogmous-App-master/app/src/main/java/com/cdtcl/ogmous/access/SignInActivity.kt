package com.cdtcl.ogmous.access

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.util.Log
import android.widget.Toast
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.StringRequestListener
import com.cdtcl.ogmous.HomeActivity
import com.cdtcl.ogmous.R
import com.cdtcl.ogmous.databinding.ActivitySignInBinding
import com.cdtcl.ogmous.models.LoginResponse
import com.cdtcl.ogmous.network.NetworkClient
import com.cdtcl.ogmous.storage.AppPreferences
import com.google.gson.Gson
import dmax.dialog.SpotsDialog
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Patterns


class SignInActivity : AppCompatActivity() {
    private lateinit var appPreferences: AppPreferences
    private var spotDialog: AlertDialog? = null
    private lateinit var binding: ActivitySignInBinding

    private val TAG = "SignInActivity"

    fun isValidEmail(target: CharSequence?): Boolean {
        return if (TextUtils.isEmpty(target)) {
            false
        } else {
            Patterns.EMAIL_ADDRESS.matcher(target).matches()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        appPreferences = AppPreferences(this)
        spotDialog = SpotsDialog.Builder().setContext(this).build()

        binding.buttonSignIn.setOnClickListener {
            signIn()
        }
        binding.buttonGotoSignUp.setOnClickListener {
            startActivity(Intent(this,SignUpActivity::class.java))
            finish()
        }
        binding.buttonForgotPassword.setOnClickListener {
            startActivity(Intent(this,ForgotPasswordActivity::class.java))
        }

        binding.emailAddress.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun afterTextChanged(p0: Editable?) {
                binding.emailAddress.setTextColor(if (isValidEmail(p0.toString())) Color.BLACK else Color.RED)
            }
        })

    }

    private fun signIn() {


        if (!isValidEmail(binding.emailAddress.text)){
            Toast.makeText(this, "Please Enter a valid Email Address", Toast.LENGTH_LONG).show()
            return
        }

        spotDialog?.show()
        AndroidNetworking.post("${NetworkClient.baseUrl}sign_in")
            .addBodyParameter("email_address",binding.emailAddress.text.toString())
            .addBodyParameter("password",binding.password.text.toString())
            .build()
            .getAsString(object : StringRequestListener {
                override fun onResponse(response: String?) {

                    spotDialog?.dismiss()
                    Log.d(TAG, "onResponse: $response")

                    val nrf = Gson().fromJson(response, LoginResponse::class.java)
                    if (nrf.status_code==200){
                        //action
                        if (nrf.person == null){
                            Toast.makeText(this@SignInActivity, "No User Found in Response", Toast.LENGTH_SHORT).show()
                        }else{
                            if (nrf.person.status == "active"){

                                if (nrf.person.office_people.isEmpty()){
                                    Toast.makeText(this@SignInActivity, "User doesn't have an office", Toast.LENGTH_SHORT).show()
                                }else{
                                    appPreferences.savePerson(nrf.person)
                                    startActivity(Intent(this@SignInActivity,HomeActivity::class.java))
                                    finish()
                                }
                            }else{
                                Toast.makeText(this@SignInActivity, "User status is ${nrf.person.status}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }

                    Toast.makeText(this@SignInActivity, nrf.status_message, Toast.LENGTH_SHORT).show()
                }

                override fun onError(anError: ANError?) {
                    Log.d(TAG, "onError: ${anError?.errorBody}")
                    Log.d(TAG, "onError: ${anError?.errorCode}")
                    Log.d(TAG, "onError: ${anError?.errorDetail}")

                    spotDialog?.dismiss()
                    Toast.makeText(this@SignInActivity, "No Internet", Toast.LENGTH_SHORT).show()
                }
            })

    }
}