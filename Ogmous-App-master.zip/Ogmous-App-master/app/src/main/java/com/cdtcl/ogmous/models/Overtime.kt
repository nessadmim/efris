package com.cdtcl.ogmous.models

data class Overtime(
    val comment: String?,
    val created_at: String,
    val date: String?,
    val end_time: String?,
    val id: Int,
    val person_id: Int,
    val reason: String?,
    val record_status: String,
    val start_time: String?,
    val status: String,
    val updated_at: String
)