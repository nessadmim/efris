package com.cdtcl.ogmous.ui.home

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.StringRequestListener
import com.cdtcl.ogmous.R
import com.cdtcl.ogmous.databinding.ActivityLeaveRequestBinding
import com.cdtcl.ogmous.databinding.DialogLeaveRequestBinding
import com.cdtcl.ogmous.databinding.RowLeaveRequestBinding
import com.cdtcl.ogmous.models.LeaveRequest
import com.cdtcl.ogmous.models.LoginResponse
import com.cdtcl.ogmous.network.NetworkClient
import com.cdtcl.ogmous.storage.AppPreferences
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dmax.dialog.SpotsDialog
import java.util.*

class LeaveRequestActivity : AppCompatActivity() {

    private lateinit var adapter: LeaveRequestAdapter
    private var spotDialog: AlertDialog? = null
    private lateinit var appPreferences: AppPreferences
    private lateinit var binding: ActivityLeaveRequestBinding

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home){
            finish()
        }
        return super.onOptionsItemSelected(item)
    }

    private val TAG = "LeaveRequestActivity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportActionBar?.title = "Leave Request"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        appPreferences = AppPreferences(this)
        spotDialog = SpotsDialog.Builder().setContext(this).build()

        binding = ActivityLeaveRequestBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = LeaveRequestAdapter(this, mutableListOf())
        binding.rvLeaveRequest.adapter = adapter

        binding.btnRequest.setOnClickListener {
            val bindingDialogLeaveRequestBinding = DialogLeaveRequestBinding.inflate(layoutInflater,null,false)

            val c = Calendar.getInstance()
            val year = c.get(Calendar.YEAR)
            val month = c.get(Calendar.MONTH)
            val day = c.get(Calendar.DAY_OF_MONTH)
            val hour = c.get(Calendar.HOUR_OF_DAY)
            val minute = c.get(Calendar.MINUTE)

            bindingDialogLeaveRequestBinding.startDate.setOnClickListener {
                val dpd = DatePickerDialog(this, { view, year, monthOfYear, dayOfMonth ->
                    bindingDialogLeaveRequestBinding.startDate.setText("$year-${monthOfYear+1}-$dayOfMonth")
                }, year, month, day)
                dpd.show()
            }

            val v = MaterialAlertDialogBuilder(this)
                .setView(bindingDialogLeaveRequestBinding.root)
                .create()
                v.show()

            bindingDialogLeaveRequestBinding.btnSave.setOnClickListener {

                spotDialog?.show()
                AndroidNetworking.post("${NetworkClient.baseUrl}create_leave_request")
                    .addBodyParameter("reason",bindingDialogLeaveRequestBinding.reason.text.toString())
                    .addBodyParameter("start_date",bindingDialogLeaveRequestBinding.startDate.text.toString())
                    .addBodyParameter("days",bindingDialogLeaveRequestBinding.days.text.toString())
                    .addBodyParameter("person_id",appPreferences.getPerson()?.id.toString())
                    .build()
                    .getAsString(object : StringRequestListener {
                        override fun onResponse(response: String?) {
                            spotDialog?.dismiss()
                            Log.d(TAG, "onResponse: $response")

                            val nrf = Gson().fromJson(response, LoginResponse::class.java)
                            if (nrf.status_code==200){
                                v.dismiss()

                                //action
                                MaterialAlertDialogBuilder(this@LeaveRequestActivity)
                                    .setMessage(nrf.status_message)
                                    .setPositiveButton("Okay"){c,v-> fetchLeaveRequests() }
                                    .create()
                                    .show()

                            }

                            Toast.makeText(this@LeaveRequestActivity, nrf.status_message, Toast.LENGTH_SHORT).show()
                        }

                        override fun onError(anError: ANError?) {
                            Log.d(TAG, "onError: ${anError?.errorBody}")
                            Log.d(TAG, "onError: ${anError?.errorCode}")
                            Log.d(TAG, "onError: ${anError?.errorDetail}")

                            spotDialog?.dismiss()
                            Toast.makeText(this@LeaveRequestActivity, "No Internet", Toast.LENGTH_SHORT).show()
                        }
                    })

            }

            bindingDialogLeaveRequestBinding.btnCancel.setOnClickListener {
                v.dismiss()
            }


        }

        fetchLeaveRequests()
    }

    
    private fun fetchLeaveRequests() {
        binding.empty.visibility = View.GONE
        binding.progressBar.visibility = View.VISIBLE

        AndroidNetworking.post("${NetworkClient.baseUrl}get_leave_request")
            .addBodyParameter("person_id",appPreferences.getPerson()?.id.toString())
                .build()
                .getAsString(object : StringRequestListener {
                    override fun onResponse(response: String?) {
                        Log.e(">>>","::${response}")
    
                        val list: MutableList<LeaveRequest> = Gson().fromJson(response, object : TypeToken<List<LeaveRequest?>?>() {}.type)
                        adapter.changeList(list)

                        binding.progressBar.visibility = View.GONE
                        binding.empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                    }
    
                    override fun onError(anError: ANError?) {
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(this@LeaveRequestActivity,"No Internet Connection",Toast.LENGTH_LONG).show()
                    }
                } )
            }
}

class LeaveRequestAdapter(val context: Context, var list: MutableList<LeaveRequest>)
    : RecyclerView.Adapter<LeaveRequestAdapter.LeaveRequestHolder>() {

    inner class LeaveRequestHolder(val binding : RowLeaveRequestBinding)
        : RecyclerView.ViewHolder(binding.root) {
        fun displayViews(obj: LeaveRequest) {
            binding.id.text = "ID: "+obj.id
            binding.days.text = "Days: "+obj.days
            binding.startDate.text = "Start Date: "+obj.start_date
            binding.endDate.text = "End Date: "+obj.end_date
            binding.reason.text = "Reason: "+obj.reason
            binding.comment.text = "Comment: "+obj.comment
            binding.status.text = "Status: "+obj.status

            binding.startDate.visibility = if (obj.start_date.isNullOrEmpty()) View.GONE else View.VISIBLE
            binding.endDate.visibility = if (obj.end_date.isNullOrEmpty()) View.GONE else View.VISIBLE
            binding.comment.visibility = if (obj.comment.isNullOrEmpty()) View.GONE else View.VISIBLE
            binding.reason.visibility = if (obj.reason.isNullOrEmpty()) View.GONE else View.VISIBLE

            binding.root.setOnClickListener {

            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LeaveRequestHolder {
        return LeaveRequestHolder(RowLeaveRequestBinding.inflate(LayoutInflater.from(context),parent,false))
    }

    override fun onBindViewHolder(holder: LeaveRequestHolder, position: Int) {
        holder.displayViews(list[position])
    }

    override fun getItemCount(): Int = list.size
    fun changeList(list: MutableList<LeaveRequest>) {
        this.list = list
        notifyDataSetChanged()
    }
}