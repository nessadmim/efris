package com.cdtcl.ogmous.ui.home

class Home(val id:Int, val name:String,val drawable:Int) {
}