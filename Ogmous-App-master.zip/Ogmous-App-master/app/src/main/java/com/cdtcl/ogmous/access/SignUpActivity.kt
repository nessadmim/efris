package com.cdtcl.ogmous.access

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.StringRequestListener
import com.cdtcl.ogmous.databinding.ActivitySignUpBinding
import com.cdtcl.ogmous.models.LoginResponse
import com.cdtcl.ogmous.models.Office
import com.cdtcl.ogmous.network.NetworkClient
import com.cdtcl.ogmous.storage.AppPreferences
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.tiper.MaterialSpinner
import dmax.dialog.SpotsDialog
import java.text.DecimalFormat
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Patterns


class SignUpActivity : AppCompatActivity() {

    private var office: Office? = null
    private var offices: MutableList<Office> = mutableListOf()
    private val TAG = "SignUpActivity"

    private var spotDialog: AlertDialog? = null
    private lateinit var appPreferences: AppPreferences
    private lateinit var binding: ActivitySignUpBinding

    private val df: DecimalFormat = DecimalFormat("0.00")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        appPreferences = AppPreferences(this)
        spotDialog = SpotsDialog.Builder().setContext(this).build()

        binding.buttonSignIn.setOnClickListener {
            signUp()
        }
        binding.buttonGotoSignIn.setOnClickListener {
            startActivity(Intent(this,SignInActivity::class.java))
            finish()
        }

        binding.ccp.registerCarrierNumberEditText(binding.phoneNumber)
        binding.ccp.setPhoneNumberValidityChangeListener {
            binding.phoneNumber.setTextColor(if (it) Color.BLACK else Color.RED)
        }
        binding.emailAddress.addTextChangedListener(object : TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun afterTextChanged(p0: Editable?) {
                binding.emailAddress.setTextColor(if (isValidEmail(p0.toString())) Color.BLACK else Color.RED)
            }
        })

        fetchOffice()
    }
    
    
    private fun fetchOffice() {
        binding.progressBar.visibility = View.VISIBLE
        AndroidNetworking.post("${NetworkClient.baseUrl}get_offices")
                .addBodyParameter("latitude","")
                .addBodyParameter("longitude","")
                .build()
                .getAsString(object : StringRequestListener {
                    override fun onResponse(response: String?) {
                        Log.e(">>>","::${response}")

                        binding.progressBar.visibility = View.GONE
                        offices = Gson().fromJson(response, object : TypeToken<List<Office?>?>() {}.type)

                        //spinnerOffices
                        val spinnerOfficesAdapter = ArrayAdapter<Any?>(this@SignUpActivity, android.R.layout.simple_spinner_item, offices.map { it.name }.toTypedArray())
                        spinnerOfficesAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        binding.spinnerOffices.adapter = spinnerOfficesAdapter
                        binding.spinnerOffices.onItemSelectedListener = object : MaterialSpinner.OnItemSelectedListener{
                            override fun onItemSelected(
                                parent: MaterialSpinner,
                                view: View?,
                                position: Int,
                                id: Long
                            ) {
                                office = offices[position]
                            }

                            override fun onNothingSelected(parent: MaterialSpinner) {
                            }

                        }

                    }
    
                    override fun onError(anError: ANError?) {
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(this@SignUpActivity,"No Internet Connection",Toast.LENGTH_LONG).show()
                    }
                } )
            }
    fun isValidEmail(target: CharSequence?): Boolean {
        return if (TextUtils.isEmpty(target)) {
            false
        } else {
            Patterns.EMAIL_ADDRESS.matcher(target).matches()
        }
    }
    private fun signUp() {

        if (office == null){
            Toast.makeText(this, "Please Select an Office", Toast.LENGTH_LONG).show()
            return
        }

        if (binding.phoneNumber.text.isEmpty() || !binding.ccp.isValidFullNumber){
            Toast.makeText(this, "Please Enter a valid Phone Number", Toast.LENGTH_LONG).show()
            return
        }
        if (!isValidEmail(binding.emailAddress.text)){
            Toast.makeText(this, "Please Enter a valid Email Address", Toast.LENGTH_LONG).show()
            return
        }

        spotDialog?.show()
        AndroidNetworking.post("${NetworkClient.baseUrl}sign_up")
            .addBodyParameter("name","${binding.firstName.text} ${binding.lastName.text}")
            .addBodyParameter("phone_number",binding.ccp.fullNumberWithPlus)
            .addBodyParameter("email_address",binding.emailAddress.text.toString())
            .addBodyParameter("password",binding.password.text.toString())
            .addBodyParameter("office_id",office?.id.toString())
            .build()
            .getAsString(object : StringRequestListener {
                override fun onResponse(response: String?) {

                    spotDialog?.dismiss()
                    Log.d(TAG, "onResponse: $response")

                    val nrf = Gson().fromJson(response, LoginResponse::class.java)
                    if (nrf.status_code==200){
                        //action
                        MaterialAlertDialogBuilder(this@SignUpActivity)
                            .setMessage("Person Created Successfully, Please wait for your confirmation")
                            .setPositiveButton("Okay"){c,v->
                                finish()
                            }
                            .create()
                            .show()
                    }

                    Toast.makeText(this@SignUpActivity, nrf.status_message, Toast.LENGTH_SHORT).show()
                }

                override fun onError(anError: ANError?) {
                    Log.d(TAG, "onError: ${anError?.errorBody}")
                    Log.d(TAG, "onError: ${anError?.errorCode}")
                    Log.d(TAG, "onError: ${anError?.errorDetail}")

                    spotDialog?.dismiss()
                    Toast.makeText(this@SignUpActivity, "No Internet", Toast.LENGTH_SHORT).show()
                }
            })
    }
}