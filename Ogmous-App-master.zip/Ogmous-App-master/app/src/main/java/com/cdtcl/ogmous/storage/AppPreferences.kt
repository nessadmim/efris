package com.cdtcl.ogmous.storage

import android.content.Context
import android.content.Context.MODE_PRIVATE
import com.cdtcl.ogmous.models.Person
import com.google.gson.Gson

class AppPreferences(val context: Context) {
    val preferences = context.getSharedPreferences("APP-PREF",MODE_PRIVATE)
    val editor = preferences.edit()

    fun savePerson(user: Person?){
        editor.putString("user", Gson().toJson(user)).commit()
    }
    fun getPerson():Person?{
        val v = preferences.getString("user",null)
        if (v.isNullOrEmpty()) return null

        val objUser = Gson().fromJson(v,Person::class.java)
        return objUser
    }

    fun signOut() {
        editor.putString("user",null).commit()
    }
}