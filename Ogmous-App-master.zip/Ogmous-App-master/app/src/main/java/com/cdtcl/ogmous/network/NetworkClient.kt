package com.cdtcl.ogmous.network

class NetworkClient {

    companion object {
        val baseUrl = "https://truenorth.rms-cloud.net/api/"
        val domain = "https://truenorth.rms-cloud.net/"
    }
}
