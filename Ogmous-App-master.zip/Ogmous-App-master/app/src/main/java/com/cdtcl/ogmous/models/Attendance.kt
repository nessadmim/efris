package com.cdtcl.ogmous.models

data class Attendance(
    val comment: String?,
    val created_at: String,
    val date: String,
    val end_datetime: String?,
    val end_latitude: String?,
    val end_longitude: String?,
    val id: Int,
    val person_id: Int,
    val record_status: String,
    val remarks: String?,
    val start_datetime: String,
    val start_latitude: String,
    val start_longitude: String,
    val updated_at: String
)