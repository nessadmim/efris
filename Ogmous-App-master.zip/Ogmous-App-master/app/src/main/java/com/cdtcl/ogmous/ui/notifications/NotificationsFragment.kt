package com.cdtcl.ogmous.ui.notifications

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.StringRequestListener
import com.cdtcl.ogmous.R
import com.cdtcl.ogmous.databinding.FragmentNotificationsBinding
import com.cdtcl.ogmous.databinding.RowNotificationBinding
import com.cdtcl.ogmous.models.Notifications
import com.cdtcl.ogmous.network.NetworkClient
import com.cdtcl.ogmous.storage.AppPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.joda.time.DateTime

import org.joda.time.format.DateTimeFormat
import org.joda.time.format.DateTimeFormatter
import java.text.SimpleDateFormat
import java.util.*


class NotificationsFragment : Fragment() {

    private lateinit var appPreferences: AppPreferences
    private lateinit var adapter: NotificationsAdapter
    private lateinit var notificationsViewModel: NotificationsViewModel
    private var _binding: FragmentNotificationsBinding? = null

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        notificationsViewModel =
            ViewModelProvider(this).get(NotificationsViewModel::class.java)


        _binding = FragmentNotificationsBinding.inflate(inflater, container, false)
        val root: View = binding.root

        appPreferences = AppPreferences(requireContext())

        adapter = NotificationsAdapter(requireContext(), mutableListOf())
        binding.rvNotification.adapter = adapter

        fetchNotifications()

        return root
    }
    
    
    private fun fetchNotifications() {
        binding.empty.visibility = View.GONE
        binding.progressBar.visibility = View.VISIBLE

        AndroidNetworking.post("${NetworkClient.baseUrl}get_notifications")
            .addBodyParameter("person_id",appPreferences.getPerson()?.id.toString())
                .build()
                .getAsString(object : StringRequestListener {
                    override fun onResponse(response: String?) {
                        Log.e(">>>","::${response}")
    
                        val list: MutableList<Notifications> = Gson().fromJson(response, object : TypeToken<List<Notifications?>?>() {}.type)
                        adapter.changeList(list)

                        binding.progressBar.visibility = View.GONE
                        binding.empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                    }
    
                    override fun onError(anError: ANError?) {
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(requireContext(),"No Internet Connection",Toast.LENGTH_LONG).show()
                    }
                } )
            }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

class NotificationsAdapter(val context: Context, var list: MutableList<Notifications>)
    : RecyclerView.Adapter<NotificationsAdapter.NotificationsHolder>() {

    inner class NotificationsHolder(val binding : RowNotificationBinding)
        : RecyclerView.ViewHolder(binding.root) {
        fun displayViews(obj: Notifications) {
            binding.message.text = obj.content
            binding.source.text = obj.title
            binding.createdAt.text = formatChatsDate(DateTime.now(),obj.created_at)
            binding.root.setOnClickListener {

            }
        }

    }

    fun formatChatsDate(today: DateTime, date_string: String?): String? {
        val DATE_FORMAT: DateTimeFormatter =
            DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss") //Default format
        var SIMPLE_DATE_FORMAT: SimpleDateFormat? = null
        val SIMPLE_DATE_FORMAT_TODAY =
            SimpleDateFormat("h:mm a", Locale.getDefault()) //Needed format
        val SIMPLE_DATE_FORMAT_YESTERDAY =
            SimpleDateFormat("MMM,d h:mma", Locale.getDefault()) //Needed format
        val SIMPLE_DATE_FORMAT_BEFORE =
            SimpleDateFormat("M/d/yy", Locale.getDefault()) //Needed format
        val chatDateTime: DateTime = DateTime(DATE_FORMAT.parseDateTime(date_string!!.split(".")[0]))
        if (chatDateTime.toLocalDate() == today.toLocalDate()) {
            //is today
            SIMPLE_DATE_FORMAT = SIMPLE_DATE_FORMAT_TODAY
        } else if (chatDateTime.toLocalDate() == today.minusDays(1).toLocalDate()) {
            //is yesterday
            SIMPLE_DATE_FORMAT = SIMPLE_DATE_FORMAT_YESTERDAY
            return "Yesterday"
        } else {
            //before yesterday
            SIMPLE_DATE_FORMAT = SIMPLE_DATE_FORMAT_BEFORE
        }
        val cal: Calendar = chatDateTime.toCalendar(Locale.getDefault())
        return SIMPLE_DATE_FORMAT.format(cal.getTime())
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotificationsHolder {
        return NotificationsHolder(RowNotificationBinding.inflate(LayoutInflater.from(context),parent,false))
    }

    override fun onBindViewHolder(holder: NotificationsHolder, position: Int) {
        holder.displayViews(list[position])
    }

    override fun getItemCount(): Int = list.size
    fun changeList(list: MutableList<Notifications>) {
        this.list = list
        notifyDataSetChanged()
    }
}