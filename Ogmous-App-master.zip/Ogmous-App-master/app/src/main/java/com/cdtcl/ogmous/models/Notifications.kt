package com.cdtcl.ogmous.models

data class Notifications(
    val content: String,
    val created_at: String,
    val id: Int,
    val person_id: Int,
    val record_status: String,
    val title: String,
    val type: String,
    val updated_at: String
)