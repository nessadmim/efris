package com.cdtcl.ogmous.ui.dashboard

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.StringRequestListener
import com.cdtcl.ogmous.R
import com.cdtcl.ogmous.SplashActivity
import com.cdtcl.ogmous.databinding.FragmentDashboardBinding
import com.cdtcl.ogmous.models.AccountResponse
import com.cdtcl.ogmous.models.Person
import com.cdtcl.ogmous.network.NetworkClient
import com.cdtcl.ogmous.storage.AppPreferences
import com.github.dhaval2404.imagepicker.ImagePicker
import com.github.florent37.inlineactivityresult.kotlin.startForResult
import com.google.gson.Gson
import com.squareup.picasso.Picasso
import java.io.File

class DashboardFragment : Fragment() {

    private var person: Person? = null
    private lateinit var dashboardViewModel: DashboardViewModel
    private var _binding: FragmentDashboardBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    private lateinit var appPreferences: AppPreferences
    private val TAG = "DashboardFragment"

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        dashboardViewModel =
            ViewModelProvider(this).get(DashboardViewModel::class.java)

        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        val root: View = binding.root

        appPreferences = AppPreferences(requireContext())
        person = appPreferences.getPerson()

        binding.name.text = person?.name
        binding.emailAddress.text = person?.email_address
        binding.phoneNumber.text = person?.phone_number
        binding.id.text = "ID CODE: "+person?.id.toString()

        val url = "${NetworkClient.domain}/profile/${person?.picture}"
        Picasso.get().load(url).placeholder(R.drawable.avatar).centerCrop().fit().into(binding.picture)

        binding.buttonLogout.setOnClickListener {
            startActivity(Intent(requireActivity(),SplashActivity::class.java))
            requireActivity().finish()
        }

        binding.imgPictureProgressTxt.visibility = View.GONE
        binding.imgPictureButton.setOnClickListener {

            ImagePicker.with(this)
                .cropSquare()
                .compress(1024)
                .maxResultSize(400, 400)
                .saveDir(File(requireActivity().getExternalFilesDir("Profile")!!.path))
                .createIntent { intent ->
                    startForResult(intent){ result ->
                        val uri: Uri = result.data?.data!!

                        completeFileAttach(File(uri.path))
                        Log.d(TAG, "onViewCreated: ")
                    }
                }

            /*ImagePicker.with(this)
                    .crop()
                    .compress(1024)
                    .maxResultSize(600, 600)
                    .start { resultCode, data ->
                        if (resultCode == Activity.RESULT_OK) {
                            completeFileAttach(ImagePicker.getFile(data))
                        } else if (resultCode == ImagePicker.RESULT_ERROR) {
                            Toast.makeText(requireContext(), ImagePicker.getError(data), Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(requireContext(), "Task Cancelled", Toast.LENGTH_SHORT).show()
                        }
                    }*/

        }

        binding.officeName.text = person?.office_people?.first()?.office?.name
        binding.officeLocation.text = person?.office_people?.first()?.office?.location

        return root
    }


    private fun completeFileAttach(file: File?) {
        binding.imgPictureButton.isEnabled = false
        binding.imgPictureProgressTxt.visibility = View.VISIBLE
        AndroidNetworking.upload("${NetworkClient.baseUrl}update_person")
            .addMultipartParameter("person_id",person?.id.toString())
            .addMultipartFile("picture",file)
            .build()
            .setUploadProgressListener { bytesUploaded, totalBytes ->
                val percentage = (bytesUploaded.toFloat() / totalBytes.toFloat() * 100.toFloat())
                Log.d(TAG, "completeFileAttach: $percentage")
                binding.imgPictureProgressTxt.text = "${percentage.toInt()}%"
            }
            .getAsString(object : StringRequestListener {
                override fun onResponse(response: String?) {

                    binding.imgPictureProgressTxt.visibility = View.GONE
                    binding.imgPictureButton.isEnabled = true
                    val nrf = Gson().fromJson(response, AccountResponse::class.java)
                    if (nrf.status_code==200){
                        //action
                        //appPreferences.saveUserData(Gson().toJson(nrf.user))
                        person?.picture = nrf.user?.picture
                        appPreferences.savePerson(person)

                        val url = "${NetworkClient.domain}/profile/${person?.picture}"
                        Picasso.get().load(url).placeholder(R.drawable.avatar).centerCrop().fit().into(binding.picture)
                        //setUserInformation()
                    }

                    Toast.makeText(requireContext(), nrf.status_message, Toast.LENGTH_SHORT).show()
                }
                override fun onError(anError: ANError?) {
                    binding.imgPictureProgressTxt.visibility = View.GONE
                    binding.imgPictureButton.isEnabled = true

                    Log.d(TAG, "onError: ${anError?.errorBody}")
                    Log.d(TAG, "onError: ${anError?.errorCode}")
                    Log.d(TAG, "onError: ${anError?.errorDetail}")

                    Toast.makeText(requireContext(), "No Internet", Toast.LENGTH_SHORT).show()
                }
            })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}