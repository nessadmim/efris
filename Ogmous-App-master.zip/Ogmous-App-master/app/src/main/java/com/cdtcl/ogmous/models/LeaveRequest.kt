package com.cdtcl.ogmous.models

data class LeaveRequest(
    val comment: String?,
    val created_at: String,
    val days: Int,
    val end_date: String?,
    val id: Int,
    val person_id: Int,
    val reason: String?,
    val record_status: String?,
    val start_date: String?,
    val status: String,
    val updated_at: String
)