package com.cdtcl.ogmous.ui.home

import android.app.AlertDialog
import android.location.Location
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import com.akhgupta.easylocation.EasyLocationAppCompatActivity
import com.akhgupta.easylocation.EasyLocationRequestBuilder
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.StringRequestListener
import com.cdtcl.ogmous.R
import com.cdtcl.ogmous.databinding.ActivityCheckInBinding
import com.cdtcl.ogmous.helper.DateHelper
import com.cdtcl.ogmous.models.LoginResponse
import com.cdtcl.ogmous.models.Office
import com.cdtcl.ogmous.network.NetworkClient
import com.cdtcl.ogmous.storage.AppPreferences
import com.google.android.gms.location.LocationRequest
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.maps.android.SphericalUtil
import dmax.dialog.SpotsDialog
import com.google.android.gms.maps.model.LatLng

import org.joda.time.DateTime
import java.text.DecimalFormat

class CheckInActivity : EasyLocationAppCompatActivity() {


    override fun onLocationPermissionGranted() {
        Log.d(TAG, "onLocationPermissionGranted: ")
    }

    override fun onLocationProviderEnabled() {
        Log.d(TAG, "onLocationProviderEnabled: ")
    }

    override fun onLocationReceived(location: Location?) {
        currentLocation = location

        if (location!=null) {
            distance = SphericalUtil.computeDistanceBetween(
                LatLng(location.latitude, location.longitude),
                LatLng(office!!.latitude.toDouble(), office!!.longitude.toDouble())
            )
            binding.distance.text = "${df.format(distance)} Metres"


            validateDistanceAndButtons()
        }
    }

    /**START DISTANCE*/
    private var canSendRecord: Boolean = false
    private var oldActivityStatus: Boolean = false
    private var activityStatus: Boolean = false

    private fun validateDistanceAndButtons() {
        oldActivityStatus = activityStatus
        activityStatus = distance < getString(R.string.maximum_office_distance).toDouble()
        checkActivity()
    }

    private fun checkActivity() {
        if (activityStatus != oldActivityStatus){
            if (activityStatus){
                Toast.makeText(this, "You can Check in", Toast.LENGTH_SHORT).show()
            }else{
                MaterialAlertDialogBuilder(this)
                    .setMessage("You are outside your designated work place")
                    .setPositiveButton("OK",null)
                    .create()
                    .show()
            }
        }

        binding.outsideDesignatedWorkplace.visibility = if(activityStatus) View.GONE else View.VISIBLE
        binding.action.isEnabled = activityStatus && canSendRecord
    }
    /**END DISTANCE*/


    override fun onLocationProviderDisabled() {
        Log.d(TAG, "onLocationProviderDisabled: ")
    }

    override fun onLocationPermissionDenied() {
        Log.d(TAG, "onLocationPermissionDenied: ")
    }

    fun startListeningForLocation(){

        val locationRequest = LocationRequest()
            .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
            .setInterval(1000)
            .setFastestInterval(1000)

        val easyLocationRequest = EasyLocationRequestBuilder()
            .setLocationRequest(locationRequest)
            .setFallBackToLastLocationTime(3000)
            .build();

        requestLocationUpdates(easyLocationRequest);
    }

    private val df: DecimalFormat = DecimalFormat("0.00")
    private var distance: Double = Double.MAX_VALUE
    private var office: Office? = null
    private var currentLocation: Location? = null
    private var spotDialog: AlertDialog? = null
    private lateinit var appPreferences: AppPreferences
    private lateinit var binding: ActivityCheckInBinding

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home){
            finish()
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        appPreferences = AppPreferences(this)
        spotDialog = SpotsDialog.Builder().setContext(this).build()

        office = appPreferences.getPerson()?.office_people?.first()?.office
        binding = ActivityCheckInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Check In"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding.time.text = DateHelper().formatNow()
        binding.action.setOnClickListener {
            recordCheckIn()
        }

        checkTodayAttendance()

        startListeningForLocation()
    }

    private val TAG = "CheckInActivity"
    private fun recordCheckIn() {

        spotDialog?.show()
        AndroidNetworking.post("${NetworkClient.baseUrl}start_attendance")
            .addBodyParameter("person_id",appPreferences.getPerson()?.id.toString())
            .addBodyParameter("latitude",currentLocation?.latitude.toString())
            .addBodyParameter("longitude",currentLocation?.longitude.toString())
            .build()
            .getAsString(object : StringRequestListener {
                override fun onResponse(response: String?) {

                    spotDialog?.dismiss()
                    Log.d(TAG, "onResponse: $response")

                    val nrf = Gson().fromJson(response, LoginResponse::class.java)
                    if (nrf.status_code==200){
                        //action
                        MaterialAlertDialogBuilder(this@CheckInActivity)
                            .setTitle("Success")
                            .setMessage(nrf.status_message)
                            .setPositiveButton("OK"){c,v->
                                finish()
                            }
                            .create()
                            .show()

                    }

                    Toast.makeText(this@CheckInActivity, nrf.status_message, Toast.LENGTH_SHORT).show()
                }

                override fun onError(anError: ANError?) {
                    Log.d(TAG, "onError: ${anError?.errorBody}")
                    Log.d(TAG, "onError: ${anError?.errorCode}")
                    Log.d(TAG, "onError: ${anError?.errorDetail}")

                    spotDialog?.dismiss()
                    Toast.makeText(this@CheckInActivity, "No Internet", Toast.LENGTH_SHORT).show()
                }
            })
    }
    private fun checkTodayAttendance() {

        binding.action.isEnabled = false
        binding.progressBar.visibility = View.VISIBLE
        AndroidNetworking.post("${NetworkClient.baseUrl}get_person_today_attendance")
            .addBodyParameter("person_id",appPreferences.getPerson()?.id.toString())
            .build()
            .getAsString(object : StringRequestListener {
                override fun onResponse(response: String?) {

                    binding.progressBar.visibility = View.GONE
                    Log.d(TAG, "onResponse: $response")

                    val nrf = Gson().fromJson(response, LoginResponse::class.java)
                    if (nrf.status_code==200){
                        //action
                        MaterialAlertDialogBuilder(this@CheckInActivity)
                            .setTitle("Caution")
                            .setMessage(nrf.status_message)
                            .setPositiveButton("OK"){c,v->
                                finish()
                            }
                            .setCancelable(false)
                            .create()
                            .show()

                        canSendRecord = false
                    }else{
                        canSendRecord = true
                    }
                    checkActivity()

                    Toast.makeText(this@CheckInActivity, nrf.status_message, Toast.LENGTH_SHORT).show()
                }

                override fun onError(anError: ANError?) {
                    Log.d(TAG, "onError: ${anError?.errorBody}")
                    Log.d(TAG, "onError: ${anError?.errorCode}")
                    Log.d(TAG, "onError: ${anError?.errorDetail}")

                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(this@CheckInActivity, "No Internet", Toast.LENGTH_SHORT).show()
                }
            })
    }
}