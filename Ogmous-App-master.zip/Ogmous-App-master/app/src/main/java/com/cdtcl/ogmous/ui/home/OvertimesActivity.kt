package com.cdtcl.ogmous.ui.home

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.StringRequestListener
import com.cdtcl.ogmous.databinding.ActivityOvertimesBinding
import com.cdtcl.ogmous.databinding.DialogLeaveRequestBinding
import com.cdtcl.ogmous.databinding.DialogOvertimeBinding
import com.cdtcl.ogmous.databinding.RowOvertimeBinding
import com.cdtcl.ogmous.models.LoginResponse
import com.cdtcl.ogmous.models.Overtime
import com.cdtcl.ogmous.network.NetworkClient
import com.cdtcl.ogmous.storage.AppPreferences
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dmax.dialog.SpotsDialog
import java.util.*

class OvertimesActivity : AppCompatActivity() {
    private lateinit var appPreferences: AppPreferences
    private var spotDialog: AlertDialog? = null
    private lateinit var adapter: OvertimeAdapter
    private lateinit var binding: ActivityOvertimesBinding

    private val TAG = "OvertimesActivity"

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home){
            finish()
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOvertimesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Overtime"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        appPreferences = AppPreferences(this)
        spotDialog = SpotsDialog.Builder().setContext(this).build()

        adapter = OvertimeAdapter(this, mutableListOf())
        binding.rvOvertime.adapter = adapter

        binding.btnRequest.setOnClickListener {
            val bindingOvertime = DialogOvertimeBinding.inflate(layoutInflater,null,false)

            val v = MaterialAlertDialogBuilder(this)
                .setView(bindingOvertime.root)
                .create()
                v.show()

            val c = Calendar.getInstance()
            val year = c.get(Calendar.YEAR)
            val month = c.get(Calendar.MONTH)
            val day = c.get(Calendar.DAY_OF_MONTH)
            val hour = c.get(Calendar.HOUR_OF_DAY)
            val minute = c.get(Calendar.MINUTE)

            bindingOvertime.date.setOnClickListener {
                val dpd = DatePickerDialog(this, { view, year, monthOfYear, dayOfMonth ->
                    bindingOvertime.date.setText("$year-${monthOfYear+1}-$dayOfMonth")
                }, year, month, day)
                dpd.show()
            }
            bindingOvertime.startTime.setOnClickListener {
                val tpd = TimePickerDialog(this, { view, h, m ->
                    bindingOvertime.startTime.setText("$h:${m}:00")
                }, hour, minute, false)
                tpd.show()
            }
            bindingOvertime.endTime.setOnClickListener {
                val tpd = TimePickerDialog(this, {view,h,m->
                    bindingOvertime.endTime.setText("$h:${m}:00")
                },hour,minute,false)
                tpd.show()
            }

            bindingOvertime.btnCancel.setOnClickListener {
                v.dismiss()
            }

            bindingOvertime.btnSave.setOnClickListener {

                spotDialog?.show()
                AndroidNetworking.post("${NetworkClient.baseUrl}create_overtime")
                    .addBodyParameter("reason",bindingOvertime.reason.text.toString())
                    .addBodyParameter("start_time",bindingOvertime.startTime.text.toString())
                    .addBodyParameter("end_time",bindingOvertime.endTime.text.toString())
                    .addBodyParameter("date",bindingOvertime.date.text.toString())
                    .addBodyParameter("person_id",appPreferences.getPerson()?.id.toString())
                    .build()
                    .getAsString(object : StringRequestListener {
                        override fun onResponse(response: String?) {
                            spotDialog?.dismiss()
                            Log.d(TAG, "onResponse: $response")

                            val nrf = Gson().fromJson(response, LoginResponse::class.java)
                            if (nrf.status_code==200){
                                v.dismiss()

                                //action
                                MaterialAlertDialogBuilder(this@OvertimesActivity)
                                    .setMessage(nrf.status_message)
                                    .setPositiveButton("Okay"){c,v-> fetchOvertime() }
                                    .create()
                                    .show()

                            }

                            Toast.makeText(this@OvertimesActivity, nrf.status_message, Toast.LENGTH_SHORT).show()
                        }

                        override fun onError(anError: ANError?) {
                            Log.d(TAG, "onError: ${anError?.errorBody}")
                            Log.d(TAG, "onError: ${anError?.errorCode}")
                            Log.d(TAG, "onError: ${anError?.errorDetail}")

                            spotDialog?.dismiss()
                            Toast.makeText(this@OvertimesActivity, "No Internet", Toast.LENGTH_SHORT).show()
                        }
                    })

            }

        }

        fetchOvertime()

    }


    private fun fetchOvertime() {
        binding.empty.visibility = View.GONE
        binding.progressBar.visibility = View.VISIBLE

        AndroidNetworking.post("${NetworkClient.baseUrl}get_overtime")
            .addBodyParameter("person_id",appPreferences.getPerson()?.id.toString())
                .build()
                .getAsString(object : StringRequestListener {
                    override fun onResponse(response: String?) {
                        Log.e(">>>","::${response}")

                        val list: MutableList<Overtime> = Gson().fromJson(response, object : TypeToken<List<Overtime?>?>() {}.type)
                        adapter.changeList(list)

                        binding.progressBar.visibility = View.GONE
                        binding.empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                    }

                    override fun onError(anError: ANError?) {
                        binding.progressBar.visibility = View.GONE
                        Toast.makeText(this@OvertimesActivity,"No Internet Connection",Toast.LENGTH_LONG).show()
                    }
                } )
            }
}

class OvertimeAdapter(val context: Context, var list: MutableList<Overtime>)
    : RecyclerView.Adapter<OvertimeAdapter.OvertimeHolder>() {

    inner class OvertimeHolder(val binding : RowOvertimeBinding)
        : RecyclerView.ViewHolder(binding.root) {
        fun displayViews(obj: Overtime) {

            binding.comment.text = "Comment: "+obj.comment
            binding.startTime.text = "Start Time: "+obj.start_time
            binding.endTime.text = "End Time: "+obj.end_time
            binding.date.text = "Date: "+obj.date
            binding.status.text = "Status: "+obj.status
            binding.reason.text = "Reason: "+obj.reason

            binding.comment.visibility = if (obj.comment.isNullOrEmpty()) View.GONE else View.VISIBLE
            binding.startTime.visibility = if (obj.start_time.isNullOrEmpty()) View.GONE else View.VISIBLE
            binding.endTime.visibility = if (obj.end_time.isNullOrEmpty()) View.GONE else View.VISIBLE
            binding.date.visibility = if (obj.date.isNullOrEmpty()) View.GONE else View.VISIBLE
            binding.reason.visibility = if (obj.reason.isNullOrEmpty()) View.GONE else View.VISIBLE

            binding.root.setOnClickListener {

            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OvertimeHolder {
        return OvertimeHolder(RowOvertimeBinding.inflate(LayoutInflater.from(context),parent,false))
    }

    override fun onBindViewHolder(holder: OvertimeHolder, position: Int) {
        holder.displayViews(list[position])
    }

    override fun getItemCount(): Int = list.size
    fun changeList(list: MutableList<Overtime>) {
        this.list = list
        notifyDataSetChanged()
    }
}