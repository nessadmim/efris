package com.cdtcl.ogmous

import android.os.Bundle
import android.util.Log
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.StringRequestListener
import com.cdtcl.ogmous.databinding.ActivityHomeBinding
import com.cdtcl.ogmous.models.Person
import com.cdtcl.ogmous.network.NetworkClient
import com.cdtcl.ogmous.storage.AppPreferences
import com.onesignal.OneSignal

class HomeActivity : AppCompatActivity() {

    private var person: Person? = null
    private lateinit var appPreferences: AppPreferences
    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navView: BottomNavigationView = binding.navView

        val navController = findNavController(R.id.nav_host_fragment_activity_home)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        val appBarConfiguration = AppBarConfiguration(
            setOf(R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)

        appPreferences = AppPreferences(this)
        person = appPreferences.getPerson()
        updatePlayerId()

        supportActionBar?.hide()
    }

    private val TAG = "HomeActivity"
    private fun updatePlayerId() {

        AndroidNetworking.post("${NetworkClient.baseUrl}update_person")
            .addBodyParameter("person_id",person?.id.toString())
            .addBodyParameter("player_id", OneSignal.getDeviceState()?.userId)
            .build()
            .getAsString(object : StringRequestListener {
                override fun onResponse(response: String?) {

                    Log.d(TAG, ">>onResponse: $response")
                }

                override fun onError(anError: ANError?) {
                    Log.d(TAG, ">>onError")
                    Log.d(TAG, ">>onError: ${anError?.errorBody}")
                    Log.d(TAG, ">>onError: ${anError?.errorCode}")
                    Log.d(TAG, ">>onError: ${anError?.message}")

                }
            })
    }
}