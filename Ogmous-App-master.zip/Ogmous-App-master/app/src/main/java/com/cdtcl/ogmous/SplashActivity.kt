package com.cdtcl.ogmous

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.cdtcl.ogmous.access.SignInActivity
import com.cdtcl.ogmous.databinding.ActivitySplashBinding
import com.onesignal.OneSignal
import java.util.*
import kotlin.concurrent.schedule

class SplashActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySplashBinding

    //187d64e5-e1b4-4f48-b94e-fbaa1b38587a
    private val ONESIGNAL_APP_ID = "187d64e5-e1b4-4f48-b94e-fbaa1b38587a";

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);

        OneSignal.initWithContext(this);
        OneSignal.setAppId(ONESIGNAL_APP_ID);

        Timer("GoToWelcomeScreen", false).schedule(3000){
            startActivity(Intent(this@SplashActivity, SignInActivity::class.java))
            finish()
        }
    }
}