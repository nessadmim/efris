package com.cdtcl.ogmous.models

data class Person(
    val created_at: String,
    val email_address: String,
    val id: Int,
    val name: String,
    val office_people: List<OfficePeople>,
    val password: String,
    val phone_number: String,
    var picture: String?,
    val record_status: String,
    val status: String,
    val updated_at: String
)