package com.cdtcl.ogmous.models

data class Office(
    val created_at: String,
    val id: Int,
    val latitude: String,
    val location: String,
    val longitude: String,
    val name: String,
    val distance: Double?,
    val supervisor_id: String?,
    val supervisor: Supervisor?,
    val record_status: String,
    val updated_at: String
)

data class Supervisor(
    val id: String,
    val name: String,
    val email: String,
    val password: String,
    val created_at: String,
    val updated_at: String
)