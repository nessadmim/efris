package com.cdtcl.ogmous.models

data class AttendanceResponse(
    val attendance: Attendance?,
    val status_code: Int,
    val status_message: String
)