package com.cdtcl.ogmous.ui.home

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.StringRequestListener
import com.cdtcl.ogmous.databinding.ActivityNotesBinding
import com.cdtcl.ogmous.databinding.SingleNoteBinding
import com.cdtcl.ogmous.models.LeaveRequest
import com.cdtcl.ogmous.network.NetworkClient
import com.cdtcl.ogmous.storage.AppPreferences
import com.github.florent37.inlineactivityresult.kotlin.coroutines.startForResult
import com.github.florent37.inlineactivityresult.kotlin.startForResult
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.joda.time.DateTime
import org.joda.time.format.DateTimeFormat
import org.joda.time.format.DateTimeFormatter
import java.text.SimpleDateFormat
import java.util.*

class NotesActivity : AppCompatActivity() {
    private lateinit var adapter: NotesAdapter
    private lateinit var appPreferences: AppPreferences
    private lateinit var binding: ActivityNotesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Notes"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        appPreferences = AppPreferences(this)

        adapter = NotesAdapter(this, mutableListOf()){
            fetchNotes()
        }
        binding.rvNotes.adapter = adapter

        fetchNotes()
    }

    fun createAction(view: android.view.View) {
        startForResult(Intent(this,CreateNotesActivity::class.java)){
            fetchNotes()
        }
    }


    private fun fetchNotes() {

        binding.empty.visibility = View.GONE
        binding.progressBar.visibility = View.VISIBLE

        AndroidNetworking.post("${NetworkClient.baseUrl}get_notes")
            .addBodyParameter("person_id",appPreferences.getPerson()?.id.toString())
            .build()
            .getAsString(object : StringRequestListener {
                override fun onResponse(response: String?) {
                    Log.e(">>>","::${response}")

                    val list: MutableList<Notes> = Gson().fromJson(response, object : TypeToken<List<Notes?>?>() {}.type)
                    adapter.changeList(list)

                    binding.progressBar.visibility = View.GONE
                    binding.empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                }

                override fun onError(anError: ANError?) {
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(this@NotesActivity,"No Internet Connection", Toast.LENGTH_LONG).show()
                }
            } )
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home){
            finish()
        }
        return super.onOptionsItemSelected(item)
    }

}

data class Notes(
    val comment: String?,
    val content: String,
    val created_at: String,
    val id: Int,
    val office_id: Int,
    val person_id: Int,
    val record_status: String,
    val status: String,
    val updated_at: String
)

class NotesAdapter(val context: AppCompatActivity, var list: MutableList<Notes>,val func:()->Unit)
    : RecyclerView.Adapter<NotesAdapter.NotesHolder>() {

    inner class NotesHolder(val binding : SingleNoteBinding)
        : RecyclerView.ViewHolder(binding.root) {
        fun displayViews(obj: Notes) {

            val DATE_FORMAT: DateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss") //Default format
            val chatDateTime: DateTime = DateTime(DATE_FORMAT.parseDateTime(obj.created_at!!.split(".")[0]))

            val SIMPLE_DATE_FORMAT_TODAY = SimpleDateFormat("h:mm a", Locale.getDefault()) //Needed format
            val SIMPLE_DATE_FORMAT_BEFORE = SimpleDateFormat("d MMMM, yyyy", Locale.getDefault()) //Needed format


            val cal: Calendar = chatDateTime.toCalendar(Locale.getDefault())
            binding.time.text = SIMPLE_DATE_FORMAT_TODAY.format(cal.time)
            binding.date.text = SIMPLE_DATE_FORMAT_BEFORE.format(cal.time)

            //binding.position.text = (bindingAdapterPosition+1).toString()

            binding.root.setOnClickListener {
                context.startForResult(Intent(context,CreateNotesActivity::class.java).putExtra("note",Gson().toJson(obj))){
                    func.invoke()
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotesHolder {
        return NotesHolder(SingleNoteBinding.inflate(LayoutInflater.from(context),parent,false))
    }

    override fun onBindViewHolder(holder: NotesHolder, position: Int) {
        holder.displayViews(list[position])
    }

    override fun getItemCount(): Int = list.size
    fun changeList(list: MutableList<Notes>) {
        this.list = list
        notifyDataSetChanged()
    }
}