package com.cdtcl.ogmous.models

data class OfficePeople(
    val created_at: String,
    val id: Int,
    val office: Office,
    val office_id: Int,
    val person_id: Int,
    val record_status: String,
    val rights: String,
    val updated_at: String
)