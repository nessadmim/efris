<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAttendancesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('attendances', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger("person_id");
            $table->date("date")->nullable()->default(null);

            $table->timestamp("start_datetime")->nullable()->default(null);
            $table->string("start_latitude")->nullable()->default(null);
            $table->string("start_longitude")->nullable()->default(null);

            $table->timestamp("end_datetime")->nullable()->default(null);
            $table->string("end_latitude")->nullable()->default(null);
            $table->string("end_longitude")->nullable()->default(null);

            $table->string("comment")->nullable()->default(null);
            $table->string("remarks")->nullable()->default(null);
            $table->enum("record_status",["active","inactive"])->default("active");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('attendances');
    }
}
