<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOfficesPeopleTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('offices_people', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger("person_id");
            $table->unsignedBigInteger("office_id");
            $table->enum("rights",["worker","manager"])->default("worker");
            $table->enum("record_status",["active","inactive"])->default("active");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('offices_people');
    }
}
