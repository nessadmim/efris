<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNotesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('notes', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger("person_id");
            $table->unsignedBigInteger("office_id");
            $table->text("content");
            $table->text("comment")->nullable()->default(null)->comment("added by supervisor/admin");
            $table->enum("status",["pending","accepted","rejected","cancelled","completed"])->default("pending");
            $table->enum("record_status",["active","inactive"])->default("active");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('notes');
    }
}
