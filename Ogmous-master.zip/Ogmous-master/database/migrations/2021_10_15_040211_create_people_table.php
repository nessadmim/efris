<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePeopleTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('people', function (Blueprint $table) {
            $table->id();
            $table->string("name");
            $table->string("phone_number")->nullable()->default(null);
            $table->string("email_address")->nullable()->default(null);
            $table->string("password");
            $table->string("picture")->nullable()->default(null);
            $table->string("player_id")->nullable()->default(null);
            $table->enum("status",["pending","active","blocked"])->default("pending");
            $table->enum("record_status",["active","inactive"])->default("active");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('people');
    }
}
