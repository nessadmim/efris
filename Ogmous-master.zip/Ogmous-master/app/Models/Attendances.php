<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Attendances extends Model{
    use HasFactory;

    protected $fillable = ["person_id","date","start_datetime","start_latitude","start_longitude",
        "end_datetime","end_latitude","end_longitude","comment","remarks","record_status",
    "is_exception"];
}
