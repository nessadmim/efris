<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OfficesPeople extends Model
{
    use HasFactory;

    protected $fillable = ["person_id","office_id","rights","record_status","shift_id"];
}
