<?php

namespace App\Http\Controllers;

use App\Models\Activities;
use App\Models\AdminNotifications;
use App\Models\Notifications;
use App\Models\People;
use Illuminate\Http\Request;

class NotificationsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view("pages.notifications.index",[
            "title"=>"Notifications",
            "description"=>"Shows all the Notifications that are registered.",
            "icon"=>"users",
            "notifications"=>Notifications::all()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Notifications  $notifications
     * @return \Illuminate\Http\Response
     */
    public function show(Notifications $notifications)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Notifications  $notifications
     * @return \Illuminate\Http\Response
     */
    public function edit(Notifications $notifications)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Notifications  $notifications
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Notifications $notifications)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Notifications  $notifications
     * @return \Illuminate\Http\Response
     */
    public function destroy(Notifications $notifications)
    {
        //
    }

    public function api_get_person_notifications(Request $request){
        $person_id = $request->input("person_id");

        return Notifications::where("person_id","=",$person_id)->get();
    }

    public function createPersonNotification($person_id,$type,$title,$content){
        Notifications::create([
            "person_id"=>$person_id,
            "type"=>$type,
            "title"=>$title,
            "content"=>$content,
        ]);

        $person = People::find($person_id);
        if ($person->player_id != "" && $person->player_id != NULL){
            (new OneSignalController())->sendOneSignalNotificationToOne($title,$content,$person->player_id);
        }
    }
}
