<?php

namespace App\Http\Controllers;

use App\Models\Offices;
use App\Models\OfficesPeople;
use App\Models\People;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class PeopleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $searchText = $request->input("searchText");
        $peoples = collect();
        if ($searchText == null || $searchText == ""){
            $peoples = People::where('name', 'LIKE', '%'. $searchText .'%')
                ->orWhere('phone_number', 'LIKE', '%'. $searchText .'%')
                ->orWhere('email_address', 'LIKE', '%'. $searchText .'%')
                ->get();
        }else{
            $peoples = People::all();
        }


        //
        return view("pages.people.index",[
            "title"=>"Employees",
            "searchText"=>$searchText,
            "description"=>"Shows all the Employees that are registered.",
            "icon"=>"users",
            "action"=>"people/create",
            "people"=>$peoples
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view("pages.people.create",[
            "title"=>"Create Employee",
            "description"=>"This can be a Employee.",
            "icon"=>"users"
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $person = People::create([
            "name"=>$request->input("name"),
            "email_address"=>$request->input("email_address"),
            "phone_number"=>$request->input("phone_number"),
            "status"=>"normal",
            "password"=>Hash::make($request->input("password")),
        ]);

        return redirect("people");
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\People  $people
     * @return \Illuminate\Http\Response
     */
    public function show(People $people)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\People  $people
     * @return \Illuminate\Http\Response
     */
    public function edit(People $people,$id)
    {
        //
        return view("pages.people.edit",[
            "title"=>"Employee",
            "description"=>"Edit a Employee.",
            "icon"=>"users",
            "person"=>People::find($id)
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\People  $people
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, People $people,$id)
    {
        //
        $person =People::find($id);
        $person->name = $request->input("name");
        $person->email_address = $request->input("email_address");
        $person->phone_number = $request->input("phone_number");
        $person->status = $request->input("status");
        $person->update();

        return redirect("people");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\People  $people
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $people = People::find($id);
        $people->delete();

        return redirect("people");

    }

    public function api_sign_in(Request $request){
        $helper = new ApiHelper();

        $email_address = $request->input("email_address");
        $password = $request->input("password");

        $error_message = "";
        if ($email_address=="") $error_message = $error_message." Email Address cannot be Empty, ";
        if ($password=="") $error_message = $error_message." Password cannot be Empty, ";

        if ($error_message==""){

            $persons = People::where("email_address","=",$email_address)->get();
            if ($persons->count() == 0){
                return $helper->display(400,"User not found");
            }else{
                $person = $persons->first();
                if(Hash::check($password, $person->password)){
                    //success
                    $person->office_people = OfficesPeople::where("person_id","=",$person->id)
                        ->where("record_status","=","active")
                        ->get()
                        ->map(function ($o){
                            $o->office = Offices::find($o->office_id);
                            $o->office->supervisor = User::find($o->office->supervisor_id);
                            return $o;
                        });
                    return $helper->display(200,"User Found","person",$person);

                }else{
                    //password failed
                    return $helper->display(400,"Passwords do not match");
                }
            }

        }else{
            return $helper->display(400,$error_message);
        }

    }
    public function api_sign_up(Request $request){
        $helper = new ApiHelper();

        $name = $request->input("name");
        $email_address = $request->input("email_address");
        $phone_number = $request->input("phone_number");
        $password = $request->input("password");
        $office_id = $request->input("office_id");
        $status = "pending";

        $error_message = "";
        if ($name=="") $error_message = $error_message." Name cannot be Empty, ";
        if ($email_address=="") $error_message = $error_message." Email Address cannot be Empty, ";
        if ($phone_number=="") $error_message = $error_message." Phone Number cannot be Empty, ";
        if ($password=="") $error_message = $error_message." Password cannot be Empty, ";

        if ($error_message==""){

            $person = People::create([
                "name"=>$name,
                "email_address"=>$email_address,
                "phone_number"=>$phone_number,
                "status"=>$status,
                "password"=>Hash::make($password), ]);


            //create office
            if ($office_id!=""){
                OfficesPeople::create([
                    "office_id"=>$office_id,
                    "person_id"=>$person->id,
                    "rights"=>"worker"
                ]);
            }

            $person->office_people = OfficesPeople::where("person_id","=",$person->id)
                ->where("record_status","=","active")
                ->get()
                ->map(function ($o){
                    $o->office = Offices::find($o->office_id);
                    $o->office->supervisor = User::find($o->office->supervisor_id);
                return $o;
            });

            return $helper->display(200,"User Registered Successfully","person",$person);
        }else{
            return $helper->display(400,$error_message);
        }

    }

    public function api_update(Request $request){
        $helper = new ApiHelper();

        $player_id = $request->input("player_id");
        $person_id = $request->input("person_id");

        $person = People::find($person_id);

        if ($player_id!="" && $player_id!=NULL){
            $person->player_id = $player_id;
        }

        $picture = $request->file("picture");
        if ($picture!=null){
            $random = Str::random(40);
            $new_picture_name = $person_id."-".time()."-".$random.".".$picture->extension();
            $picture->move(public_path("profile"),$new_picture_name);
            $person->picture = $new_picture_name;
        }

        $person->update();

        return $helper->display(200,"Person Updated Successfully","user",$person);
    }

    function api_forgot_password_check(Request $request){
        $helper = new ApiHelper();
        $email_address = $request->input("email_address");

        $people = People::where("email_address","=",$email_address)->get();
        if ($people->count() == 0){
            //notfound
            return $helper->display(400,"Person not found on system");
        }else{
            $person = $people->first();
            (new SendEmailController())->sendForgotPasswordEmail($person->id);
            //success
            return $helper->display(200,"A reset password email has been sent to $email_address.");
        }

    }

    function web_change_password($person_id){
        return view("pages.people.change_password",["person"=>People::find($person_id)]);
    }

    function web_save_password(Request $request, $person_id){
        $person = People::find($person_id);
        $person->password = Hash::make($request->input("password"));
        $person->update();

        return back()->with('message', 'Password Updated Successfully');
    }
}
