<?php

namespace App\Http\Controllers;

use App\Models\LeaveRequests;
use App\Models\Notes;
use App\Models\Offices;
use App\Models\OfficesPeople;
use App\Models\People;
use Illuminate\Http\Request;

class NotesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view("pages.notes.index",[
            "title"=>"Notes",
            "description"=>"Shows all Notes that are submitted.",
            "icon"=>"users",
            "action"=>"",
            "notes"=>Notes::all()->map(function ($row){
                $row->person = People::find($row->person_id);
                $row->office = Offices::find($row->office_id);
                return $row;
            })
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Notes  $notes
     * @return \Illuminate\Http\Response
     */
    public function show(Notes $notes)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Notes  $notes
     * @return \Illuminate\Http\Response
     */
    public function edit(Notes $notes)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Notes  $notes
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Notes $notes)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Notes  $notes
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //

        $people = Notes::find($id);
        $people->delete();

        return redirect("notes");
    }

    public function api_create_notes(Request $request){
        $content = $request->input("content");
        $person_id = $request->input("person_id");

        $notes = Notes::create([
            "person_id"=>$person_id,
            "office_id"=>( (new OfficesPeopleController())->getPersonOfficeId($person_id) ),
            "content"=>$content
        ]);

        (new ActivitiesController())->createActivity("NOTES SUBMITTED",People::find($person_id)->name." submitted notes");
        (new NotificationsController())->createPersonNotification($person_id,"Notes","Notes Submitted","New Notes Submitted");
        (new AdminNotificationsController())->createAdminNotification($person_id,"Notes","Notes Submitted",People::find($person_id)->name." submitted Notes");


        $helper = new ApiHelper();
        return $helper->display(200,"Notes Submitted successfully");

    }
    public function api_get_notes(Request $request){

        $person_id = $request->input("person_id");
        return Notes::where("person_id","=",$person_id)->orderBy("created_at","DESC")->get();
    }
}
