<?php

namespace App\Http\Controllers;

use App\Models\Attendances;
use App\Models\Offices;
use App\Models\People;
use App\Models\Shift;
use Carbon\Carbon;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use function PHPUnit\Framework\isEmpty;

class AttendanceReportController extends Controller
{
    //
    public function index(Request $request){

        $working_time = 8;

        $office_id = $request->input("office_id");
        $start_date = $request->input("start_date");
        $end_date = $request->input("end_date");

        if ($office_id==""){
            $office_id = 1;
        }
        if ($start_date==""){
            $start_date = Carbon::today()->toDateString();
        }
        if ($end_date==""){
            $end_date = Carbon::today()->toDateString();
        }



        /*$b = Attendances::where("office_id","=",$office_id)->whereBetween("date",[$start_date,$end_date]);
        $analysis_punched_in = $b->distinct("person_id")->count();


        $b = Attendances::where("office_id","=",$office_id)->whereBetween("date",[$start_date,$end_date]);
        $analysis_punched_out = $b->whereNotNull("end_datetime")->distinct("person_id")->count();*/

        $b = Attendances::where("office_id","=",$office_id)->whereBetween("date",[$start_date,$end_date]);
        $attendance = $b->get()->map(function ($row) use ($working_time){
            $row->person = People::find($row->person_id);

            $row->hours = round(abs( strtotime($row->start_datetime) - strtotime($row->end_datetime) ) / (60*60) ,2);
            $row->office = ( (new OfficesPeopleController())->getPersonOffice($row->person_id) );

            if ($row->hours<$working_time || $row->end_datetime==""){
                $row->normal_abnormal = "abnormal";
            } else{
                $row->normal_abnormal = "normal";
            }

            return $row;
        });

        /*$left_early = $attendance->filter(function ($value, $key) use ($working_time) {
            return $value['end_datetime'] != "" and $value['hours']<$working_time;
        })->count();
        $left_later = $attendance->filter(function ($value, $key) use ($working_time) {
            return $value['end_datetime'] != "" and $value['hours']>=$working_time;
        })->count();*/



        $begin = new DateTime( $start_date );
        $end   = new DateTime( $end_date );

        $people = collect();
        for($i = $begin; $i <= $end; $i->modify('+1 day')){
            $date =  $i->format("Y-m-d");

            $people_once = DB::table("people")
                ->join("offices_people","offices_people.person_id","=","people.id")
                ->where("offices_people.office_id","=",$office_id)
                ->get(["people.*","offices_people.office_id","offices_people.shift_id"])
                ->map(function ($r) use ($date){

                    //attendance
                    $attendance = Attendances::where("person_id","=",$r->id)->where("date","=",$date)->get()->first();
                    $r->shift = Shift::find($r->shift_id);
                    $r->attendance = $attendance;
                    $r->attendance_state = "X";
                    $r->attendance_state_reason = "Y";
                    $r->mdate = $date;


                    if ($attendance==null){
                        $r->attendance_state = "abnormal";
                        $r->attendance_state_reason = "Not Checked In";
                        return $r;
                    }else{

                        if ($attendance->is_exception == "yes"){
                            $r->attendance_state = "normal";
                            $r->attendance_state_reason = "Exceptional";
                            return $r;
                        }

                        if ($r->attendance->end_datetime == null){
                            $r->attendance_state = "abnormal";
                            $r->attendance_state_reason = "Not Checked Out";
                            return $r;
                        }

                        $start = Carbon::parse($r->attendance->start_datetime);
                        $end = Carbon::parse($r->attendance->end_datetime);

                        $shiftStart = Carbon::now()->setTimeFromTimeString($r->shift->start_time);
                        $shiftEnd = Carbon::now()->setTimeFromTimeString($r->shift->end_time);

                        if($shiftEnd->isBefore($shiftStart)){
                            $shiftEnd = $shiftEnd->addDay();
                        }

                        if ($start->isAfter($shiftStart)){
                            $r->attendance_state = "abnormal";
                            $r->attendance_state_reason = "Started Late";
                            return $r;
                        }

                        if ($end->isBefore($shiftEnd)){
                            $r->attendance_state = "abnormal";
                            $r->attendance_state_reason = "Left Early";
                            return $r;
                        }

                        $r->hours = round(abs( strtotime($r->attendance->start_datetime) - strtotime($r->attendance->end_datetime) ) / (60*60) ,2);
                        $r->attendance_state = "normal";
                        $r->attendance_state_reason = "On Time";
                        return $r;

                        //$r->attendance_state_reason = $start;
                    }

                    return $r;
                });

            if ($people->count() == 0){
                $people = $people_once;
            }else{
                $people = $people->merge($people_once);

            }

            //array_push($people,$people_once);
        }



        //dd($people);

        $on_time = $people->filter(function ($value, $key) {
            return $value->attendance_state_reason == "On Time";
        })->count();
        $left_early = $people->filter(function ($value, $key) {
            return $value->attendance_state_reason == "Left Early";
        })->count();
        $started_late = $people->filter(function ($value, $key) {
            return $value->attendance_state_reason == "Started Late";
        })->count();
        $not_checked_out = $people->filter(function ($value, $key) {
            return $value->attendance_state_reason == "Not Checked Out";
        })->count();
        $not_checked_in = $people->filter(function ($value, $key) {
            return $value->attendance_state_reason == "Not Checked In";
        })->count();
        $total_workers = $people->count();


        return view("pages.attendance_reports.index",[
            "office_id"=>$office_id,
            "start_date"=>$start_date,
            "end_date"=>$end_date,

            "on_time"=>$on_time,
            "left_early"=>$left_early,
            "started_late"=>$started_late,
            "not_checked_out"=>$not_checked_out,
            "not_checked_in"=>$not_checked_in,
            "total_workers"=>$total_workers,
            "abnormal"=>$left_early+$started_late+$not_checked_in+$not_checked_out,
            "normal"=>$on_time,

            "title"=>"Attendances Report",
            "description"=>"Shows all the Attendances that are registered.",
            "icon"=>"users",
            "offices"=>Offices::all(),
            "attendances"=>$attendance,
            "people"=>$people
        ]);



    }

    public function markException(Request $request){

        $person_id = $request->input("person_id");
        $date = $request->input("date");

        $atts = Attendances::where("person_id","=",$person_id)->where("date","=",$date)->get();
        if ($atts->count() == 0){
            $attendance = Attendances::create([
                "person_id"=>$person_id,
                "date"=>$date,
                "office_id"=>( (new OfficesPeopleController())->getPersonOfficeId($person_id) ),
                "is_exception"=>"yes",
            ]);
        }else{
            $attendance = $atts->first();
            $attendance->is_exception = "yes";
            $attendance->save();
        }

        return redirect("reports/attendance");
    }

    public function indexBACKUP(Request $request){

        $working_time = 8;

        $office_id = $request->input("office_id");
        $date = $request->input("date");

        if ($office_id==""){
            $office_id = 1;
        }
        if ($date==""){
            $date = Carbon::today()->toDateString();
        }



        $b = Attendances::where("office_id","=",$office_id)->whereDate("date","=",$date);
        $analysis_punched_in = $b->distinct("person_id")->count();


        $b = Attendances::where("office_id","=",$office_id)->whereDate("date","=",$date);
        $analysis_punched_out = $b->whereNotNull("end_datetime")->distinct("person_id")->count();


        $b = Attendances::where("office_id","=",$office_id)->whereDate("date","=",$date);
        $attendance = $b->get()->map(function ($row) use ($working_time){
            $row->person = People::find($row->person_id);

            $row->hours = round(abs( strtotime($row->start_datetime) - strtotime($row->end_datetime) ) / (60*60) ,2);
            $row->office = ( (new OfficesPeopleController())->getPersonOffice($row->person_id) );

            if ($row->hours<$working_time || $row->end_datetime==""){
                $row->normal_abnormal = "abnormal";
            } else{
                $row->normal_abnormal = "normal";
            }

            return $row;
        });

        $left_early = $attendance->filter(function ($value, $key) use ($working_time) {
            return $value['end_datetime'] != "" and $value['hours']<$working_time;
        })->count();
        $left_later = $attendance->filter(function ($value, $key) use ($working_time) {
            return $value['end_datetime'] != "" and $value['hours']>=$working_time;
        })->count();


        return view("pages.attendance_reports.index",[
            "office_id"=>$office_id,
            "date"=>$date,

            "analysis_punched_in"=>$analysis_punched_in,
            "analysis_punched_out"=>$analysis_punched_out,
            "left_early"=>$left_early,
            "left_later"=>$left_later,

            "title"=>"Attendances Report",
            "description"=>"Shows all the Attendances that are registered.",
            "icon"=>"users",
            "offices"=>Offices::all(),
            "attendances"=>$attendance
        ]);
    }
}
