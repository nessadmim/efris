<?php


namespace App\Http\Controllers;


use App\Models\AnimalBreeds;
use App\Models\Animals;
use App\Models\AnimalTypes;
use App\Models\Farms;
use App\Models\Paddocks;
use Illuminate\Support\Carbon;

class ApiHelper
{

    public function display($status_code,$status_message,$data_name=null,$data_value=null){
        $array = array();
        $array["status_code"] = $status_code;
        $array["status_message"] = $status_message;
        if ($data_name!=null){
            $array[$data_name] = $data_value;
        }
        return $array;
    }

    public function fetchActive($builder){
        return $builder->where("record_status","=","active");
    }

    public function getRemainingDays($d)
    {
        if ($d) {
            $remaining_days = Carbon::now()->diffInDays(Carbon::parse($d));
        } else {
            $remaining_days = 0;
        }

        if (Carbon::parse($d)->isBefore(Carbon::now()))
            $remaining_days = $remaining_days." Past";
        else
            $remaining_days = $remaining_days." Left";


        return $remaining_days;
    }
    public function getRemainingDaysWithSign($d)
    {
        if ($d) {
            $remaining_days = Carbon::now()->diffInDays(Carbon::parse($d));
        } else {
            $remaining_days = 0;
        }

        if (Carbon::parse($d)->isBefore(Carbon::now()))
            $remaining_days = 0 - $remaining_days;
        else
            $remaining_days = $remaining_days - 0;


        return $remaining_days;
    }
    public function leaveRequest_getDaysTakenSoFar($d)
    {
        $r = $this->getRemainingDaysWithSign($d);
        if ($r<0){
            //day spent
            return abs($r);
        }else{
            //not yet touched
            return  0;
        }

        //return $remaining_days;
    }
    public function leaveRequest_getDaysRemainingSoFar($d)
    {
        $r = $this->getRemainingDaysWithSign($d);
        if ($r<0){
            //days used up
            return 0;
        }else{
            //has days remaining
            return  $r;
        }

        //return $remaining_days;
    }

}
