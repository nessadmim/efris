<?php

namespace App\Http\Controllers;

use App\Models\LeaveRequests;
use App\Models\Notifications;
use App\Models\Offices;
use App\Models\OfficesPeople;
use App\Models\Overtime;
use App\Models\People;
use Illuminate\Http\Request;

class OvertimeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view("pages.overtimes.index",[
            "title"=>"Overtime",
            "description"=>"Shows all the overtime Requests that are registered.",
            "icon"=>"users",
            "action"=>"overtimes/create",
            "overtimes"=>Overtime::all()->map(function ($row){
                $row->person = People::find($row->person_id);

                $row->office_people = OfficesPeople::where("person_id","=",$row->person_id)
                    ->where("record_status","=","active")
                    ->get()
                    ->map(function ($o){
                        $o->office = Offices::find($o->office_id);
                        return $o;
                    });

                return $row;
            })
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        return view("pages.overtimes.create",[
            "title"=>"Create Overtime",
            "description"=>"This can be an Overtime Request.",
            "icon"=>"users",
            "people"=>People::all(),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $person_id = $request->input("person_id");
        $farm_user = Overtime::create([
            "person_id"=>$person_id,
            "date"=>$request->input("date"),
            "office_id"=>( (new OfficesPeopleController())->getPersonOfficeId($person_id) ),
            "end_time"=>$request->input("end_time"),
            "start_time"=>$request->input("start_time"),
            "reason"=>$request->input("reason"),
        ]);

        Notifications::create([
            "person_id"=>0,
            "title"=>"NEW OVERTIME REQUEST",
            "content"=>People::find($person_id)->name." is requesting overtime added ",
        ]);

        return redirect("overtimes");
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Overtime  $overtime
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        //
        $request=Overtime::find($id);

        $request->person = People::find($request->person_id);
        $request->office_people = OfficesPeople::where("person_id","=",$request->person_id)
            ->where("record_status","=","active")
            ->get()
            ->map(function ($o){
                $o->office = Offices::find($o->office_id);
                return $o;
            });


        return view("pages.overtimes.show",[
            "title"=>"Overtimes",
            "description"=>"Shows all the Overtimes that are registered.",
            "icon"=>"users",
            "request"=>$request
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Overtime  $overtime
     * @return \Illuminate\Http\Response
     */
    public function edit($id )
    {

        return view("pages.overtimes.edit",[
            "title"=>"Edit Overtime",
            "description"=>"This can be an overtime.",
            "icon"=>"users",
            "people"=>People::all(),
            "leave_request"=>Overtime::find($id)
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Overtime  $overtime
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $leave_request = Overtime::find($id);
        $old_status = $leave_request->status;

        $person_id = $request->input("person_id");
        $leave_request->person_id = $person_id;

        if ($request->input("date")!="")
            $leave_request->date = $request->input("date");

        if ($request->input("start_time")!="")
            $leave_request->start_time = $request->input("start_time");

        if ($request->input("end_time")!="")
            $leave_request->end_time = $request->input("end_time");

        if ($request->input("reason")!="")
            $leave_request->reason = $request->input("reason");

        if ($request->input("comment")!="")
            $leave_request->comment = $request->input("comment");

        if ($request->input("status")!="")
            $leave_request->status = $request->input("status");

        $leave_request->update();

        $m = "";
        $m_a = "";
        if ($old_status != $request->input("status")){
            switch ($request->input("status")){
                case "accepted":
                    $m = "Your Overtime Request was accepted";
                    $m_a = "Overtime Request was accepted";
                    break;
                case "rejected":
                    $m = "Your Overtime Request was rejected";
                    $m_a = "Overtime Request was rejected";
                    break;
                case "cancelled":
                    $m = "Your Overtime Request was Cancelled";
                    $m_a = "Overtime Request was cancelled";
                    break;
                case "completed":
                    $m = "Your Overtime was Completed";
                    $m_a = "Overtime was Completed";
                    break;
            }
        }else{
            $m = "Overtime Request Edited";
            $m_a = "Overtime Request Edited";
        }

        (new ActivitiesController())->createActivity("LEAVE EDITED",People::find($person_id)->name." | ".$m_a);
        (new NotificationsController())->createPersonNotification($person_id,"Leave","Overtime Request Edited",$m);
        (new AdminNotificationsController())->createAdminNotification($person_id,"Leave","Overtime Request Edited",People::find($person_id)->name." | ".$m_a);


        return redirect("overtimes");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Overtime  $overtime
     * @return \Illuminate\Http\Response
     */
    public function destroy(Overtime $overtime)
    {
        //
    }










    function api_create_overtime(Request $request){

        $reason = $request->input("reason");
        $start_time = $request->input("start_time");
        $end_time = $request->input("end_time");
        $date = $request->input("date");
        $person_id = $request->input("person_id");

        $farm_user = Overtime::create([
            "person_id"=>$person_id,
            "date"=>$date,
            "office_id"=>( (new OfficesPeopleController())->getPersonOfficeId($person_id) ),
            "end_time"=>$end_time,
            "start_time"=>$start_time,
            "reason"=>$reason,
        ]);


        (new ActivitiesController())->createActivity("OVERTIME REQUESTED",People::find($person_id)->name." requested for Overtime");
        (new NotificationsController())->createPersonNotification($person_id,"Overtime","Overtime Requested","New Overtime Request Submitted");
        (new AdminNotificationsController())->createAdminNotification($person_id,"Overtime","Overtime Requested",People::find($person_id)->name." requested for Overtime");


        $helper = new ApiHelper();
        return $helper->display(200,"Overtime Submitted successfully");
    }

    function api_get_overtime(Request $request){
        $person_id = $request->input("person_id");

        return Overtime::where("person_id","=",$person_id)->get();
    }
}
