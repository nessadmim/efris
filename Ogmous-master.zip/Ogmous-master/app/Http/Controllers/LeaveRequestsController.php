<?php

namespace App\Http\Controllers;

use App\Models\LeaveRequests;
use App\Models\Notifications;
use App\Models\Offices;
use App\Models\OfficesPeople;
use App\Models\People;
use Illuminate\Http\Request;

class LeaveRequestsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view("pages.leave_requests.index",[
            "title"=>"Leave Requests",
            "description"=>"Shows all the Leave Requests that are registered.",
            "icon"=>"users",
            "action"=>"leave_requests/create",
            "requests"=>LeaveRequests::all()->map(function ($row){
                $row->person = People::find($row->person_id);

                $row->office_people = OfficesPeople::where("person_id","=",$row->person_id)
                    ->where("record_status","=","active")
                    ->get()
                    ->map(function ($o){
                        $o->office = Offices::find($o->office_id);
                        return $o;
                    });

                return $row;
            })
        ]);
    }

    public function indexReports()
    {
        //
        return view("pages.leave_requests.index_reports",[
            "title"=>"Leave Requests Report",
            "description"=>"Shows all analysis of the Leave Requests that are registered.",
            "icon"=>"users",
            "requests"=>LeaveRequests::all()->map(function ($row){
                $row->person = People::find($row->person_id);

                $row->office_people = OfficesPeople::where("person_id","=",$row->person_id)
                    ->where("record_status","=","active")
                    ->get()
                    ->map(function ($o){
                        $o->office = Offices::find($o->office_id);
                        return $o;
                    });

                return $row;
            })
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view("pages.leave_requests.create",[
            "title"=>"Create Leave Request",
            "description"=>"This can be a Leave Request.",
            "icon"=>"users",
            "people"=>People::all(),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $person_id = $request->input("person_id");
        $farm_user = LeaveRequests::create([
            "person_id"=>$person_id,
            "office_id"=>( (new OfficesPeopleController())->getPersonOfficeId($person_id) ),
            "days"=>$request->input("days"),
            "start_date"=>$request->input("start_date"),
            "reason"=>$request->input("reason"),
        ]);

        Notifications::create([
            "person_id"=>0,
            "title"=>"NEW LEAVE",
            "content"=>People::find($person_id)->name." is requesting Leave added ",
        ]);

        return redirect("leave_requests");
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\LeaveRequests  $leaveRequests
     * @return \Illuminate\Http\Response
     */
    public function show(LeaveRequests $leaveRequests,$id)
    {
        //
        $request=LeaveRequests::find($id);

        $request->person = People::find($request->person_id);
        $request->office_people = OfficesPeople::where("person_id","=",$request->person_id)
            ->where("record_status","=","active")
            ->get()
            ->map(function ($o){
                $o->office = Offices::find($o->office_id);
                return $o;
            });


        return view("pages.leave_requests.show",[
            "title"=>"Leave Requests",
            "description"=>"Shows all the Leave Requests that are registered.",
            "icon"=>"users",
            "request"=>$request
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\LeaveRequests  $leaveRequests
     * @return \Illuminate\Http\Response
     */
    public function edit(LeaveRequests $leaveRequests,$id)
    {
        //

        return view("pages.leave_requests.edit",[
            "title"=>"Edit Leave Request",
            "description"=>"This can be a Leave Request.",
            "icon"=>"users",
            "people"=>People::all(),
            "leave_request"=>LeaveRequests::find($id)
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\LeaveRequests  $leaveRequests
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LeaveRequests $leaveRequests, $id)
    {
        //
        $leave_request = LeaveRequests::find($id);
        $old_status = $leave_request->status;

        $person_id = $request->input("person_id");
        $leave_request->person_id = $person_id;

        if ($request->input("days")!="")
        $leave_request->days = $request->input("days");

        if ($request->input("start_date")!="")
        $leave_request->start_date = $request->input("start_date");

        if ($request->input("end_date")!="")
        $leave_request->end_date = $request->input("end_date");

        if ($request->input("reason")!="")
        $leave_request->reason = $request->input("reason");

        if ($request->input("comment")!="")
        $leave_request->comment = $request->input("comment");

        if ($request->input("status")!="")
        $leave_request->status = $request->input("status");

        $leave_request->update();

        $m = "";
        $m_a = "";
        if ($old_status != $request->input("status")){
            switch ($request->input("status")){
                case "accepted":
                    $m = "Your leave request was accepted";
                    $m_a = "Leave request was accepted";
                    break;
                case "rejected":
                    $m = "Your leave request was rejected";
                    $m_a = "Leave request was rejected";
                    break;
                case "cancelled":
                    $m = "Your leave request was Cancelled";
                    $m_a = "Leave request was cancelled";
                    break;
                case "completed":
                    $m = "Your leave was Completed";
                    $m_a = "Leave was Completed";
                    break;
            }
        }else{
            $m = "Leave Request Edited";
            $m_a = "Leave Request Edited";
        }

        (new ActivitiesController())->createActivity("LEAVE EDITED",People::find($person_id)->name." | ".$m_a);
        (new NotificationsController())->createPersonNotification($person_id,"Leave","Leave Request Edited",$m);
        (new AdminNotificationsController())->createAdminNotification($person_id,"Leave","Leave Request Edited",People::find($person_id)->name." | ".$m_a);


        return redirect("leave_requests");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\LeaveRequests  $leaveRequests
     * @return \Illuminate\Http\Response
     */
    public function destroy(LeaveRequests $leaveRequests,$id)
    {
        //

        $people = LeaveRequests::find($id);
        $people->delete();

        return redirect("leave_requests");
    }


    function api_create_leave(Request $request){

        $reason = $request->input("reason");
        $start_date = $request->input("start_date");
        $days = $request->input("days");
        $person_id = $request->input("person_id");

        $farm_user = LeaveRequests::create([
            "person_id"=>$person_id,
            "days"=>$days,
            "office_id"=>( (new OfficesPeopleController())->getPersonOfficeId($person_id) ),
            "start_date"=>$start_date,
            "reason"=>$reason,
        ]);

        (new ActivitiesController())->createActivity("LEAVE REQUESTED",People::find($person_id)->name." requested for ".$days." days leave");
        (new NotificationsController())->createPersonNotification($person_id,"Leave","Leave Requested","New Leave Request Submitted");
        (new AdminNotificationsController())->createAdminNotification($person_id,"Leave","Leave Requested",People::find($person_id)->name." requested for ".$days." days leave");


        $helper = new ApiHelper();
        return $helper->display(200,"Leave Request Submitted successfully");
    }

    function api_get_leave_requests(Request $request){
        $person_id = $request->input("person_id");

        return LeaveRequests::where("person_id","=",$person_id)->get();
    }

}
