<?php

namespace App\Http\Controllers;

use App\Models\LeaveRequests;
use App\Models\Offices;
use App\Models\OfficesPeople;
use App\Models\People;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OfficesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view("pages.offices.index",[
            "title"=>"Sites",
            "description"=>"Shows all the Sites that are registered.",
            "icon"=>"users",
            "action"=>"offices/create",
            "offices"=>Offices::all()->map(function ($o){
                $o->counter = OfficesPeople::where("office_id","=",$o->id)->where("record_status","=","active")->count();
                $o->supervisor = User::find($o->supervisor_id);
                return $o;
            })
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view("pages.offices.create",[
            "title"=>"Create Sites",
            "description"=>"This can be an Site.",
            "icon"=>"users"
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $office = Offices::create([
            "name"=>$request->input("name"),
            "location"=>$request->input("location"),
            "latitude"=>$request->input("latitude"),
            "longitude"=>$request->input("longitude"),
        ]);

        return redirect("offices");
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Offices  $offices
     * @return \Illuminate\Http\Response
     */
    public function show(Offices $offices, $id)
    {
        //
        $office = Offices::find($id);

        $people = OfficesPeople::where("office_id","=",$id)->get()->map(function ($op){
            return People::find($op->person_id);
        });

        $requests = DB::table("leave_requests")
            ->join("offices_people","leave_requests.person_id","=","offices_people.person_id")
            ->where("offices_people.office_id","=",$id)
            ->get()
            ->map(function ($row){
                $row->person = People::find($row->person_id);
                return $row;
            });


        return view("pages.offices.show",[
            "title"=>"Site",
            "description"=>"Shows Site details registered.",
            "icon"=>"users",
            "office"=>$office,
            "people"=>$people,
            "requests"=>$requests
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Offices  $offices
     * @return \Illuminate\Http\Response
     */
    public function edit(Offices $offices,$id)
    {
        //

        $office = Offices::find($id);
        $office->supervisor = User::find($office->supervisor_id);

        return view("pages.offices.edit",[
            "title"=>"Site",
            "description"=>"Edit a Site.",
            "icon"=>"users",
            "users"=>User::all(),
            "office"=>$office
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Offices  $offices
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Offices $offices,$id)
    {
        //
        $office =Offices::find($id);
        $office->name = $request->input("name");
        $office->location = $request->input("location");
        $office->longitude = $request->input("longitude");
        $office->supervisor_id = $request->input("supervisor_id");
        $office->latitude = $request->input("latitude");
        $office->update();

        return redirect("offices");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Offices  $offices
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $v = Offices::find($id);
        $v->delete();

        return redirect("offices");
    }



    public function api_get_offices(Request $request){

        $latitude = $request->input("latitude");
        $longitude = $request->input("longitude");

        $d = new DistanceHelper();

        return Offices::where("record_status","=","active")->get()->map(function ($office) use ($d,$latitude,$longitude){
            $office->distance = $d->vincentyGreatCircleDistance($latitude,$longitude,$office->latitude,$office->longitude);
            return $office;
        });
    }
}
