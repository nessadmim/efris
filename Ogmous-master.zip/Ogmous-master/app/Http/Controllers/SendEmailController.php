<?php

namespace App\Http\Controllers;

use App\Mail\ForgotPasswordMail;
use App\Models\People;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class SendEmailController extends Controller
{
    //
    public function sendForgotPasswordEmail($person_id){

        $person = People::find($person_id);

        $details = [
            'title' => env("APP_NAME").' Change Password Request',
            'body' => 'Hello '.$person->name.', You have requested a password reset, please use the link below to change your password or ignore if it was not requested by you.'.url("user/change_password/".$person_id)
        ];

        Mail::to($person->email_address)->send(new ForgotPasswordMail($details));

    }
}
