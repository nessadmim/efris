<?php

namespace App\Http\Controllers;

use App\Models\LeaveRequests;
use App\Models\Offices;
use App\Models\People;
use App\Models\User;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    //
    function index(){
        return view("pages.dashboard",[
            "title"=>"Dashboard",
            "description"=>"Shows the analysis of all the data around the system",
            "icon"=>"home",

            "total_offices"=>Offices::all()->count(),
            "total_administrators"=>User::all()->count(),
            "total_workers"=>People::all()->count(),
            "total_leave_requests"=>LeaveRequests::all()->count(),

        ]);
    }
}
