<?php

namespace App\Http\Controllers;

use App\Models\People;
use App\Models\Shift;
use Illuminate\Http\Request;

class ShiftsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view("pages.shifts.index",[
            "title"=>"Work Shifts",
            "description"=>"Shows all the shifts that are registered.",
            "icon"=>"users",
            "action"=>"shifts/create",
            "shifts"=>Shift::all()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view("pages.shifts.create",[
            "title"=>"Create Shift",
            "description"=>"This can be a Work Shift.",
            "icon"=>"users",
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $farm_user = Shift::create([
            "name"=>$request->input("name"),
            "start_time"=>$request->input("start_time"),
            "end_time"=>$request->input("end_time"),
        ]);

        return redirect("shifts");
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Shift  $shift
     * @return \Illuminate\Http\Response
     */
    public function show(Shift $shift)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Shift  $shift
     * @return \Illuminate\Http\Response
     */
    public function edit(Shift $shift)
    {
        //
        return view("pages.shifts.edit",[
            "title"=>"Edit Shift",
            "shift"=>$shift,
            "description"=>"This can be a Work Shift.",
            "icon"=>"users",
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Shift  $shift
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Shift $shift)
    {
        //
        $shift->name = $request->input("name");
        $shift->start_time = $request->input("start_time");
        $shift->end_time = $request->input("end_time");
        $shift->update();

        return redirect("shifts");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Shift  $shift
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $shift = Shift::find($id);
        $shift->delete();

        return redirect("shifts");
    }
}
