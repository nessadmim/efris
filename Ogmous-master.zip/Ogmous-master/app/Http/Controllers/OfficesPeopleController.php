<?php

namespace App\Http\Controllers;

use App\Models\Offices;
use App\Models\OfficesPeople;
use App\Models\People;
use App\Models\Shift;
use Illuminate\Http\Request;

class OfficesPeopleController extends Controller
{
    public function index()
    {
        //
        return view("pages.offices_people.index",[
            "title"=>"Sites Employee",
            "description"=>"Shows all the Sites-Employee mapping that are registered.",
            "icon"=>"users",
            "action"=>"offices_people/create",
            "office_people"=>OfficesPeople::all()->map(function ($row){
                $row->person = People::find($row->person_id);
                $row->office = Offices::find($row->office_id);
                $row->shift = Shift::find($row->shift_id);
                return $row;
            })
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view("pages.offices_people.create",[
            "title"=>"Create Sites - Employee Mapping",
            "description"=>"This can be a mapping from farm to Employees.",
            "icon"=>"users",
            "offices"=>Offices::all(),
            "people"=>People::all(),
            "shifts"=>Shift::all(),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        $farm_user = OfficesPeople::create([
            "office_id"=>$request->input("office_id"),
            "person_id"=>$request->input("person_id"),
            "shift_id"=>$request->input("shift_id"),
            "rights"=>$request->input("rights"),
        ]);

        return redirect("offices_people");    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\FarmsUsers  $farmsUsers
     * @return \Illuminate\Http\Response
     */
    public function show(OfficesPeople $farmsUsers)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\FarmsUsers  $farmsUsers
     * @return \Illuminate\Http\Response
     */
    public function edit(OfficesPeople $farmsUsers,$id)
    {
        //

        return view("pages.offices_people.edit",[
            "title"=>"Edit Site - Employee Mapping",
            "description"=>"This can be a mapping from Site to Employees.",
            "icon"=>"users",
            "offices"=>Offices::all(),
            "people"=>People::all(),
            "shifts"=>Shift::all(),
            "office_person"=>OfficesPeople::find($id)
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\FarmsUsers  $farmsUsers
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, OfficesPeople $farmsUsers, $id)
    {
        //

        $office_person =OfficesPeople::find($id);
        $office_person->office_id = $request->input("office_id");
        $office_person->person_id = $request->input("person_id");
        $office_person->shift_id = $request->input("shift_id");
        $office_person->rights = $request->input("rights");
        $office_person->update();

        return redirect("offices_people");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\OfficesPeople  $officesPeople
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //

        $people = OfficesPeople::find($id);
        $people->delete();

        return redirect("offices_people");
    }

    public function getPersonOfficeId($person_id){
        $o = OfficesPeople::where("person_id","=",$person_id)->where("record_status","=","active")->get();

        if ($o->count() == 0)
            return "0";
        else
            return $o->last()->office_id;
    }

    public function getPersonOffice($person_id){
        $o = OfficesPeople::where("person_id","=",$person_id)->where("record_status","=","active")->get();

        if ($o->count() == 0)
            return null;
        else
            return Offices::find($o->last()->office_id);
    }
}
