<?php

namespace App\Http\Controllers;

use App\Models\Activities;
use App\Models\Attendances;
use App\Models\Notifications;
use App\Models\People;
use Carbon\Carbon;
use Illuminate\Http\Request;

class AttendancesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view("pages.attendances.index",[
            "title"=>"Attendance",
            "description"=>"Shows all the Attendances that are registered.",
            "icon"=>"users",
            "attendances"=>Attendances::all()->map(function ($row){
                $row->person = People::find($row->person_id);
                return $row;
            })
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Attendances  $attendances
     * @return \Illuminate\Http\Response
     */
    public function show(Attendances $attendances)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Attendances  $attendances
     * @return \Illuminate\Http\Response
     */
    public function edit(Attendances $attendances)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Attendances  $attendances
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Attendances $attendances)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Attendances  $attendances
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $people = Attendances::find($id);
        $people->delete();

        return redirect("attendances");
    }

    public function api_start_attendance(Request $request){

        $person_id = $request->input("person_id");
        $latitude = $request->input("latitude");
        $longitude = $request->input("longitude");
        $today = Carbon::now()->toDateString();
        $date_time = Carbon::now();

        $attendance = Attendances::create([
            "person_id"=>$person_id,
            "date"=>$today,
            "office_id"=>( (new OfficesPeopleController())->getPersonOfficeId($person_id) ),
            "start_datetime"=>$date_time,
            "start_latitude"=>$latitude,
            "start_longitude"=>$longitude,
        ]);

        (new ActivitiesController())->createActivity("ATTENDANCE STARTED",People::find($person_id)->name." record added at ".$date_time);
        (new NotificationsController())->createPersonNotification($person_id,"Attendance","Punched In","Working Started");
        (new AdminNotificationsController())->createAdminNotification($person_id,"Attendance","Punched In",People::find($person_id)->name." Started working");

        $helper = new ApiHelper();
        return $helper->display(200,"saved successfully");

    }

        public function api_get_person_today_attendance(Request $request)
        {
            $helper = new ApiHelper();

            $person_id = $request->input("person_id");
            $today = Carbon::now()->toDateString();

            $attendance = Attendances::where("person_id","=",$person_id)
                ->where("date","=",$today)
                ->get();

            if ($attendance->count() > 0){
                return $helper->display(200,"Today's Attendance is Already Started","attendance",$attendance->first());
            }else{
                return $helper->display(400,"No Attendance Found for Today");
            }

        }

        public function api_end_attendance(Request $request){

        $person_id = $request->input("person_id");
        $latitude = $request->input("latitude");
        $longitude = $request->input("longitude");
        $today = Carbon::now()->toDateString();
        $date_time = Carbon::now();

        $attendance = Attendances::where("person_id","=",$person_id)->where("date","=",$today)->
        update([
            "end_datetime"=>$date_time,
            "end_latitude"=>$latitude,
            "end_longitude"=>$longitude,
        ]);

            (new ActivitiesController())->createActivity("ATTENDANCE ENDED",People::find($person_id)->name." record ended at ".$date_time);
            (new NotificationsController())->createPersonNotification($person_id,"Attendance","Punched Out","Working Ended");
            (new AdminNotificationsController())->createAdminNotification($person_id,"Attendance","Punched Out",People::find($person_id)->name." stopped working");


            $helper = new ApiHelper();
        return $helper->display(200,"Updated successfully");

    }
}
