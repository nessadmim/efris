## DATABASE

#### OFFICE
- name
- location
- latitude
- longitude
- record_status (active,inactive)

#### PEOPLE
- name
- phone_number
- email_address
- password
- picture
- record_status (active,inactive)

#### OFFICE_PEOPLE
- person_id
- office_id
- rights (worker,manager)
- record_status (active,inactive)

#### LEAVE
- person_id
- days
- start_date
- reason
- status (pending,accepted,rejected,cancelled)
- record_status (active,inactive)

#### ACCESS
- date
- person_id
- start_datetime
- start_latitude
- start_longitude
- end_datetime
- end_latitude
- end_longitude
- record_status (active,inactive)

#### ACTIVITIES
- action
- comment
- record_status (active,inactive)

#### NOTIFICATIONS
- person_id (dashboard is 0)
- title
- content
- record_status (active,inactive)

## API


