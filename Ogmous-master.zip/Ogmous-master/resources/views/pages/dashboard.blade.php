@extends("layouts.layout")

@section("content")

    <div class="row">
        <div class="col-md-6 col-xl-3">
            <a href="{{url("offices")}}">
                <div class="card mb-3 widget-content">
                    <div class="widget-content-outer">
                        <div class="widget-content-wrapper">
                            <div class="widget-content-left">
                                <div class="widget-heading">Total Sites</div>
                                <div class="widget-subheading"></div>
                            </div>
                            <div class="widget-content-right">
                                <div class="widget-numbers text-success">{{$total_offices}}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-6 col-xl-3">
            <a href="{{url("people")}}">
                <div class="card mb-3 widget-content">
                <div class="widget-content-outer">
                    <div class="widget-content-wrapper">
                        <div class="widget-content-left">
                            <div class="widget-heading">Total Employees</div>
                            <div class="widget-subheading"></div>
                        </div>
                        <div class="widget-content-right">
                            <div class="widget-numbers text-warning">{{$total_workers}}</div>
                        </div>
                    </div>
                </div>
            </div>
            </a>
        </div>
        <div class="col-md-6 col-xl-3">
            <a href="{{url("users")}}">
                <div class="card mb-3 widget-content">
                <div class="widget-content-outer">
                    <div class="widget-content-wrapper">
                        <div class="widget-content-left">
                            <div class="widget-heading">Administrators</div>
                            <div class="widget-subheading"></div>
                        </div>
                        <div class="widget-content-right">
                            <div class="widget-numbers text-danger">{{$total_administrators}}</div>
                        </div>
                    </div>
                </div>
            </div>
            </a>
        </div>
        <div class="col-md-6 col-xl-3">
            <a href="{{url("leave_requests")}}">
                <div class="card mb-3 widget-content">
                <div class="widget-content-outer">
                    <div class="widget-content-wrapper">
                        <div class="widget-content-left">
                            <div class="widget-heading">Leave Requests</div>
                            <div class="widget-subheading"></div>
                        </div>
                        <div class="widget-content-right">
                            <div class="widget-numbers text-danger">{{$total_leave_requests}}</div>
                        </div>
                    </div>
                </div>
            </div>
            </a>
        </div>
    </div>

@endsection
