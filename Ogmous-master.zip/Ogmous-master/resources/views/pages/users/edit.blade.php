@extends("layouts.layout")

@section("content")

    <div class="row">


        <div class="col-md-6">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <h5 class="card-title">Edit Office</h5>
                    <form class="" enctype="multipart/form-data" method="post" action="{{url("users/".$user->id)}}">
                        @method("put")
                        @csrf
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Name</label>
                            <input name="name" type="text" value="{{$user->name}}" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Email</label>
                            <input name="email" type="text" value="{{$user->email}}" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Rights</label>
                            <select name="rights" id="exampleSelect" class="form-control">
                                <option
                                    @if("default" == $user->rights)
                                    selected
                                    @endif
                                    value="default">Default</option>
                                <option
                                    @if("super" == $user->rights)
                                    selected
                                    @endif
                                    value="super">Super</option>
                                <option
                                    @if("supervisor" == $user->rights)
                                    selected
                                    @endif
                                    value="supervisor">Supervisor</option>
                            </select>
                        </div>


                        <button class="mt-1 btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>

    </div>

@endsection
