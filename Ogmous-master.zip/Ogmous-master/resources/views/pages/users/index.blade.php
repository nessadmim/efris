@extends("layouts.layout")

@section("content")

    <div class="row">

                <div class="">
                    <table class="mb-0 table table-bordered">
                        <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Rights</th>
                            <th>Created At</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($users as $user)
                            <tr>
                                <th scope="row">{{$user->id}}</th>
                                <td>{{$user->name}}</td>
                                <td>{{$user->email}}</td>
                                <td>{{$user->rights}}</td>
                                <td>{{$user->created_at}}</td>
                                <td>
                                    <a href="#" class="p-2 text-success">View</a>
                                    <a href="users/{{$user->id}}/edit" class="p-2 text-primary">Edit</a>
                                </td>
                            </tr>
                        @endforeach

                        </tbody>
                    </table>
                </div>
            </div>


@endsection
