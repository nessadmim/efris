@extends("layouts.layout")

@section("content")

    <div class="row">

                <div class="table-wrap">
                    <table class="mb-0 table table-bordered">
                        <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Person</th>
                            <th>Date</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Working Hrs</th>
                            <th>Record Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($attendances as $attendance)
                            <tr>
                                <th scope="row">{{$attendance->id}}</th>
                                <td>
                                    @if(is_null($attendance->person))
                                        <span class="text-danger">Deleted</span>
                                    @else
                                        {{$attendance->person->name}}
                                    @endif
                                </td>
                                <td>{{$attendance->date}}</td>
                                @if( !is_null($attendance->start_datetime) )
                                    <td>{{ date('h:i:s a', strtotime($attendance->start_datetime)) }}</td>
                                @endif
                                @if( !is_null($attendance->end_datetime) )
                                    <td>{{ date('h:i:s a', strtotime($attendance->end_datetime)) }}</td>
                                    <td>{{ round(abs( strtotime($attendance->start_datetime) - strtotime($attendance->end_datetime) ) / (60*60) ,2). " hrs" }}</td>
                                @else
                                    <td></td>
                                    <td></td>
                                @endif
                                <td>{{$attendance->record_status}}</td>
                                <td>
                                    <form method="post" action="{{url("attendances/".$attendance->id)}}">
                                        @method("delete")
                                        @csrf
                                        <input type="submit" value="delete" class="btn btn-link text-danger">
                                    </form>
                                </td>
                            </tr>
                        @endforeach

                        </tbody>
                    </table>
                </div>
            </div>

@endsection
