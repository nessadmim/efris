@extends("layouts.layout")

@section("content")

    <div class="row">

                <div class="table-wrap">
                    <table class="mb-0 table table-bordered">
                        <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Action</th>
                            <th>Comment</th>
                            <th>Record Status</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($activities as $activity)
                            <tr>
                                <th scope="row">{{$activity->id}}</th>
                                <td>{{$activity->action}}</td>
                                <td>{{$activity->comment}}</td>
                                <td>{{$activity->record_status}}</td>
                            </tr>
                        @endforeach

                        </tbody>
                    </table>
                </div>
            </div>

@endsection
