@extends("layouts.layout")

@section("content")

    <div class="row">

                <div class="table-wrap">
                    <table class="mb-0 table table-bordered">
                        <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>Content</th>
                            <th>Record Status</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($notifications as $activity)
                            <tr>
                                <th scope="row">{{$activity->id}}</th>
                                <td>{{$activity->title}}</td>
                                <td>{{$activity->content}}</td>
                                <td>{{$activity->record_status}}</td>
                            </tr>
                        @endforeach

                        </tbody>
                    </table>
                </div>
            </div>
@endsection
