@extends("layouts.layout")

@section("content")

    <div class="row">

                <div class="table-wrap">
                    <table class="mb-0 table table-bordered">
                        <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($shifts as $shift)
                            <tr>
                                <th scope="row">{{$shift->id}}</th>
                                <td>{{$shift->name}}</td>
                                <td>{{$shift->start_time}}</td>
                                <td>{{$shift->end_time}}</td>
                                <td>
                                    {{--<a href="shifts/{{$shift->id}}" class="p-2 text-success">Show</a>--}}
                                    <a href="shifts/{{$shift->id}}/edit" class="p-2 text-primary">Edit</a>
                                    <form method="post" action="{{url("shifts/".$shift->id)}}">
                                        @method("delete")
                                        @csrf
                                        <input type="submit" value="delete" class="btn btn-link text-danger">
                                    </form>
                                </td>
                            </tr>
                        @endforeach

                        </tbody>
                    </table>
                </div>
            </div>

@endsection
