@extends("layouts.layout")

@section("content")

    <div class="row">


        <div class="col-md-6">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <h5 class="card-title">Edit Shift</h5>
                    <form class="" enctype="multipart/form-data" method="post" action="{{url("shifts/".$shift->id)}}">
                        @method("put")
                        @csrf

                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Name</label>
                            <input name="name" value="{{$shift->name}}" type="text" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Start Time</label>
                            <input name="start_time" value="{{$shift->start_time}}" type="time" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">End Time</label>
                            <input name="end_time" value="{{$shift->end_time}}" type="time" class="form-control">
                        </div>




                        <button class="mt-1 btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>

    </div>

@endsection
