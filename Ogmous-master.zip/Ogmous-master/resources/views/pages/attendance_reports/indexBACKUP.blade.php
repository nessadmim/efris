@extends("layouts.layout")

@section("content")

    <div class="row">


        <div class="col-12">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <h5 class="card-title">Office Attendance Date</h5>
                    <form class="" enctype="multipart/form-data" method="get" action="{{url("reports/attendance")}}">
                        <div class="row">
                            <div class="position-relative form-group col-6">
                                <select name="office_id" id="exampleSelect" class="form-control">
                                    @foreach($offices as $office)
                                        <option
                                            @if($office_id == $office->id)
                                                selected
                                            @endif
                                            value="{{$office->id}}" >{{$office->name}} | {{$office->location}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="position-relative form-group col-4">
                                <input name="date" value="{{$date}}" type="date" class="form-control">
                            </div>
                            <div class="col-2">
                                <button class="mt-1 btn btn-primary" style="width: 100%">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="row col-12">
            <div class="col-md-4 col-xl-3">
                <div class="card mb-3 widget-content">
                    <div class="widget-content-outer">
                        <div class="widget-content-wrapper">
                            <div class="widget-content-left">
                                <div class="widget-heading">Punched In</div>
                                <div class="widget-subheading"></div>
                            </div>
                            <div class="widget-content-right">
                                <div class="widget-number text-success">{{$analysis_punched_in}}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xl-3">
                <div class="card mb-3 widget-content">
                    <div class="widget-content-outer">
                        <div class="widget-content-wrapper">
                            <div class="widget-content-left">
                                <div class="widget-heading">Punched Out</div>
                                <div class="widget-subheading"></div>
                            </div>
                            <div class="widget-content-right">
                                <div class="widget-number text-success">{{$analysis_punched_out}}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xl-3">
                <div class="card mb-3 widget-content">
                    <div class="widget-content-outer">
                        <div class="widget-content-wrapper">
                            <div class="widget-content-left">
                                <div class="widget-heading">Left Early</div>
                                <div class="widget-subheading"></div>
                            </div>
                            <div class="widget-content-right">
                                <div class="widget-number text-success">{{$left_early}}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xl-3">
                <div class="card mb-3 widget-content">
                    <div class="widget-content-outer">
                        <div class="widget-content-wrapper">
                            <div class="widget-content-left">
                                <div class="widget-heading">Left Later</div>
                                <div class="widget-subheading"></div>
                            </div>
                            <div class="widget-content-right">
                                <div class="widget-number text-success">{{$left_later}}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xl-3">
                <div class="card mb-3 widget-content">
                    <div class="widget-content-outer">
                        <div class="widget-content-wrapper">
                            <div class="widget-content-left">
                                <div class="widget-heading">Not Checked In</div>
                                <div class="widget-subheading"></div>
                            </div>
                            <div class="widget-content-right">
                                <div class="widget-number text-success">{{$not_checked_out}}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xl-3">
                <div class="card mb-3 widget-content">
                    <div class="widget-content-outer">
                        <div class="widget-content-wrapper">
                            <div class="widget-content-left">
                                <div class="widget-heading">Total Workers</div>
                                <div class="widget-subheading"></div>
                            </div>
                            <div class="widget-content-right">
                                <div class="widget-number text-success">{{$total_workers}}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-12">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <h5 class="card-title">Attendance Report</h5>
                    <table class="mb-0 table table-bordered" id="examp">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Normal/Abnormal</th>
                            <th>Person</th>
                            <th>Date</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Working Hrs</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($attendances as $attendance)
                            <tr>
                                <th scope="row">{{$attendance->id}}</th>

                                <td><span class="btn
                                        @if($attendance->normal_abnormal == "normal")
                                        btn-success
                                        @else
                                        btn-danger
                                        @endif">{{$attendance->normal_abnormal}}</span></td>

                                <td>{{$attendance->person->name}}</td>
                                <td>{{$attendance->date}}</td>
                                @if( !is_null($attendance->start_datetime) )
                                    <td>{{ date('h:i:s a', strtotime($attendance->start_datetime)) }}</td>
                                @endif
                                @if( !is_null($attendance->end_datetime) )
                                    <td>{{ date('h:i:s a', strtotime($attendance->end_datetime)) }}</td>
                                    <td>{{ $attendance->hours. " hrs" }}</td>
                                @else
                                    <td></td>
                                    <td></td>
                                @endif

                            </tr>
                        @endforeach

                        </tbody>
                    </table>

                    <script src="{{url("jquery-3.6.0.min.js")}}"></script>
                    <script src="{{url("jquery.dataTables.min.js")}}"></script>
                    <script src="https://cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.min.js"></script>
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
                    <script src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js"></script>
                    <script src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.print.min.js"></script>
                    <script >
                        $(document).ready(function() {
                            $('#examp').DataTable( {
                                dom: 'Bfrtip',
                                buttons: [
                                    'copy', 'csv', 'excel', 'pdf', 'print'
                                ]
                            });
                        } );
                    </script>
                </div>
            </div>
        </div>
    </div>


@endsection
