@extends("layouts.layout")

@section("content")

    <div class="row">

                <div class="table-wrap">
                    <table class="mb-0 table table-bordered">
                        <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Office</th>
                            <th>Person</th>
                            <th>Content</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($notes as $activity)
                            <tr>
                                <th scope="row">{{$activity->id}}</th>
                                <td>

                                    @if(is_null($activity->office))
                                        <span class="text-danger">Deleted</span>
                                    @else
                                        {{$activity->office->name}}
                                    @endif
                                </td>
                                <td>
                                    @if(is_null($activity->person))
                                        <span class="text-danger">Deleted</span>
                                    @else
                                        {{$activity->person->name}}
                                    @endif
                                </td>
                                <td>{!! $activity->content !!}</td>
                                <td>{{$activity->created_at}}</td>
                                <td>
                                    <form method="post" action="{{url("notes/".$activity->id)}}">
                                        @method("delete")
                                        @csrf
                                        <input type="submit" value="delete" class="btn btn-link text-danger">
                                    </form>
                                </td>
                            </tr>
                        @endforeach

                        </tbody>
                    </table>
                </div>
            </div>

@endsection
