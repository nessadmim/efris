@extends("layouts.layout")

@section("content")

    <div class="row">

                <div class="table-wrap">
                    <table class="mb-0 table table-bordered"  style="display: block; overflow-x: auto; white-space: nowrap;">
                        <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Person</th>
                            <th>Days</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($requests as $request)
                            <tr>
                                <th scope="row">{{$request->id}}</th>
                                <td>
                                    <b>{{$request->person->name}}</b>
                                    <br>
                                    @if($request->office_people->count()!=0)
                                        @if(is_null($request->office_people->first()->office))
                                            <span class="text-danger">Deleted</span>
                                        @else
                                            {{$request->office_people->first()->office->name}}
                                        @endif
                                    @endif
                                </td>
                                <td>{{$request->days}}</td>
                                <td>{{$request->start_date}}</td>
                                <td>
                                    @if(!is_null($request->end_date))
                                        {{$request->end_date}}({{ (new \App\Http\Controllers\ApiHelper())->getRemainingDays($request->end_date) }})
                                    @endif
                                </td>
                                <td>
                                    <span class="btn
                                    @switch($request->status)
                                        @case("pending")
                                            btn-primary
                                            @break
                                        @case("accepted")
                                            btn-secondary
                                            @break
                                        @case("rejected")
                                            btn-danger
                                            @break
                                        @case("cancelled")
                                            btn-dark
                                            @break
                                        @case("completed")
                                            btn-success
                                            @break
                                        @default
                                            btn-info
                                    @endswitch
                                    ">{{$request->status}}</span>
                                </td>
                                <td style="min-width: 250px;">
                                    <div class="row">
                                    <a href="leave_requests/{{$request->id}}" class="p-2 mr-2 text-success">Show</a>
                                    <a href="leave_requests/{{$request->id}}/edit" class="p-2 mr-2 text-primary">Edit</a>
                                    <form method="post" action="{{url("leave_requests/".$request->id)}}">
                                        @method("delete")
                                        @csrf
                                        <input type="submit" value="delete" class="btn btn-link text-danger">
                                    </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach

                        </tbody>
                    </table>
        </div>
    </div>

@endsection
