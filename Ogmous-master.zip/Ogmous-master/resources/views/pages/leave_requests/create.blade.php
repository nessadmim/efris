@extends("layouts.layout")

@section("content")

    <div class="row">


        <div class="col-md-6">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <h5 class="card-title">Create Leave Request</h5>
                    <form class="" enctype="multipart/form-data" method="post" action="{{url("leave_requests")}}">
                        @method("post")
                        @csrf

                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Person</label>
                            <select name="person_id" id="exampleSelect" class="form-control">
                                @foreach($people as $person)
                                <option value="{{$person->id}}" >{{$person->name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Days</label>
                            <input name="days" type="number" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Start Date</label>
                            <input name="start_date" type="date" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Reason</label>
                            <input name="reason" type="text" class="form-control">
                        </div>




                        <button class="mt-1 btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>

    </div>

@endsection
