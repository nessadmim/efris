@extends("layouts.layout")

@section("content")

    <div class="row">

        <div class="col-12 row">
            <div class="col-md-6">
                <div class="main-card mb-3 card">
                    <div class="card-body">
                        <h5 class="card-title">Person</h5>
                        <div>
                            <h5>{{$request->person->name}}</h5>
                            <p><b>Phone Number:</b> {{$request->person->phone_number}}</p>
                            <p><b>Email:</b> {{$request->person->email_address}}</p>
                        </div>
                        <hr>
                        <h5 class="card-title">Office</h5>
                        <div>
                            <h5>{{$request->office_people->first()->office->name}}</h5>

                            <p><b>Location:</b> {{$request->office_people->first()->office->location}}</p>
                            <p><b>Rights:</b> {{$request->office_people->first()->rights}}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="main-card mb-3 card bg-success text-white">
                    <div class="card-body">
                        <h5 class="card-title text-white">Show Details</h5>
                        <div>
                            <p><b>Date:</b> {{$request->date}}</p>
                            <p><b>Reason:</b> {{$request->reason}}</p>
                            <p><b>Start Time:</b> {{$request->start_time}}</p>
                        </div>
                        <hr>
                        <div>
                            <p><b>End Date: </b>
                                @if(!is_null($request->end_time))
                                    {{$request->end_time}}
                                @endif
                            </p>
                            <p><b>Comment:</b> {{$request->comment}}</p>
                            <p><b>Status:</b> {{$request->status}}</p>
                        </div>

                        <a href="{{url("overtimes/".$request->id."/edit")}}" class="btn btn-dark">Edit Request</a>
                    </div>
                </div>
            </div>
        </div>


    </div>

@endsection
