@extends("layouts.layout")

@section("content")

    <div class="row">


        <div class="col-md-6">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <h5 class="card-title">Edit Overtime</h5>
                    <form class="" enctype="multipart/form-data" method="post" action="{{url("overtimes/".$leave_request->id)}}">
                        @method("put")
                        @csrf

                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Person</label>
                            <select name="person_id" id="exampleSelect" class="form-control">
                                @foreach($people as $person)
                                    <option
                                        @if($person->id == $leave_request->person_id)
                                        selected
                                        @endif
                                        value="{{$person->id}}" >{{$person->name}}</option>
                                @endforeach
                            </select>
                        </div>


                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Days</label>
                            <input name="date" value="{{$leave_request->date}}" type="date" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Start Date</label>
                            <input name="start_time" value="{{$leave_request->start_time}}" type="time" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">End Date</label>
                            <input name="end_time" value="{{$leave_request->end_time}}" type="time" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Reason</label>
                            <input name="reason" type="text" value="{{$leave_request->reason}}"  class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Comment</label>
                            <input name="comment" type="text" value="{{$leave_request->comment}}"  class="form-control">
                        </div>



                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Rights</label>
                            <select name="status" id="exampleSelect" class="form-control">
                                <option
                                    @if("pending" == $leave_request->status)
                                    selected
                                    @endif
                                    value="pending">Pending</option>
                                <option
                                    @if("accepted" == $leave_request->status)
                                    selected
                                    @endif
                                    value="accepted">Accepted</option>
                                <option
                                    @if("rejected" == $leave_request->status)
                                    selected
                                    @endif
                                    value="rejected">Rejected</option>
                                <option
                                    @if("cancelled" == $leave_request->status)
                                    selected
                                    @endif
                                    value="cancelled">Cancelled</option>
                                <option
                                    @if("completed" == $leave_request->status)
                                    selected
                                    @endif
                                    value="completed">Completed</option>
                            </select>
                        </div>





                        <button class="mt-1 btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>

    </div>

@endsection
