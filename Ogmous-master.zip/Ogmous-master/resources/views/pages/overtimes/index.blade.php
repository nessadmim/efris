@extends("layouts.layout")

@section("content")

    <div class="row">

                <div class="table-wrap">
                    <table class="mb-0 table table-bordered">
                        <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Person</th>
                            <th>Date</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($overtimes as $request)
                            <tr>
                                <th scope="row">{{$request->id}}</th>
                                <td>
                                    <b>
                                        @if(is_null($request->person))
                                            <span class="text-danger">Deleted</span>
                                        @else
                                            {{$request->person->name}}
                                        @endif
                                    </b>
                                    <br>
                                    @if($request->office_people->count()!=0)
                                        @if(is_null($request->office_people->first()->office))
                                            <span class="text-danger">Deleted</span>
                                        @else
                                            {{$request->office_people->first()->office->name}}
                                        @endif
                                    @endif
                                </td>
                                <td>{{$request->date}}</td>
                                <td>{{$request->start_time}}</td>
                                <td>
                                    @if(!is_null($request->end_time))
                                        {{$request->end_time}}
                                    @endif
                                </td>
                                <td>{{$request->reason}}</td>
                                <td>
                                    <span class="btn
                                    @switch($request->status)
                                        @case("pending")
                                            btn-primary
                                            @break
                                        @case("accepted")
                                            btn-secondary
                                            @break
                                        @case("rejected")
                                            btn-danger
                                            @break
                                        @case("cancelled")
                                            btn-dark
                                            @break
                                        @case("completed")
                                            btn-success
                                            @break
                                        @default
                                            btn-info
                                    @endswitch
                                    ">{{$request->status}}</span>
                                </td>
                                <td>
                                    <a href="overtimes/{{$request->id}}" class="p-2 text-success">Show</a>
                                    <a href="overtimes/{{$request->id}}/edit" class="p-2 text-danger">Edit</a>
                                </td>
                            </tr>
                        @endforeach

                        </tbody>
                    </table>
                </div>
            </div>

@endsection
