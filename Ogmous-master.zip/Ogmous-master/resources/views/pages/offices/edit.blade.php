@extends("layouts.layout")

@section("content")

    <div class="row">


        <div class="col-md-6">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <h5 class="card-title">Edit Site</h5>
                    <form class="" enctype="multipart/form-data" method="post" action="{{url("offices/".$office->id)}}">
                        @method("put")
                        @csrf
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Name</label>
                            <input name="name" type="text" value="{{$office->name}}" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Location</label>
                            <input name="location" type="text" value="{{$office->location}}" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Latitude</label>
                            <input name="latitude" type="text" value="{{$office->latitude}}" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Longitude</label>
                            <input name="longitude" type="text" value="{{$office->longitude}}" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Supervisor/Users</label>
                            <select name="supervisor_id" id="exampleSelect" class="form-control">
                                @foreach($users as $user)
                                    <option
                                        @if($user->id == $user->supervisor_id)
                                        selected
                                        @endif
                                        value="{{$user->id}}" >{{$user->name}}</option>
                                @endforeach
                            </select>
                        </div>


                        <button class="mt-1 btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>

    </div>

@endsection
