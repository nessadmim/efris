@extends("layouts.layout")

@section("content")

    <div class="row">

        <div class="table-wrap">
                    <table class="mb-0 table "  style="display: block; overflow-x: auto; white-space: nowrap;">
                        <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Location</th>
                            <th>GPS</th>
                            <th>Supervisor</th>
                            <th>Workers</th>
                            <th style="min-width: 250px;">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($offices as $office)
                            <tr>
                                <th scope="row">{{$office->id}}</th>
                                <td>{{$office->name}}</td>
                                <td>{{$office->location}}</td>
                                <td>{{$office->latitude}},{{$office->longitude}}</td>
                                @if($office->supervisor_id==null)
                                    <td>{{"NULL"}}</td>
                                @else
                                    <td>{{$office->supervisor->name}}</td>
                                @endif
                                <td>{{$office->counter}}</td>
                                <td style="min-width: 250px;">
                                    <div class="row">
                                        <a href="offices/{{$office->id}}" class="p-2 mr-2 text-success">Show</a>
                                        <a href="offices/{{$office->id}}/edit" class="p-2 mr-2 text-danger">Edit</a>
                                        <form method="post" action="{{url("offices/".$office->id)}}">
                                            @method("delete")
                                            @csrf
                                            <input type="submit" value="delete" class="btn btn-link text-danger">
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach

                        </tbody>
                    </table>
                </div>

    </div>

@endsection
