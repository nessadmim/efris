@extends("layouts.layout")

@section("content")

    <div class="row">

        <div class="col-12 row">
            <div class="col-md-6">
                <div class="main-card mb-3 card">
                    <div class="card-body">
                        <h5 class="card-title">Office Details</h5>
                        <div>
                            <h3>{{$office->name}}</h3>
                            <p>{{$office->location}}</p>
                            <p>Current Status : {{$office->record_status}}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 row">
                <div class="col-md-6">
                    <div class="card mb-3 widget-content">
                        <div class="widget-content-outer">
                            <div class="widget-content-wrapper">
                                <div class="widget-content-left">
                                    <div class="widget-heading">Workers</div>
                                    <div class="widget-subheading"></div>
                                </div>
                                <div class="widget-content-right">
                                    <div class="widget-numbers text-danger">{{$people->count()}}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card mb-3 widget-content">
                        <div class="widget-content-outer">
                            <div class="widget-content-wrapper">
                                <div class="widget-content-left">
                                    <div class="widget-heading">Today Attendance</div>
                                    <div class="widget-subheading"></div>
                                </div>
                                <div class="widget-content-right">
                                    <div class="widget-numbers text-danger">00/{{$people->count()}}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card mb-3 widget-content">
                        <div class="widget-content-outer">
                            <div class="widget-content-wrapper">
                                <div class="widget-content-left">
                                    <div class="widget-heading">---</div>
                                    <div class="widget-subheading"></div>
                                </div>
                                <div class="widget-content-right">
                                    <div class="widget-numbers text-danger">---</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card mb-3 widget-content">
                        <div class="widget-content-outer">
                            <div class="widget-content-wrapper">
                                <div class="widget-content-left">
                                    <div class="widget-heading">---</div>
                                    <div class="widget-subheading"></div>
                                </div>
                                <div class="widget-content-right">
                                    <div class="widget-numbers text-danger">---</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 row">
            <div class="col-lg-6">
                <div class=" mb-3">
                    <div class="" style="height: 400px; overflow-y: auto">
                        <h5 class="card-title">Workers</h5>
                        <table class="mb-0 table">
                            <thead class="thead-dark">
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Phone Number</th>
                                <th>Attendance Today</th>
                                <th>Start Time</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($people as $person)
                                <tr>
                                    <th scope="row">{{$person->id}}</th>
                                    <td>{{$person->name}}</td>
                                    <td>{{$person->phone_number}}</td>
                                    <td>0000</td>
                                    <td>00:00</td>
                                    <td>
                                        <a href="#" class="p-2 text-success">View</a>
                                    </td>
                                </tr>
                            @endforeach

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="mb-3">
                    <div class="" style="height: 400px; overflow-y: auto">
                        <h5 class="card-title">Leave Requests</h5>
                        <table class="mb-0 table">
                            <thead class="thead-dark">
                            <tr>
                                <th>#</th>
                                <th>Person</th>
                                <th>Days</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($requests as $request)
                                <tr>
                                    <th scope="row">{{$request->id}}</th>
                                    <td>{{$request->person->name}}</td>
                                    <td>{{$request->days}}</td>
                                    <td>{{$request->start_date}}</td>
                                    <td>{{$request->end_date}}</td>
                                    <td>
                                    <span class="btn
                                    @switch($request->status)
                                    @case("pending")
                                        btn-primary
@break
                                    @case("accepted")
                                        btn-secondary
@break
                                    @case("rejected")
                                        btn-danger
@break
                                    @case("cancelled")
                                        btn-dark
@break
                                    @case("completed")
                                        btn-success
@break
                                    @default
                                        btn-info
@endswitch
                                        ">{{$request->status}}</span>
                                    </td>
                                </tr>
                            @endforeach

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>

@endsection
