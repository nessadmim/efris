@extends("layouts.layout")

@section("content")

    <div class="row">


        <div class="col-md-6">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <h5 class="card-title">Edit Office</h5>
                    <form class="" enctype="multipart/form-data" method="post" action="{{url("people/".$person->id)}}">
                        @method("put")
                        @csrf
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Name</label>
                            <input name="name" type="text" value="{{$person->name}}" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Phone Number</label>
                            <input name="phone_number" type="text" value="{{$person->phone_number}}" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Email Address</label>
                            <input name="email_address" type="text" value="{{$person->email_address}}" class="form-control">
                        </div>


                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Status</label>
                            <select name="status" id="exampleSelect" class="form-control">
                                <option
                                    @if("pending" == $person->status)
                                    selected
                                    @endif
                                    value="pending">Pending</option>
                                <option
                                    @if("active" == $person->status)
                                    selected
                                    @endif
                                    value="active">Active</option>
                                <option
                                    @if("blocked" == $person->status)
                                    selected
                                    @endif
                                    value="blocked">Blocked</option>
                            </select>
                        </div>
                        <button class="mt-1 btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>

    </div>

@endsection
