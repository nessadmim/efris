@extends("layouts.layout")

@section("content")

    <div class="row">


        <div class="col-md-6">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <h5 class="card-title">Create Person</h5>
                    <form class="" enctype="multipart/form-data" method="post" action="{{url("people")}}">
                        @method("post")
                        @csrf
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Name</label>
                            <input name="name" type="text" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Email Address</label>
                            <input name="email_address" type="text" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Phone Number</label>
                            <input name="phone_number" value="+256" type="text" class="form-control">
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Password</label>
                            <input name="password" value="123456789" type="password" class="form-control">
                        </div>


                        <button class="mt-1 btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>

    </div>

@endsection
