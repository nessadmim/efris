@extends("layouts.layout")

@section("content")

            <div class="row">

                <div class="col-12">
                    <div class="main-card mb-3 card">
                        <div class="card-body">
                            <h5 class="card-title">Search</h5>
                            <form class="" enctype="multipart/form-data" method="get" action="{{url("people")}}">
                                <div class="row">

                                    <div class="position-relative form-group col-lg-10 col-sm-12">
                                        <input name="searchText" value="{{$searchText}}" type="text" placeholder="Search Text" class="form-control">
                                    </div>
                                    <div class="col-lg-2 col-sm-12">
                                        <button class="mt-1 btn btn-primary" style="width: 100%">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>


                <div class="table-wrap">
                    <table class="mb-0 table "  style="display: block; overflow-x: auto; white-space: nowrap;">
                        <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Phone Number</th>
                            <th>Email Address</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($people as $person)
                            <tr>
                                <th scope="row">{{$person->id}}</th>
                                <td>{{$person->name}}</td>
                                <td>{{$person->phone_number}}</td>
                                <td>{{$person->email_address}}</td>
                                <td>{{$person->status}}</td>
                                <td style="min-width: 250px;">
                                    {{--<a href="#" class="p-2 text-success">View</a>--}}
                                    <div class="row">
                                        <a href="people/{{$person->id}}/edit" class="p-2 mr-2  text-primary">Edit</a>
                                        <form method="post" action="{{url("people/".$person->id)}}">
                                            @method("delete")
                                            @csrf
                                            <input type="submit" value="delete" class="btn btn-link text-danger">
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach

                        </tbody>
                    </table>
                </div>
            </div>


@endsection
