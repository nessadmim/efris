@extends("layouts.layout")

@section("content")

    <div class="row">

                <div class="table-wrap">
                    <table class="mb-0 table table-bordered">
                        <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Site</th>
                            <th>Shift</th>
                            <th>Person</th>
                            <th>Rights</th>
                            <th>Record Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($office_people as $office_person)
                            <tr>
                                <th scope="row">{{$office_person->id}}</th>
                                <td>
                                    @if(is_null($office_person->office))
                                        <span class="text-danger">Deleted</span>
                                    @else
                                        {{$office_person->office->name}} | {{$office_person->office->location}}
                                    @endif
                                </td>
                                <td>
                                    @if(is_null($office_person->shift))
                                        <span class="text-danger">Deleted</span>
                                    @else
                                        {{$office_person->shift->name}}
                                    @endif
                                </td>
                                <td>
                                    @if(is_null($office_person->person))
                                        <span class="text-danger">Deleted</span>
                                    @else
                                        {{$office_person->person->name}}
                                    @endif
                                </td>
                                <td>{{$office_person->rights}}</td>
                                <td>{{$office_person->record_status}}</td>
                                <td>
                                    <a href="offices_people/{{$office_person->id}}/edit" class="p-2 text-primary">Edit</a>
                                    <form method="post" action="{{url("offices_people/".$office_person->id)}}">
                                        @method("delete")
                                        @csrf
                                        <input type="submit" value="delete" class="btn btn-link text-danger">
                                    </form>
                                </td>
                            </tr>
                        @endforeach

                        </tbody>
                    </table>
                </div>
            </div>

@endsection
