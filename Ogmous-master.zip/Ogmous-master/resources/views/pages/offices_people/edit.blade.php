@extends("layouts.layout")

@section("content")

    <div class="row">


        <div class="col-md-6">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <h5 class="card-title">Edit Office Person</h5>
                    <form class="" enctype="multipart/form-data" method="post" action="{{url("offices_people/".$office_person->id)}}">
                        @method("put")
                        @csrf

                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Farms</label>
                            <select name="office_id" id="exampleSelect" class="form-control">
                                @foreach($offices as $office)
                                    <option
                                        @if($office->id == $office_person->office_id)
                                            selected
                                        @endif
                                        value="{{$office->id}}" >{{$office->name}} | {{$office->location}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Person</label>
                            <select name="person_id" id="exampleSelect" class="form-control">
                                @foreach($people as $person)
                                    <option
                                        @if($person->id == $office_person->person_id)
                                        selected
                                        @endif
                                        value="{{$person->id}}" >{{$person->name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Shift</label>
                            <select name="shift_id" id="exampleSelect" class="form-control">
                                @foreach($shifts as $shift)
                                    <option
                                        @if($shift->id == $office_person->shift_id)
                                        selected
                                        @endif
                                        value="{{$shift->id}}" >{{$shift->name}} | {{$shift->start_time}} - {{$shift->end_time}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Rights</label>
                            <select name="rights" id="exampleSelect" class="form-control">
                                <option
                                    @if("worker" == $office_person->rights)
                                    selected
                                    @endif
                                    value="worker">Worker</option>
                                <option
                                    @if("manager" == $office_person->rights)
                                    selected
                                    @endif
                                    value="manager">Manager</option>
                            </select>
                        </div>





                        <button class="mt-1 btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>

    </div>

@endsection
