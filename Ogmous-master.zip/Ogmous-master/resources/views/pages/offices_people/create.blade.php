@extends("layouts.layout")

@section("content")

    <div class="row">


        <div class="col-md-6">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <h5 class="card-title">Create Office - People Mapping</h5>
                    <form class="" enctype="multipart/form-data" method="post" action="{{url("offices_people")}}">
                        @method("post")
                        @csrf
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Offices</label>
                            <select name="office_id" id="exampleSelect" class="form-control">
                                @foreach($offices as $office)
                                    <option value="{{$office->id}}" >{{$office->name}} | {{$office->location}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Person</label>
                            <select name="person_id" id="exampleSelect" class="form-control">
                                @foreach($people as $person)
                                <option value="{{$person->id}}" >{{$person->name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Shift</label>
                            <select name="shift_id" id="exampleSelect" class="form-control">
                                @foreach($shifts as $shift)
                                <option value="{{$shift->id}}" >{{$shift->name}} | {{$shift->start_time}} - {{$shift->end_time}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="position-relative form-group">
                            <label for="exampleEmail" class="">Rights</label>
                            <select name="rights" id="exampleSelect" class="form-control">
                                <option value="worker">Worker</option>
                                <option value="manager">Manager</option>
                            </select>
                        </div>




                        <button class="mt-1 btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>

    </div>

@endsection
