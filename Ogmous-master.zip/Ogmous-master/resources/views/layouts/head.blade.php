<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Content-Language" content="en">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>{{$title}}</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
<meta name="description" content="Highly configurable boxes best used for showing numbers in an user friendly way.">
<meta name="msapplication-tap-highlight" content="no">


<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="{{url("truenorth_table")}}/css/style.css">

<link href="{{url("main.css")}}" rel="stylesheet">
<link href="{{url("jquery.dataTables.min.css")}}" rel="stylesheet">
<link href="https://cdn.datatables.net/buttons/2.0.1/css/buttons.dataTables.min.css" rel="stylesheet">

{{--
<link href="{{url("jquery-3.6.0.min.js")}}" rel="script">
<link href="{{url("jquery.dataTables.min.css")}}" rel="stylesheet">
--}}

