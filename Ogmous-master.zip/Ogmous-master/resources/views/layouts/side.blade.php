
<div class="scrollbar-sidebar">
    <div class="app-sidebar__inner" style="
                height: 600px;
              overflow-y: scroll;
            ">
        <ul class="vertical-nav-menu">
            <li class="app-sidebar__heading">Dashboards</li>
            <li><a href="{{url("dashboard")}}"><i class="metismenu-icon pe-7s-home"></i>Dashboard</a></li>
            <li><a href="{{url("offices")}}"><i class="metismenu-icon pe-7s-map-marker"></i>Sites</a></li>
            <li><a href="{{url("people")}}"><i class="metismenu-icon pe-7s-users"></i>Employees</a></li>
            <li><a href="{{url("offices_people")}}"><i class="metismenu-icon pe-7s-users"></i>Site - Employees</a></li>
            <li class="app-sidebar__heading">Records</li>
            <li><a href="{{url("leave_requests")}}"><i class="metismenu-icon pe-7s-hammer"></i>Leave Requests</a></li>
            <li><a href="{{url("overtimes")}}"><i class="metismenu-icon pe-7s-hammer"></i>Overtime</a></li>
            <li><a href="{{url("attendances")}}"><i class="metismenu-icon pe-7s-hammer"></i>Attendance</a></li>
            <li><a href="{{url("notes")}}"><i class="metismenu-icon pe-7s-hammer"></i>Notes</a></li>
            <li class="app-sidebar__heading">Reports</li>
            <li><a href="{{url("reports/attendance")}}"><i class="metismenu-icon pe-7s-way"></i>Attendance</a></li>
            <li><a href="{{url("reports/leave_requests")}}"><i class="metismenu-icon pe-7s-way"></i>Leave Requests</a></li>
            <li class="app-sidebar__heading">Others</li>
            <li><a href="{{url("shifts")}}"><i class="metismenu-icon pe-7s-way"></i>Shifts</a></li>
            <li><a href="{{url("notifications")}}"><i class="metismenu-icon pe-7s-way"></i>Notifications</a></li>
            <li><a href="{{url("activities")}}"><i class="metismenu-icon pe-7s-way"></i>Activities</a></li>
            <li><a href="{{url("users")}}"><i class="metismenu-icon pe-7s-user"></i>Administrators</a></li>



        </ul>
    </div>
</div>
