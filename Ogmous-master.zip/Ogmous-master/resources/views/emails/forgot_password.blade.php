<!DOCTYPE html>
<html>
<head>
    <title>{{env("APP_NAME")}}</title>
</head>
<body>
<h1>Change Password Request</h1>
<p>{{ $details['body'] }}</p>

<p>Thank you</p>
</body>
</html>
