<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|

| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post("sign_in",[\App\Http\Controllers\PeopleController::class,"api_sign_in"]);

Route::get("sign_in_again",[\App\Http\Controllers\PeopleController::class,"api_sign_in"]);

Route::post("sign_up",[\App\Http\Controllers\PeopleController::class,"api_sign_up"]);
Route::post("update_person",[\App\Http\Controllers\PeopleController::class,"api_update"]);

Route::post("get_person_today_attendance",[\App\Http\Controllers\AttendancesController::class,"api_get_person_today_attendance"]);
Route::post("start_attendance",[\App\Http\Controllers\AttendancesController::class,"api_start_attendance"]);
Route::post("end_attendance",[\App\Http\Controllers\AttendancesController::class,"api_end_attendance"]);

Route::post("create_leave_request",[\App\Http\Controllers\LeaveRequestsController::class,"api_create_leave"]);
Route::post("get_leave_request",[\App\Http\Controllers\LeaveRequestsController::class,"api_get_leave_requests"]);

Route::post("create_overtime",[\App\Http\Controllers\OvertimeController::class,"api_create_overtime"]);
Route::post("get_overtime",[\App\Http\Controllers\OvertimeController::class,"api_get_overtime"]);

Route::post("get_notifications",[\App\Http\Controllers\NotificationsController::class,"api_get_person_notifications"]);
Route::post("get_offices",[App\Http\Controllers\OfficesController::class,"api_get_offices"]);

Route::post("create_notes",[\App\Http\Controllers\NotesController::class,"api_create_notes"]);
Route::post("get_notes",[\App\Http\Controllers\NotesController::class,"api_get_notes"]);

Route::post("forgot_password_check",[\App\Http\Controllers\PeopleController::class,"api_forgot_password_check"]);
