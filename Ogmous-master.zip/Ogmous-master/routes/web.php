<?php

use App\Http\Controllers\SendEmailController;
use App\Mail\ForgotPasswordMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect("login");
    //return view('welcome');
});

Auth::routes();

Route::get('/logout', [\App\Http\Controllers\Auth\LoginController::class,"logout"]);
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/dashboard', [App\Http\Controllers\DashboardController::class, 'index']);
Route::resource('/offices', App\Http\Controllers\OfficesController::class);
Route::resource('/people', App\Http\Controllers\PeopleController::class);
Route::resource('/offices_people', App\Http\Controllers\OfficesPeopleController::class);
Route::resource('/leave_requests', App\Http\Controllers\LeaveRequestsController::class);
Route::resource('/overtimes', App\Http\Controllers\OvertimeController::class);
Route::resource('/attendances', App\Http\Controllers\AttendancesController::class);
Route::resource('/users', App\Http\Controllers\UsersController::class);
Route::resource('/notifications', App\Http\Controllers\NotificationsController::class);
Route::resource('/activities', App\Http\Controllers\ActivitiesController::class);
Route::resource('/notes', App\Http\Controllers\NotesController::class);
Route::resource('/shifts', App\Http\Controllers\ShiftsController::class);
Route::get('/reports/attendance', [\App\Http\Controllers\AttendanceReportController::class,"index"]);
Route::post('/reports/attendance/markException', [\App\Http\Controllers\AttendanceReportController::class,"markException"]);
Route::get('/reports/overtime', [\App\Http\Controllers\OvertimeReportController::class,"index"]);
Route::get('/reports/leave_requests', [\App\Http\Controllers\LeaveRequestsController::class,"indexReports"]);

Route::get('user/change_password/{person_id}', [\App\Http\Controllers\PeopleController::class,"web_change_password"]);
Route::post('user/change_password/{person_id}/save', [\App\Http\Controllers\PeopleController::class,"web_save_password"]);

Route::get('send-mail', function () {

    (new SendEmailController())->sendForgotPasswordEmail(1);

    dd("Email is Sent.");
});
